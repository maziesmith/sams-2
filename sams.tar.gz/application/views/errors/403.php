<div class="four-zero-content no-sidebar">
    <div class="four-zero">
        <h2>Hello?</h2>
        <small class="m-b-10">Will you let me in?</small>
        <small class="m-b-10">No. It's 403. You're restricted.</small>
        <footer>
            <a href="<?php echo base_url('dashboard'); ?>"><i class="zmdi zmdi-arrow-back"></i></a>
            <a href="<?php echo base_url('/'); ?>"><i class="zmdi zmdi-home"></i></a>
        </footer>
    </div>
</div>