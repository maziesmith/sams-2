<?php $this->load->view('partials/header'); ?>
<?php $this->load->view($Headers->Page); ?>
<?php $this->load->view('partials/footer'); ?>