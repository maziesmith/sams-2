<aside id="sidebar">
    <div class="sidebar-inner c-overflow">

        <?php $this->load->view('partials/profile-menu') ?>

        <?php $this->load->view('partials/main-menu') ?>

    </div>
</aside>