# sams
A management system for Student Attendance
