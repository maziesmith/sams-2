<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class admin extends CI_Controller {

	function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
        
        if (!$this->session->userdata('IsLoggedIn')):
            redirect();
        else:
            if(!$this->session->userdata('IsAdmin')):
                redirect('users');
            endif;
        endif;
    }
    


	public function index()	{	

	$data['profile'] = $this->session->userdata('User');
	$data['sum_receipts'] = $this->main_model-> my_receipt($data['profile']['users_id']);	
	$data['sum_receipts_amount'] = $this->main_model-> my_receipt_sale($data['profile']['users_id']);
	$data['all_participants'] = $this->main_model->all_the_participant();
	$data['sum_events'] = $this->main_model->all_events();
	$data['results'] = $this->main_model->top_receipt();

	$this->template
		->title('Admin')
		->sub_title('Dashboard')
		->set_layout('admin')
		->append_metadata('<link rel="stylesheet" type="text/css" href="' . base_url("assets/plugin/morris/morris.css") . '">')
		->append_metadata('<link rel="stylesheet" type="text/css" href="' . base_url("assets/plugin/sweet-alert/sweet-alert.min.css") . '">')
		->append_metadata('<link rel="stylesheet" type="text/css" href="' . base_url("assets/plugin/rickshaw-chart/rickshaw.min.css") . '">')
        ->append_metadata('<script src="' . base_url("assets/plugin/chartjs/Chart.js") . '"></script>')
        ->append_metadata('<script src="' . base_url("assets/plugin/chartjs/chartjs.init.js") . '"></script>')
        ->append_metadata('<script src="' . base_url("assets/plugin/morris/morris.min.js") . '"></script>')
        ->append_metadata('<script src="' . base_url("assets/plugin/morris/raphael.min.js") . '"></script>')
        ->append_metadata('<script src="' . base_url("assets/plugin/morris/morris.init.js") . '"></script>')
        ->append_metadata('<script src="' . base_url("assets/js/jquery.counterup.min.js") . '"></script>')
        ->append_metadata('<script src="' . base_url("assets/js/counter.init.js") . '"></script>')
		->append_metadata('<script src="' . base_url("assets/admin/js/custom.js") . '"></script>')
		->build('admin/dashboard',$data);
	}


	public function receipts($add = null, $invoice = null){	

		if($add == "add"):			

			$this->load->model('main_model');
		    $data['results'] = $this->main_model->get_all_participants();
		    $data['profile'] = $this->session->userdata('User');


			$this->template
			->title('Admin')
			->sub_title('Add New Receipt')
			->set_layout('admin')
	        ->append_metadata('<link rel="stylesheet" type="text/css" href="' . base_url("assets/plugin/sweet-alert/sweet-alert.min.css") . '">')    
	        ->append_metadata('<link rel="stylesheet" type="text/css" href="' . base_url("assets/plugin/select2new/select2.min.css") . '">')
			->append_metadata('<script src="' . base_url("assets/plugin/sweet-alert/sweet-alert.min.js") . '"></script>')
	        ->append_metadata('<script src="' . base_url("assets/plugin/sweet-alert/sweet-alert.init.js") . '"></script>')
	        ->append_metadata('<script src="' . base_url("assets/plugin/select2new/select2.min.js") . '"></script>')
	        ->append_metadata('<script src="' . base_url("assets/plugin/select2new/select2.init.js") . '"></script>')
			->append_metadata('<script src="' . base_url("assets/admin/js/custom.js") . '"></script>')
			->append_metadata('<script src="' . base_url("assets/admin/js/paginate.js") . '"></script>')
			->build('admin/new_receipt',$data);  

		elseif( ($add == "generate") && (!(is_null($invoice))) ):	
			$data['profile'] = $this->session->userdata('User');

			$user = $this->main_model->get_receipts($invoice);
            if ($user):            	
                $this->main_model->print_receipts($invoice,$data);
                $this->load->library('pdf');
                $this->pdf->create($user);
            else:
                show_404();
            endif;

		elseif( ($add == "invoice") && (!(is_null($invoice))) ):	
			
			$this->load->model('main_model');
			$data['results'] = $this->main_model->search_receipts($invoice);
			$data['profile'] = $this->session->userdata('User');

			$this->template
			->title('Admin')
			->sub_title('Receipts')
			->set_layout('admin')			
			->append_metadata('<link rel="stylesheet" type="text/css" href="' . base_url("assets/plugin/sweet-alert/sweet-alert.min.css") . '">') 
			->append_metadata('<script src="' . base_url("assets/plugin/sweet-alert/sweet-alert.min.js") . '"></script>')
	        ->append_metadata('<script src="' . base_url("assets/plugin/sweet-alert/sweet-alert.init.js") . '"></script>')		
			->append_metadata('<script src="' . base_url("assets/admin/js/custom.js") . '"></script>')
			->build('admin/invoice',$data);

		elseif(is_null($add)):

			$data['profile'] = $this->session->userdata('User');

			$this->load->model('main_model');
			$data['all_receipts'] = $this->main_model->all_receipts();
			$data['all_received_receipts'] = $this->main_model->all_received_receipts();
			$data['all_cancelled_receipts'] = $this->main_model->all_cancelled_receipts();

			$this->template
			->title('Admin')
			->sub_title('All Receipts')
			->set_layout('admin')
			->append_metadata('<link rel="stylesheet" type="text/css" href="' . base_url("assets/plugin/sweet-alert/sweet-alert.min.css") . '">')
			->append_metadata('<script src="' . base_url("assets/plugin/sweet-alert/sweet-alert.min.js") . '"></script>')	
			->append_metadata('<script src="' . base_url("assets/admin/js/custom.js") . '"></script>')
			->append_metadata('<script src="' . base_url("assets/admin/js/paginate-all.js") . '"></script>')
			->append_metadata('<script src="' . base_url("assets/admin/js/paginate-all-received.js") . '"></script>')
			->append_metadata('<script src="' . base_url("assets/admin/js/paginate-all-cancelled.js") . '"></script>')
			->build('admin/receipts',$data);

		else:
			show_404();
		endif;

	}

	public function users($add = null){
		if($add == "add"):

			$this->load->model('main_model');
		    $data['results'] = $this->main_model->get_all_branch();
		    $data['profile'] = $this->session->userdata('User');


			$this->template
			->title('Admin')
			->sub_title('Add New User')
			->set_layout('admin')
	        ->append_metadata('<link rel="stylesheet" type="text/css" href="' . base_url("assets/plugin/sweet-alert/sweet-alert.min.css") . '">')    
			->append_metadata('<script src="' . base_url("assets/plugin/sweet-alert/sweet-alert.min.js") . '"></script>')
			->append_metadata('<script src="' . base_url("assets/admin/js/custom.js") . '"></script>')
			->build('admin/add_user',$data); 

		elseif(is_null($add)):

			$data['profile'] = $this->session->userdata('User');

			$this->load->model('main_model');
			$data['all_users'] = $this->main_model->all_users();
			$data['all_main_users'] = $this->main_model->all_main_users();
			$data['all_branch_users'] = $this->main_model->all_branch_users();
			$data['results'] = $this->main_model->get_all_branch();

			$this->template
			->title('Admin')
			->sub_title('All Users')
			->set_layout('admin')
			->append_metadata('<link rel="stylesheet" type="text/css" href="' . base_url("assets/plugin/sweet-alert/sweet-alert.min.css") . '">')
			->append_metadata('<script src="' . base_url("assets/plugin/sweet-alert/sweet-alert.min.js") . '"></script>')	
			->append_metadata('<script src="' . base_url("assets/admin/js/custom.js") . '"></script>')
			->append_metadata('<script src="' . base_url("assets/admin/js/paginate-all-users.js") . '"></script>')
			->append_metadata('<script src="' . base_url("assets/admin/js/paginate-all-main.js") . '"></script>')
			->append_metadata('<script src="' . base_url("assets/admin/js/paginate-all-branch.js") . '"></script>')
			->build('admin/users',$data);
		else:
			show_404();
		endif;

	}

	




	public function myprofile(){
		$data['profile'] = $this->session->userdata('User');

		$this->template
		->title('Admin')
		->sub_title('MyProfile')
		->set_layout('admin')		
		->append_metadata('<script src="' . base_url("assets/admin/js/custom.js") . '"></script>')
		->build('admin/myprofile',$data);
	}

	public function timestamp(){
		$data['profile'] = $this->session->userdata('User');
		$data['results'] = $this->main_model->get_all_users();
		

		$this->template
		->title('Admin')
		->sub_title('Timestamp')
		->set_layout('admin')
		->append_metadata('<link rel="stylesheet" type="text/css" href="' . base_url("assets/plugin/timepicker/bootstrap-datepicker.min.css") . '">')
		->append_metadata('<script src="' . base_url("assets/plugin/timepicker/bootstrap-datepicker.js") . '"></script>')
		->append_metadata('<script src="' . base_url("assets/plugin/timepicker/datepicker-init.js") . '"></script>')
		->append_metadata('<script src="' . base_url("assets/admin/js/custom.js") . '"></script>')
		->build('admin/timestamp',$data);
	}

	public function search_nric($val){		
		$this->load->model('main_model');
		$data['results'] = $this->main_model->search_participants($val);
		$data['profile'] = $this->session->userdata('User');

		$this->template
		->title('Admin')
		->sub_title('Search Participants')
		->set_layout('')
		->build('admin/search_nric.php',$data);
	}

	public function add_receipts(){
		
		$this->load->model('main_model');		
		$data['results'] = $this->main_model->add_receipts();
		$data['profile'] = $this->session->userdata('User');

		$this->template
		->title('Admin')
		->sub_title('Add Receipts')
		->set_layout('')
		->build('admin/add_receipts.php',$data);
	}


	public function save_user(){
		
		$this->load->model('main_model');		
		$data['results'] = $this->main_model->save_user();
		$data['profile'] = $this->session->userdata('User');

		$this->template
		->title('Admin')
		->sub_title('Save User')
		->set_layout('')
		->build('admin/save_user.php',$data);
	}

	public function search_receipts($add = null){
		
		$this->template
		->title('Admin')
		->sub_title('Search Receipts')
		->set_layout('admin')
		->append_metadata('<script src="' . base_url("assets/plugin/modal-effect/js/classie.js") . '"></script>')
	    ->append_metadata('<script src="' . base_url("assets/plugin/modal-effect/js/modalEffects.js") . '"></script>')
	    ->append_metadata('<script src="' . base_url("assets/admin/js/custom.js") . '"></script>')
	    ->build('admin/search_receipts.php');

	}

	public function participants($add = null){
		$data['profile'] = $this->session->userdata('User');
		
		$this->template
		->title('Admin')
		->sub_title('All Participants')
		->set_layout('admin')
	    ->append_metadata('<link rel="stylesheet" type="text/css" href="' . base_url("assets/plugin/sweet-alert/sweet-alert.min.css") . '">')
		->append_metadata('<script src="' . base_url("assets/plugin/sweet-alert/sweet-alert.min.js") . '"></script>')	
		->append_metadata('<script src="' . base_url("assets/admin/js/custom.js") . '"></script>')
		->append_metadata('<script src="' . base_url("assets/admin/js/paginate-all-part.js") . '"></script>')
		->append_metadata('<script src="' . base_url("assets/admin/js/paginate-all-del-part.js") . '"></script>')
	    ->build('admin/participants.php',$data);
	}



	public function search_or($add = null){
		$this->load->model('main_model');
		$data['results'] = $this->main_model->search_or();
		$data['profile'] = $this->session->userdata('User');

		$this->template
		->title('Admin')
		->sub_title('Search OR')
		->set_layout('')
		->build('admin/search_or.php',$data);
	}

	public function search_pr($add = null){
		$this->load->model('main_model');
		$data['results'] = $this->main_model->search_pr();
		$data['profile'] = $this->session->userdata('User');

		$this->template
		->title('Admin')
		->sub_title('Search PR')
		->set_layout('')
		->build('admin/search_pr.php',$data);
	}

	public function search_user($add = null){
		$this->load->model('main_model');
		$data['results'] = $this->main_model->search_user();
		$data['profile'] = $this->session->userdata('User');

		$this->template
		->title('Admin')
		->sub_title('Search User')
		->set_layout('')
		->build('admin/search_user.php',$data);
	}

	public function view_activity(){
		$this->load->model('main_model');
		$data['results'] = $this->main_model->view_activity();
		$data['profile'] = $this->session->userdata('User');

		$this->template
		->title('Admin')
		->sub_title('View Activity')
		->set_layout('')
		->build('admin/view_activity.php',$data);
	}


	public function update_or($add = null){
		
		$this->load->model('main_model');
		$data['results'] = $this->main_model->update_or();
		$data['profile'] = $this->session->userdata('User');

		$this->template
		->title('Admin')
		->sub_title('Update OR')
		->set_layout('')
		->build('admin/update_or.php',$data);

	}

	public function update_user($add = null){
		
		$this->load->model('main_model');
		$data['results'] = $this->main_model->update_user(true);
		$data['profile'] = $this->session->userdata('User');

		$this->template
		->title('Admin')
		->sub_title('Update User')
		->set_layout('')
		->build('admin/update_user.php',$data);

	}

	public function update_pr(){
		
		$this->load->model('main_model');
		$data['results'] = $this->main_model->update_pr();
		$data['profile'] = $this->session->userdata('User');

		$this->template
		->title('Admin')
		->sub_title('Update Participants')
		->set_layout('')
		->build('admin/update_pr.php',$data);

	}


	public function count_all_cancelled_receipt(){
		
		$this->load->model('main_model');
		$data['results'] = $this->main_model->count_all_cancelled_receipt();
		$data['profile'] = $this->session->userdata('User');

		$this->template
		->title('Admin')
		->sub_title('Count All Cancelled Receipts')
		->set_layout('')
		->build('admin/count_all_cancelled_receipt.php',$data);

	}

	public function count_all_received_receipt(){
		
		$this->load->model('main_model');
		$data['results'] = $this->main_model->count_all_received_receipt();
		$data['profile'] = $this->session->userdata('User');

		$this->template
		->title('Admin')
		->sub_title('Count All Received Receipts')
		->set_layout('')
		->build('admin/count_all_received_receipt.php',$data);

	}

	public function count_all_receipt(){
		
		$this->load->model('main_model');
		$data['results'] = $this->main_model->count_all_receipt();
		$data['profile'] = $this->session->userdata('User');

		$this->template
		->title('Admin')
		->sub_title('Count All Receipts')
		->set_layout('')
		->build('admin/count_all_receipt.php',$data);

	}


	public function count_del(){
		
		$this->load->model('main_model');
		$data['results'] = $this->main_model->count_del();
		$data['profile'] = $this->session->userdata('User');

		$this->template
		->title('Admin')
		->sub_title('Count All Delete Participants')
		->set_layout('')
		->build('admin/count_del.php',$data);

	}

	public function autoload_process(){
		
		$this->load->model('main_model');
		
		$data['profile'] = $this->session->userdata('User');

		$this->template
		->title('Admin')
		->sub_title('Autoload')
		->set_layout('')
		->append_metadata('<script src="' . base_url("assets/js/jquery.js") . '"></script>')
		->append_metadata('<script src="' . base_url("assets/plugin/timeago/jquery.timeago.js") . '"></script>')
		->append_metadata('<script src="' . base_url("assets/plugin/timeago/jquery.timeago-init.js") . '"></script>')
		->build('admin/autoload_process.php',$data);

	}

	public function count_act(){
		
		$this->load->model('main_model');
		$data['results'] = $this->main_model->count_act();
		$data['profile'] = $this->session->userdata('User');

		$this->template
		->title('Admin')
		->sub_title('Count All Active Participants')
		->set_layout('')
		->append_metadata('<script src="' . base_url("assets/admin/js/custom.js") . '"></script>')
		->build('admin/count_act.php',$data);

	}


	public function all_receipts(){
		$this->template
		->title('Admin')
		->sub_title('View All Receipts')
		->set_layout('admin')
		->append_metadata('<script src="' . base_url("assets/plugin/modal-effect/js/classie.js") . '"></script>')
	    ->append_metadata('<script src="' . base_url("assets/plugin/modal-effect/js/modalEffects.js") . '"></script>')
	    ->append_metadata('<script src="' . base_url("assets/admin/js/cancel-1.js") . '"></script>')
	    ->build('admin/all_receipts.php');
	}

	public function all_users(){
		$this->template
		->title('Admin')
		->sub_title('View All Users')
		->set_layout('admin')
		->append_metadata('<script src="' . base_url("assets/plugin/modal-effect/js/classie.js") . '"></script>')
	    ->append_metadata('<script src="' . base_url("assets/plugin/modal-effect/js/modalEffects.js") . '"></script>')
	    ->append_metadata('<script src="' . base_url("assets/admin/js/custom2.js") . '"></script>')
	    ->build('admin/all_users.php');
	}

	public function all_main(){
		$this->template
		->title('Admin')
		->sub_title('View All Main Users')
		->set_layout('admin')
		->append_metadata('<script src="' . base_url("assets/plugin/modal-effect/js/classie.js") . '"></script>')
	    ->append_metadata('<script src="' . base_url("assets/plugin/modal-effect/js/modalEffects.js") . '"></script>')
	    ->append_metadata('<script src="' . base_url("assets/admin/js/custom2.js") . '"></script>')
	    ->build('admin/all_main.php');
	}

	public function all_branch(){
		$this->template
		->title('Admin')
		->sub_title('View All Branch Users')
		->set_layout('admin')
		->append_metadata('<script src="' . base_url("assets/plugin/modal-effect/js/classie.js") . '"></script>')
	    ->append_metadata('<script src="' . base_url("assets/plugin/modal-effect/js/modalEffects.js") . '"></script>')
	    ->append_metadata('<script src="' . base_url("assets/admin/js/custom2.js") . '"></script>')
	    ->build('admin/all_branch.php');
	}

	public function all_participants(){
		

		$this->template
		->title('Admin')
		->sub_title('View All Participants')
		->set_layout('admin')
		->append_metadata('<script src="' . base_url("assets/plugin/modal-effect/js/classie.js") . '"></script>')
	    ->append_metadata('<script src="' . base_url("assets/plugin/modal-effect/js/modalEffects.js") . '"></script>')
	    ->append_metadata('<script src="' . base_url("assets/admin/js/custom1.js") . '"></script>')
	    ->build('admin/all_participants.php');
	}

	public function all_del_participants(){
		

		$this->template
		->title('Admin')
		->sub_title('View All Delete Participants')
		->set_layout('admin')
		->append_metadata('<script src="' . base_url("assets/plugin/modal-effect/js/classie.js") . '"></script>')
	    ->append_metadata('<script src="' . base_url("assets/plugin/modal-effect/js/modalEffects.js") . '"></script>')
	    ->append_metadata('<script src="' . base_url("assets/admin/js/custom1.js") . '"></script>')
	    ->build('admin/all_del_participants.php');
	}

	public function all_received_receipts(){
		$this->template
		->title('Admin')
		->sub_title('View All Received Receipts')
		->set_layout('admin')
		->append_metadata('<script src="' . base_url("assets/plugin/modal-effect/js/classie.js") . '"></script>')
	    ->append_metadata('<script src="' . base_url("assets/plugin/modal-effect/js/modalEffects.js") . '"></script>')
	    ->append_metadata('<script src="' . base_url("assets/admin/js/cancel-1.js") . '"></script>')
	    ->build('admin/all_received_receipts.php');
	}

	public function all_cancelled_receipts(){
		$this->template
		->title('Admin')
		->sub_title('View All Cancelled Receipts')
		->set_layout('admin')
		->append_metadata('<script src="' . base_url("assets/plugin/modal-effect/js/classie.js") . '"></script>')
	    ->append_metadata('<script src="' . base_url("assets/plugin/modal-effect/js/modalEffects.js") . '"></script>')
	    ->build('admin/all_cancelled_receipts.php');
	}

	public function selectallparticipants(){
        // change value of var
        $this->variable = 'adios';
    }


}
