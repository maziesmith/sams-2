<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Main extends CI_Controller {

	function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
    }

	public function index()	{	
	
	/*if($this->session->userdata('IsLoggedIn')):
	    if($this->session->userdata('IsAdmin')):
	        redirect('admin/');
	    else:
	        redirect('users/');
	    endif;
	endif;
    */

	$this->template
	->title('Login')
	->set_layout('main')
	->append_metadata('<link rel="stylesheet" type="text/css" href="' . base_url("assets/front/css/style.css") . '">') 
	->append_metadata('<script src="' . base_url("assets/front/js/custom.js") . '"></script>')
	->build('login');

	}

    public function lean() {

        $this->template
        ->title('Login')
        ->set_layout('main')
        ->append_metadata('<link rel="stylesheet" type="text/css" href="' . base_url("assets/front/css/style.css") . '">')
        ->append_metadata('<link rel="stylesheet" type="text/css" href="' . base_url("assets/front/css/style1.css") . '">') 
        ->append_metadata('<script src="' . base_url("assets/front/js/custom.js") . '"></script>')
        ->build('login');

        $this->load->view('wasak');
      
    }

    
	/*public function ajax_login() {
        if ($this->input->is_ajax_request()):

            $this->form_validation->set_rules('Username', 'Username', 'required|trim|xss_clean');
            $this->form_validation->set_rules('Password', 'Password', 'required|trim|xss_clean');

            $user = FALSE;

            if ($this->form_validation->run() == TRUE):
                $user = $this->users_model->checkUsernameAndPassword($this->input->post('Username'), $this->input->post('Password'));
            endif;

            if ($user):
                //set user session
                $this->session
                        ->set_userdata(
                                array(
                                    'User' => $user,
                                    'IsLoggedIn' => true,
                                    'IsAdmin' => $user['users_role'] == 'admin' ? true : false
                                )
                );
                $redirect = $user['users_role'] == 'admin' ? 'admin/dashboard' : 'users';
                echo json_encode(array('status' => 'Success', 'redirect' => base_url($redirect)));
            else:
                echo json_encode(array('status' => 'Failed'));
            endif;
        endif;

    }

    public function is_logged_in() {
        if ($this->session->userdata('User') && $this->session->userdata('IsLoggedIn')):
            return true;
        endif;
        return false;
    }

    public function is_admin() {
        if ($this->session->userdata('User') && $this->session->userdata('IsAdmin')):
            return true;
        endif;
        return false;
    }

    public function logout() {
        $this->session->sess_destroy();
        redirect();
    }*/
	
}
