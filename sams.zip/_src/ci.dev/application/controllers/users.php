<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Users extends CI_Controller {

	function __construct() {
		
        parent::__construct();
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');

        if (!$this->session->userdata('IsLoggedIn')):
            redirect();
   	 	else:
            if($this->session->userdata('IsAdmin')):
                redirect('admin');
            endif;
        endif;
        
    }


	public function index()	{	

	$this->load->model('main_model');
	$data['profile'] = $this->session->userdata('User');
	$data['sum_receipts'] = $this->main_model-> my_receipt($data['profile']['users_id']);	
	$data['sum_receipts_amount'] = $this->main_model-> my_receipt_sale($data['profile']['users_id']);
	$data['all_participants'] = $this->main_model->all_the_participant();
	$data['sum_events'] = $this->main_model->all_events();

	$data['results'] = $this->main_model->recent_receipt($data['profile']['users_id']);

	$this->template
		->title('Users')
		->sub_title('Dashboard')
		->set_layout('users')
		->append_metadata('<link rel="stylesheet" type="text/css" href="' . base_url("assets/plugin/morris/morris.css") . '">')
		->append_metadata('<link rel="stylesheet" type="text/css" href="' . base_url("assets/plugin/rickshaw-chart/rickshaw.min.css") . '">')
        ->append_metadata('<script src="' . base_url("assets/plugin/chartjs/Chart.js") . '"></script>')
        ->append_metadata('<script src="' . base_url("assets/plugin/chartjs/chartjs.init.js") . '"></script>')  		
        ->append_metadata('<script src="' . base_url("assets/plugin/rickshaw-chart/vendor/d3.min.js") . '"></script>')
        ->append_metadata('<script src="' . base_url("assets/plugin/rickshaw-chart/vendor/d3.layout.min.js") . '"></script>')
        ->append_metadata('<script src="' . base_url("assets/plugin/rickshaw-chart/rickshaw.min.js") . '"></script>')
        ->append_metadata('<script src="' . base_url("assets/plugin/rickshaw-chart/rickshaw.chart.init.js") . '"></script>')
		->append_metadata('<script src="' . base_url("assets/users/js/custom.js") . '"></script>')
		->build('users/dashboard',$data);
	}


	public function receipts($add = null, $invoice = null){	

		if($add == "add"):			

			$this->load->model('main_model');
		    $data['results'] = $this->main_model->get_all_participants();
		    $data['profile'] = $this->session->userdata('User');


			$this->template
			->title('Users')
			->sub_title('Add New Receipt')
			->set_layout('users')
	        ->append_metadata('<link rel="stylesheet" type="text/css" href="' . base_url("assets/plugin/sweet-alert/sweet-alert.min.css") . '">')    
	        ->append_metadata('<link rel="stylesheet" type="text/css" href="' . base_url("assets/plugin/select2new/select2.min.css") . '">')
			->append_metadata('<script src="' . base_url("assets/plugin/sweet-alert/sweet-alert.min.js") . '"></script>')
	        ->append_metadata('<script src="' . base_url("assets/plugin/sweet-alert/sweet-alert.init.js") . '"></script>')
	        ->append_metadata('<script src="' . base_url("assets/plugin/select2new/select2.min.js") . '"></script>')
	        ->append_metadata('<script src="' . base_url("assets/plugin/select2new/select2.init.js") . '"></script>')
			->append_metadata('<script src="' . base_url("assets/users/js/custom.js") . '"></script>')
			->append_metadata('<script src="' . base_url("assets/users/js/paginate.js") . '"></script>')
			->build('users/new_receipt',$data);  

		elseif( ($add == "generate") && (!(is_null($invoice))) ):	
			$data['profile'] = $this->session->userdata('User');
			$user = $this->main_model->get_receipts($invoice);
            if ($user):
            	$this->main_model->print_receipts($invoice,$data);
                $this->load->library('pdf');
                $this->pdf->create($user);
            else:
                show_404();
            endif;

		elseif( ($add == "invoice") && (!(is_null($invoice))) ):	
			
			$this->load->model('main_model');
			$data['results'] = $this->main_model->search_receipts($invoice);
			$data['profile'] = $this->session->userdata('User');

			$this->template
			->title('Users')
			->sub_title('Receipts')
			->set_layout('users')
			->append_metadata('<link rel="stylesheet" type="text/css" href="' . base_url("assets/plugin/sweet-alert/sweet-alert.min.css") . '">') 
			->append_metadata('<script src="' . base_url("assets/plugin/sweet-alert/sweet-alert.min.js") . '"></script>')
	        ->append_metadata('<script src="' . base_url("assets/plugin/sweet-alert/sweet-alert.init.js") . '"></script>')		
			->append_metadata('<script src="' . base_url("assets/users/js/custom.js") . '"></script>')
			->build('users/invoice',$data);

		elseif(is_null($add)):

			$data['profile'] = $this->session->userdata('User');

			$this->load->model('main_model');
			$data['all_receipts'] = $this->main_model->all_receipts($data['profile']);
			$data['all_received_receipts'] = $this->main_model->all_received_receipts($data['profile']);
			$data['all_cancelled_receipts'] = $this->main_model->all_cancelled_receipts($data['profile']);

			$this->template
			->title('Users')
			->sub_title('All Receipts')
			->set_layout('users')		
			->append_metadata('<script src="' . base_url("assets/users/js/custom.js") . '"></script>')
			->append_metadata('<script src="' . base_url("assets/users/js/paginate-all.js") . '"></script>')
			->append_metadata('<script src="' . base_url("assets/users/js/paginate-all-received.js") . '"></script>')
			->append_metadata('<script src="' . base_url("assets/users/js/paginate-all-cancelled.js") . '"></script>')
			->build('users/receipts',$data);

		else:
			show_404();
		endif;

	}

	public function myprofile(){
		$data['profile'] = $this->session->userdata('User');

		$this->template
		->title('Users')
		->sub_title('MyProfile')
		->set_layout('users')		
		->append_metadata('<script src="' . base_url("assets/users/js/custom.js") . '"></script>')
		->build('users/myprofile',$data);
	}

	public function search_nric($val){		
		$this->load->model('main_model');
		$data['results'] = $this->main_model->search_participants($val);
		$data['profile'] = $this->session->userdata('User');

		$this->template
		->title('Users')
		->sub_title('Search Participants')
		->set_layout('')
		->build('users/search_nric.php',$data);
	}

	public function add_receipts(){
		
		$this->load->model('main_model');		
		$data['results'] = $this->main_model->add_receipts();
		$data['profile'] = $this->session->userdata('User');

		$this->template
		->title('Users')
		->sub_title('Add Receipts')
		->set_layout('')
		->build('users/add_receipts.php',$data);
	}

	public function search_receipts($add = null){

		$this->template
		->title('Users')
		->sub_title('Search Receipts')
		->set_layout('users')
		->append_metadata('<script src="' . base_url("assets/plugin/modal-effect/js/classie.js") . '"></script>')
	    ->append_metadata('<script src="' . base_url("assets/plugin/modal-effect/js/modalEffects.js") . '"></script>')
	    ->append_metadata('<script src="' . base_url("assets/users/js/custom.js") . '"></script>')
	    ->build('users/search_receipts.php');
	}


	public function all_receipts(){
		$data['profile'] = $this->session->userdata('User');

		$this->template
		->title('Users')
		->sub_title('View All Receipts')
		->set_layout('users')
		->append_metadata('<script src="' . base_url("assets/plugin/modal-effect/js/classie.js") . '"></script>')
	    ->append_metadata('<script src="' . base_url("assets/plugin/modal-effect/js/modalEffects.js") . '"></script>')

	    ->build('users/all_receipts.php',$data);
	}

	public function all_received_receipts(){
		$data['profile'] = $this->session->userdata('User');

		$this->template
		->title('Users')
		->sub_title('View All Received Receipts')
		->set_layout('users')
		->append_metadata('<script src="' . base_url("assets/plugin/modal-effect/js/classie.js") . '"></script>')
	    ->append_metadata('<script src="' . base_url("assets/plugin/modal-effect/js/modalEffects.js") . '"></script>')
	    ->build('users/all_received_receipts.php',$data);
	}

	public function all_cancelled_receipts(){
		$data['profile'] = $this->session->userdata('User');

		$this->template
		->title('Users')
		->sub_title('View All Cancelled Receipts')
		->set_layout('users')
		->append_metadata('<script src="' . base_url("assets/plugin/modal-effect/js/classie.js") . '"></script>')
	    ->append_metadata('<script src="' . base_url("assets/plugin/modal-effect/js/modalEffects.js") . '"></script>')
	    ->build('users/all_cancelled_receipts.php',$data);
	}

	public function participants_name($id){
        $this->load->model('main_model');
		return $this->main_model->search_participant_name($id);
	
    }


}
