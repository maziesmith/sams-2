<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">

        <link rel="shortcut icon" href="img/favicon_1.ico">

        <title>Velonic - Responsive Admin Dashboard Template</title>

        


        <!-- Bootstrap core CSS -->
        <link href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>" rel="stylesheet">
        <link href="<?php echo base_url('assets/css/bootstrap-reset.css'); ?>" rel="stylesheet">

        <!--Animation css-->
        <link href="<?php echo base_url('assets/css/animate.css'); ?>" rel="stylesheet">

        <!--Icon-fonts css-->
        <link href="<?php echo base_url('assets/css/font-awesome.css'); ?>" rel="stylesheet" />
        <link href="<?php echo base_url('assets/plugin/ionicon/css/ionicons.min.css'); ?>" rel="stylesheet" />



        <!-- Custom styles for this template -->

        <link href="<?php echo base_url('assets/front/css/style.css'); ?>" rel="stylesheet">
        <link href="<?php echo base_url('assets/front/css/404.css'); ?>" rel="stylesheet">
        <link href="<?php echo base_url('assets/css/helper.css'); ?>" rel="stylesheet">
        

        <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
        <!--[if lt IE 9]>
          <script src="js/html5shiv.js"></script>
          <script src="js/respond.min.js"></script>
        <![endif]-->

    </head>


    <body>

        <div class="wrapper-page animated fadeInDown">

            <div class="ex-page-content animated flipInX text-center">
                <br/>
                <h1>404</h1>
                <h2 class="font-light">Sorry, page not found</h2><br>
               
                <a class="btn btn-primary" href="<?php echo base_url(); ?>"><i class="fa fa-angle-left"></i> Back to Homepage</a>
            </div>
            
        </div>


        <!-- js placed at the end of the document so the pages load faster -->
        <script src="<?php echo base_url('assets/js/jquery.js'); ?>"></script>
        <script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
        <script src="<?php echo base_url('assets/js/pace.min.js'); ?>"></script>
        <script src="<?php echo base_url('assets/js/wow.min.js'); ?>"></script>
        <script src="<?php echo base_url('assets/js/jquery.nicescroll.js'); ?>"></script>
            

        <!--common script for all pages-->
        <script src="<?php echo base_url('assets/js/jquery.app.js'); ?>"></script>

    
  </body>
</html>
