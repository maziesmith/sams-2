<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Validate {

    protected $validations_array = array();

    public function __construct() {
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('', '');
    }

    public function run($fields = array()) {
        foreach ($fields as $key => $rule):

            if (substr($rule, 0, 8) === "Required"):

                $rules = 'trim|required|xss_clean';

            elseif (substr($rule, 0, 3) === "Url"):

                $rules = 'trim|valid_url|xss_clean';

            else:

                $rules = 'trim|xss_clean';

            endif;

            $this->form_validation->set_rules(
                    $key, //name of inupt, select or textarea
                    $field, //label
                    $rules
            );
            break;

        endforeach;

        //validation errors
        if ($this->form_validation->run() == FALSE):

            //set all error message to an array with it's field
            foreach ($fields as $key => $field):
                if (form_error($key)): $this->validations_array[$key] = form_error($key);
                endif;
            endforeach;

            //return validation errors	
            return $this->validations_array;
        endif;

        //return validation errors	
        return $this->validations_array;
    }

    /**
     * __get
     *
     * Enables the use of CI super-global without having to define an extra variable.
     *
     * I can't remember where I first saw this, so thank you if you are the original author. -Militis
     *
     * @access	public
     * @param	$var
     * @return	mixed
     */
    public function __get($var) {
        return get_instance()->$var;
    }

}
