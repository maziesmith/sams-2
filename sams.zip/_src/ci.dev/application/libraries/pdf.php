<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');
//============================================================+
// File name   : example_061.php
// Begin       : 2010-05-24
// Last Update : 2010-08-08
//
// Description : Example 061 for TCPDF class
//               XHTML + CSS
//
// Author: Nicola Asuni
//
// (c) Copyright:
//               Nicola Asuni
//               Tecnick.com s.r.l.
//               Via Della Pace, 11
//               09044 Quartucciu (CA)
//               ITALY
//               www.tecnick.com
//               info@tecnick.com
//============================================================+

/**
 * Creates an example PDF TEST document using TCPDF
 * @package com.tecnick.tcpdf
 * @abstract TCPDF - Example: XHTML + CSS
 * @author Nicola Asuni
 * @since 2010-05-25
 */
require_once('tcpdf/tcpdf.php');

class PDF {

    public function create($data) {
        // create new PDF document
        $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

        // set document information
        $pdf->SetCreator(PDF_CREATOR);
        $pdf->SetAuthor('theRECEIPT');
        $pdf->SetTitle($data['receipts_or']);
        $pdf->SetSubject('theRECEIPT');

        // remove default header/footer
        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);


        $query = $this->db->query("SELECT * FROM participants where participants_id='".$data['participants_id']."'");
            foreach ($query->result() as $row)
            {
                $id = $row->participants_id;
                $fname = $row->participants_fullname;
                $nric = $row->participants_nric;
            }

        $query = $this->db->query("SELECT * FROM users where users_id='".$data['users_id']."'");
            foreach ($query->result() as $row)
            {                
                $u_fname = $row->users_fullname;

                $query1 = $this->db->query("SELECT * FROM branch where branch_id='".$row->branch_id."'");
                foreach ($query1->result() as $row1)
                {                
                    $location = $row1->branch_name;
                }
            }


        $query3 = $this->db->query("SELECT * FROM receipts_printed where receipts_id=".$data['receipts_id']."");
            
            if ($query3->num_rows() == 1){
                $receipt_type = "Original Receipt";
            } else {
                $receipt_type = "Duplicate Copy";
            }


            $msg = '';
            $msg .= substr($nric, 0, 1);
            $msg .= 'XXXX';
            $msg .= substr($nric, 5);

                                                       
        // set default monospaced font
        //$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

        //set margins
        //$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
        $pdf->SetMargins(10, 10, 10);

        //set auto page breaks
        $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

        //set image scale factor
        $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

        // ---------------------------------------------------------
        // set font
        $pdf->SetFont('helvetica', '', 11);

        // add a page
        $pdf->AddPage();

        date_default_timezone_set("Asia/Singapore"); 
        $date = date('Y-M-d / h:i A');
        
        //$dateCreated = date('F d, Y',strtotime($data['DateCreated']));
        //$dateUpdated = date('F d, Y',strtotime($data['DateUpdated']));
        $pdf->SetAlpha(1);
        // define some HTML content with style
        $pdf->Image('assets/img/logo.png',13,11,62);
        $pdf->SetFont('helvetica','B',12);
        $pdf->SetY(10);
        $pdf->Setx(85);
        $pdf->Cell(65, 6, 'SSA Consulting Group Pte. Ltd', 0, 0, 'L');
        $pdf->Cell(47, 6, 'Official Receipt', 0, 0, 'R');
        $pdf->ln(5);
        $pdf->SetFont('helvetica','',11);
        $pdf->Setx(85);
        $pdf->Cell(65, 6, '11 Eunos Road 8 Lifelong Learning', 0, 0, 'L');
        $pdf->Cell(47, 6, 'No.: '.$data['receipts_or'], 0, 0, 'R');
        $pdf->ln(5);
        $pdf->SetFont('helvetica','',11);
        $pdf->Setx(85);
        $pdf->Cell(65, 5, 'Institute Singapore 408601', 0, 0, 'L');
        $pdf->Cell(47, 5, $receipt_type, 0, 0, 'R');
        $pdf->ln(5);
        $pdf->SetFont('helvetica','',11);
        $pdf->Setx(85);
        $pdf->Cell(65, 5, 'Tel: 6842-2282 Fax: 6842-2202', 0, 0, 'L');
        $pdf->Cell(47, 5, '', 0, 0, 'R');
        $pdf->ln(5);
        $pdf->SetFont('helvetica','',11);
        $pdf->Setx(85);
        $pdf->Cell(65, 5, 'GST Reg No.: M200632125', 0, 0, 'L');
        $pdf->Cell(47, 5, '', 0, 0, 'R');
        $pdf->ln(5);
       

        $style = array('width' => .5, 'cap' => 'butt', 'join' => 'miter', 'stroke' => '10,20,5,10', 'phase' => 10, 'color' => array(238, 238, 238));
        $pdf->Line(14, 42, 196, 42, $style);


        $pdf->ln(13);
        $pdf->SetFont('helvetica','B',11);
        $pdf->Setx(13);
        $pdf->Cell(65, 6, 'Receipts Details', 0, 0, 'L');
        $pdf->ln();
        $pdf->SetFont('helvetica','B',11);
        $pdf->Setx(13);
        $pdf->Cell(44, 6, 'Received From', 0, 0, 'L');
        $pdf->SetFont('helvetica','',11);
        $pdf->Cell(47, 6, ': '.$fname, 0, 0, 'L');
        $pdf->SetFont('helvetica','B',11);
        $pdf->Cell(44, 6, 'Receipt Date', 0, 0, 'L');
        $pdf->SetFont('helvetica','',11);
        $pdf->Cell(47, 6, ': '.$data['receipts_date'],0, 0, 'L');

        $pdf->ln();
        $pdf->SetFont('helvetica','B',11);
        $pdf->Setx(13);
        $pdf->Cell(44, 6, 'Type of Transaction', 0, 0, 'L');
        $pdf->SetFont('helvetica','',11);
        $pdf->Cell(47, 6, ': '.$data['receipts_trans_type'], 0, 0, 'L');
        $pdf->SetFont('helvetica','B',11);
        $pdf->Cell(44, 6, 'Received By', 0, 0, 'L');
        $pdf->SetFont('helvetica','',11);
        $pdf->Cell(47, 6, ': '.$u_fname, 0, 0, 'L');

        $pdf->ln();
        $pdf->SetFont('helvetica','B',11);
        $pdf->Setx(13);
        $pdf->Cell(44, 6, 'Transaction Ref. No.', 0, 0, 'L');
        $pdf->SetFont('helvetica','',11);
        $pdf->Cell(47, 6, ': '.$data['receipts_ref_no'], 0, 0, 'L');
        $pdf->SetFont('helvetica','B',11);
        $pdf->Cell(44, 6, 'Received At', 0, 0, 'L');
        $pdf->SetFont('helvetica','',11);
        $pdf->Cell(47, 6, ': '.$location, 0, 0, 'L');

        $pdf->ln();
        $pdf->SetFont('helvetica','B',11);
        $pdf->Setx(13);
        $pdf->Cell(44, 6, 'Remarks', 0, 0, 'L');
        $pdf->SetFont('helvetica','',11);  
        $pdf->Cell(2, 6, ':', 0, 0, 'L');  
        $pdf->ln(.5); 
        $pdf->MultiCell(137, 6,$data['receipts_ref_no'],0, 'L',false, 0, 59); 


        $style = array('width' => .7, 'cap' => 'butt', 'join' => 'miter', 'stroke' => '10,20,5,10', 'phase' => 10, 'color' => array(221, 221, 221));
        $pdf->Line(14, 85, 196, 85, $style);

        $pdf->ln(14);
        $pdf->SetFont('helvetica','B',11);
        $pdf->Setx(15);
        $pdf->Cell(44, 6, 'Participant', 0, 0, 'L');
        $pdf->Cell(40, 6, 'Identification No.', 0, 0, 'L');
        $pdf->Cell(64, 6, 'Description', 0, 0, 'L');
        $pdf->Cell(32, 6, 'Amount', 0, 0, 'R');

        $pdf->Line(14, 94, 196, 94 , $style);

        $pdf->ln(9);
        $pdf->SetFont('helvetica','',11);
        $pdf->MultiCell(44, 6,$fname,0, 'L',false, 0, 15); 
        $pdf->MultiCell(40, 6,$msg,0, 'L',false, 1, 59);
        $pdf->ln(-5.5);
        $pdf->MultiCell(64, 6,$data['receipts_course_desc'],0, 'L',false, 1, 99); 
        
        $pdf->ln(2);
        $pdf->SetLineWidth(.3);
        $pdf->Setx(14);
        $pdf->Cell(182, 0, '', 1, 1, 'C', 0, '', 0, true, 'T', 'C');

        $style = array('width' => .5, 'cap' => 'butt', 'join' => 'miter', 'stroke' => '10,20,5,10', 'phase' => 10, 'color' => array(238, 238, 238));
      
    


        //$pdf->Line(14, 127, 196, 127, $style);
        $pdf->ln(2);

        $pdf->SetFont('helvetica','I',11);

        $pdf->MultiCell(91, 6,'This is a company-generated document. No signature is required.',0, 'L',false, 0, 14); 
        
        $pdf->ln(-0.5);     
        $pdf->Setx(105);
       

        $pdf->SetFont('helvetica','B',11);
        $pdf->Cell(44, 6, 'Total Amount', 0, 0, 'L');
        $pdf->SetFont('helvetica','',11);
        $pdf->Cell(2, 6, ': ', 0, 0, 'L');
        $pdf->Cell(44, 6, '$ '.number_format($data['receipts_amount'],2), 0, 0, 'R');
        $pdf->ln(6);     
        $pdf->Setx(105);
        $pdf->SetFont('helvetica','B',11);
        $pdf->Cell(44, 6, 'Print Date/Time', 0, 0, 'L');
        $pdf->SetFont('helvetica','',11);
        $pdf->Cell(2, 6, ': ', 0, 0, 'L');
        $pdf->Cell(44, 6, $date, 0, 0, 'R');


        $pdf->Setx(15);
        $pdf->Sety(96);
        $pdf->MultiCell(32, 6,'$ '.number_format($data['receipts_amount'],2),0, 'R',false,1, 163);  


        $pdf->Output($data['receipts_or'].'.pdf', 'I');
    }

    /**
     * __get
     *
     * Enables the use of CI super-global without having to define an extra variable.
     * @access	public
     * @param	$var
     * @return	mixed
     */
    public function __get($var) {
        return get_instance()->$var;
    }

}
