<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Crud_Model extends CI_Model {

    var $name = 'users';
    var $key = 'users_id';

    public function __construct($name = "", $key = "") {
        parent::__construct();
        $this->load->database();
        $this->name = $name;
        if ($key != "") {
            $this->key = $key;
        }
    }
    
    public function getRowWhere($where) {
        $query = $this->db->get_where($this->name, $where);
        return $query->row_array();
    }

   

}
