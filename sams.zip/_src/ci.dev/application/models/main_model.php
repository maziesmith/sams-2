<?php

class Main_model extends CI_Model{


		
	function get_all_participants()
    {	
		$query = $this->db->query("SELECT * FROM participants ORDER BY participants_id DESC");
		return $query->result();
    }
    function get_all_branch()
    {	
		$query = $this->db->query("SELECT * FROM branch ORDER BY branch_id DESC");
		return $query->result();
    }

    function get_all_users()
    {	
		$query = $this->db->query("SELECT * FROM users ORDER BY users_id ASC");
		return $query->result();
    }

    function search_participants($val)
    {	
		$query = $this->db->query("SELECT * FROM participants where participants_nric='".$val."'");
		return $query->result();
    }

    function search_participants_nric($val)
    {	
		$query = $this->db->query("SELECT * FROM participants where participants_id='".$val."'");
		foreach ($query->result() as $row)
		{
	   		$id = $row->participants_nric;
		}	
		return $id;
    }		

    function select_count($val)
    {
    	$query = $this->db->query("SELECT * FROM receipts where participants_id='".$val."'");
		$value = 0;
		foreach ($query->result() as $row)
		{
	   		$value++;
		}	
		return $value;
    }

    function search_username($val)
    {
    	$query1 = $this->db->query("SELECT * FROM users where users_id='".$val."'");
		
		foreach ($query1->result() as $row1)
		{
	   		$fname = $row1->users_fullname;
		}	
		return $fname;
    }

   	function update_or()
    {	
    	if(isset($_GET['or'])):

    		$receipts = $this->main_model->search_or_value($_GET['or']);

    		$data['profile'] = $this->session->userdata('User');
    		date_default_timezone_set("Asia/Singapore"); 

    		$date1 = date('Y-m-d');
		    $date2 = date('h:i a');

		    $query1 = $this->db->query("INSERT INTO  `ssagroup_thereceipt`.`transaction_history` (
			`th_no` ,
			`th_user` ,
			`th_transaction` ,
			`th_date` ,
			`th_time`
			)
			VALUES (
			NULL ,  '".$data['profile']['users_id']."',  'has cancelled OR ( ".$receipts." ).',  '".$date1."',  '".$date2."'
			)");

			$query = $this->db->query("UPDATE receipts set receipts_status='Cancelled' where receipts_id='".$_GET['or']."'");
			return $query->result();
		endif;
    }

    function update_user($special = false)
    {	
    	if(isset($_GET['id'])):

			$data['profile'] = $this->session->userdata('User');
    		date_default_timezone_set("Asia/Singapore"); 

    		$date1 = date('Y-m-d');
		    $date2 = date('h:i a');

		    $query1 = $this->db->query("INSERT INTO  `ssagroup_thereceipt`.`transaction_history` (
			`th_no` ,
			`th_user` ,
			`th_transaction` ,
			`th_date` ,
			`th_time`
			)
			VALUES (
			NULL ,  '".$data['profile']['users_id']."',  'has updated user( ".$_GET['u_uname']." ) information.',  '".$date1."',  '".$date2."'
			)");

			$query = $this->db->query("UPDATE users set users_username='".$_GET['u_uname']."', users_password='".$_GET['u_pass']."', users_email = '".$_GET['u_email']."', users_fullname = '".$_GET['u_fname']."', branch_id='".$_GET['u_branch']."' where users_id='".$_GET['id']."'");
			if($special)
		    {
		        return $query;
		    }
			return $query->result();
		endif;
    }

    function update_pr()
    {	
    	if(isset($_GET['id'])):
    		
    		$data['profile'] = $this->session->userdata('User');
    		date_default_timezone_set("Asia/Singapore"); 

    		$date1 = date('Y-m-d');
		    $date2 = date('h:i a');

		    $query1 = $this->db->query("INSERT INTO  `ssagroup_thereceipt`.`transaction_history` (
			`th_no` ,
			`th_user` ,
			`th_transaction` ,
			`th_date` ,
			`th_time`
			)
			VALUES (
			NULL ,  '".$data['profile']['users_id']."',  'has been edited participant( ".$_GET['p_nric']." ).',  '".$date1."',  '".$date2."'
			)");
    		
			$query = $this->db->query("UPDATE participants set participants_nric='".$_GET['p_nric']."', participants_fullname='".$_GET['p_fname']."', participants_referral='".$_GET['p_ref']."' where participants_id='".$_GET['id']."'");
			return $query->result();		

		else:

			$data['profile'] = $this->session->userdata('User');
    		date_default_timezone_set("Asia/Singapore"); 

    		$date1 = date('Y-m-d');
		    $date2 = date('h:i a');

		    $query1 = $this->db->query("INSERT INTO  `ssagroup_thereceipt`.`transaction_history` (
			`th_no` ,
			`th_user` ,
			`th_transaction` ,
			`th_date` ,
			`th_time`
			)
			VALUES (
			NULL ,  '".$data['profile']['users_id']."',  'has been deleted participant( ".$this->search_participants_nric($_GET['del'])." ).',  '".$date1."',  '".$date2."'
			)");

			$query = $this->db->query("UPDATE participants set participants_status='Inactive' where participants_id='".$_GET['del']."'");
			return $query->result();			
		endif;
    }		

    function search_or()
    {	
    	if(isset($_GET['or'])):
			$query = $this->db->query("SELECT * FROM receipts where receipts_id='".$_GET['or']."'");
			return $query->result();
		endif;
    }

    function search_or_value($data)
    {	
    	
		$query = $this->db->query("SELECT * FROM receipts where receipts_id='".$data."'");
		foreach ($query->result() as $row)
		{
	   		$or = $row->receipts_or;
		}	
		return $or;
		
    }		

    function search_branch($val)
    {	
    	
		$query = $this->db->query("SELECT * FROM branch where branch_id='".$val."'");
		foreach ($query->result() as $row)
		{
	   		$br = $row->branch_name;
		}	
		return $br;
		
    }	

    function search_pr()
    {	
    	if(isset($_GET['id'])):
			$query = $this->db->query("SELECT * FROM participants where participants_id='".$_GET['id']."'");
			return $query->result();
		endif;
    }	

    function search_user()
    {	
    	if(isset($_GET['id'])):
			$query = $this->db->query("SELECT * FROM users where users_id='".$_GET['id']."'");
			return $query->result();
		endif;
    }	

    function view_activity()
    {	
    	if( (isset($_GET['category'])) && (isset($_GET['date_from'])) && (isset($_GET['date_to'])) ):
			
    		if($_GET['category']!="ALL"):
				$query = $this->db->query("SELECT * FROM transaction_history where (th_user='".$_GET['category']."' and th_date BETWEEN '".$_GET['date_from']."' AND '".$_GET['date_to']."')  ORDER BY th_no DESC");
				return $query->result();
			else:
				$query = $this->db->query("SELECT * FROM transaction_history where th_date BETWEEN '".$_GET['date_from']."' AND '".$_GET['date_to']."' ORDER BY th_no DESC");
				return $query->result();
			endif;
		endif;
    }	

    function count_all_receipt()
    {	
    	
		$query = $this->db->query("SELECT * FROM receipts");
		return $query->result();
		
    }

    function count_all_received_receipt()
    {	
    	
		$query = $this->db->query("SELECT * FROM receipts where receipts_status='Received'");
		return $query->result();
		
    }

    function count_all_cancelled_receipt()
    {	
    	
		$query = $this->db->query("SELECT * FROM receipts where receipts_status='Cancelled'");
		return $query->result();
		
    }

    function count_del()
    {	
    	
		$query = $this->db->query("SELECT * FROM participants where participants_status='Inactive'");
		return $query->result();
		
    }

    function count_act()
    {	
    	
		$query = $this->db->query("SELECT * FROM participants where participants_status='Active'");
		return $query->result();
		
    }		

    function search_participant_name($val)
    {	
		$query = $this->db->query("SELECT * FROM participants where participants_id='".$val."'");
		$name = '';
		foreach ($query->result_array() as $row) 
		    {
		        $name = $row['participants_fullname'];
		    }
		return $name;		
    }	

    function all_active_participants()
    {
    	$query = $this->db->query("SELECT * from participants where participants_status='Active'");
		
		$sum_active_participants = 0;

		foreach ($query->result_array() as $row) 
	    {
	        $sum_active_participants++;
   		}		
		return $sum_active_participants;
    }

    function all_users()
    {
    	$query = $this->db->query("SELECT * from users");
		
		$sum_users = 0;

		foreach ($query->result_array() as $row) 
	    {
	        $sum_users++;
   		}		
		return $sum_users;
    }

    function all_main_users()
    {
    	$query = $this->db->query("SELECT * from users INNER JOIN branch on users.branch_id = branch.branch_id where branch_slug='OR'");
		
		$sum_all_users = 0;

		foreach ($query->result_array() as $row) 
	    {
	        $sum_all_users++;
   		}		
		return $sum_all_users;
    }

    function all_branch_users()
    {
    	$query = $this->db->query("SELECT * from users INNER JOIN branch on users.branch_id = branch.branch_id where branch_slug='BR'");
		
		$sum_all_branch = 0;

		foreach ($query->result_array() as $row) 
	    {
	        $sum_all_branch++;
   		}		
		return $sum_all_branch;
    }

    function all_deleted_participants()
    {
    	$query = $this->db->query("SELECT * from participants where participants_status='Inactive'");
		
		$sum_active_participants = 0;

		foreach ($query->result_array() as $row) 
	    {
	        $sum_active_participants++;
   		}		
		return $sum_active_participants;
    }

    function all_received_receipts($all = null)
    {	
    	if($all):
    		$query = $this->db->query("SELECT * from receipts where receipts_status='Received' and users_id = ".$all['users_id']."");
		
			$sum_received = 0;

			foreach ($query->result_array() as $row) 
		    {
		        $sum_received++;
	   		}		
			return $sum_received;	

    	else:

			$query = $this->db->query("SELECT * from receipts where receipts_status='Received'");
			
			$sum_received = 0;

			foreach ($query->result_array() as $row) 
		    {
		        $sum_received++;
	   		}		
			return $sum_received;

		endif;
    }	

    function all_cancelled_receipts($all = null)
    {	
    	if($all):
    		$query = $this->db->query("SELECT * from receipts where receipts_status='Cancelled' and users_id = ".$all['users_id']."");
			
			$sum_cancelled = 0;

			foreach ($query->result_array() as $row) 
		    {
		        $sum_cancelled++;
	   		}			
			return $sum_cancelled;
    	else:
			$query = $this->db->query("SELECT * from receipts where receipts_status='Cancelled'");
			
			$sum_cancelled = 0;

			foreach ($query->result_array() as $row) 
		    {
		        $sum_cancelled++;
	   		}			
			return $sum_cancelled;
		endif;
    }	

   	function all_receipts($all = null)
    {	
    	if($all):
	    	$query = $this->db->query("SELECT * from receipts where users_id = ".$all['users_id']."");
		
			$sum_received = 0;

			foreach ($query->result_array() as $row) 
		    {
		        $sum_received++;
	   		}		
			return $sum_received;

    	else:
			$all_receipts = $this->db->count_all_results("receipts");
			return $all_receipts;
		endif;
    }	 

    function search_receipts($data){

    	$val2 = str_replace("-","/",substr($data, 4));	
    	$val1 = substr($data, 0, 4);
    	$val = $val1.''.$val2;

    	$query = $this->db->query("SELECT * FROM receipts where receipts_or='".$val."'");
		return $query->result();
    }

    function print_receipts($invoice,$data){
    	$val2 = str_replace("-","/",substr($invoice, 4));	
    	$val1 = substr($invoice, 0, 4);
    	$val = $val1.''.$val2;

        $data['profile']['users_id'];

		date_default_timezone_set("Asia/Singapore"); 

		
		$date1 = date('Y-m-d');
	    $date2 = date('h:i a');

	    $query1 = $this->db->query("INSERT INTO  `ssagroup_thereceipt`.`transaction_history` (
		`th_no` ,
		`th_user` ,
		`th_transaction` ,
		`th_date` ,
		`th_time`
		)
		VALUES (
		NULL ,  '".$data['profile']['users_id']."',  'has printed receipt( ".$val." ).',  '".$date1."',  '".$date2."'
		)");
    }

    function get_receipts($data){

    	$val2 = str_replace("-","/",substr($data, 4));	
    	$val1 = substr($data, 0, 4);
    	$val = $val1.''.$val2;
   		
   		$query = $this->db->query("SELECT * FROM receipts where receipts_or='".$val."'");
		
		
		foreach ($query->result() as $row)
		{
	   		$id = $row->receipts_id;
		}

			
			$query3 = $this->db->query("SELECT * FROM receipts_printed where receipts_id=".$row->receipts_id."");
		    
		    if ($query3->num_rows() > 0){
		        $date1 = date('Y-M-d');
		        $date2 = date('h:ia');

		        $data = array(
				   'receipts_id' => $id ,
				   'receipts_print' => 'Copy',
				   'receipts_print_date' => $date1,
				   'receipts_print_time' => $date2
				);

		    	$this->db->insert('receipts_printed', $data);
		    } else {
		    	$date1 = date('Y-M-d');
		    	$date2 = date('h:i a');
		        $data = array(
				   'receipts_id' => $id ,
				   'receipts_print' => 'Original',
				   'receipts_print_date' => $date1,
				   'receipts_print_time' => $date2
				);

		    	$this->db->insert('receipts_printed', $data); 
		    }


		$query = $this->db->get_where('receipts', array('receipts_id' => $id));
        return $query->row_array();

    }


    function recent_receipt($val){
    	$query = $this->db->query("SELECT * from receipts where users_id= ".$val." ORDER BY receipts_id DESC LIMIT 5");
    	return $query->result();
    }

    function top_receipt(){

    	$query = $this->db->query("SELECT users_id, SUM(receipts_amount) AS amount, count(receipts_id) AS count FROM receipts where receipts_status <> 'Cancelled' GROUP BY users_id ORDER BY amount DESC LIMIT 5");
    	return $query->result();
    }

    function my_receipt($val){

    	if($val==1):
    		$query = $this->db->query("SELECT * from receipts where receipts_status <> 'Cancelled'");
	    	
	    	$sum_receipts = 0;

			foreach ($query->result_array() as $row) 
		    {
		        $sum_receipts++;
	   		}

    	else:

	    	$query = $this->db->query("SELECT * from receipts where receipts_status <> 'Cancelled' and users_id= ".$val."");
	    	
	    	$sum_receipts = 0;

			foreach ($query->result_array() as $row) 
		    {
		        $sum_receipts++;
	   		}

   		endif;		

		return $sum_receipts;
    }

    function all_events(){
    	$query = $this->db->query("SELECT distinct(receipts_course_desc) from receipts where receipts_status <> 'Cancelled'");
    	
    	$sum_events = 0;

		foreach ($query->result_array() as $row) 
	    {
	        $sum_events++;
   		}		
		return $sum_events;
    }

    function all_the_participant(){
    	$query = $this->db->query("SELECT * from participants where participants_status <> 'Inactive'");
    	
    	$participants = 0;

		foreach ($query->result_array() as $row) 
	    {
	        $participants++;
   		}		
		return $participants;
    }

    function my_receipt_sale($val){

    	if($val==1):
    		$query = $this->db->query("SELECT * from receipts where receipts_status <> 'Cancelled'");
    	
	    	$sum_receipts_amount = 0;

			foreach ($query->result_array() as $row) 
		    {
		        $sum_receipts_amount += floatval($row['receipts_amount']);
	   		}

    	else:
	    	$query = $this->db->query("SELECT * from receipts where receipts_status <> 'Cancelled' and users_id= ".$val."");
	    	
	    	$sum_receipts_amount = 0;

			foreach ($query->result_array() as $row) 
		    {
		        $sum_receipts_amount += floatval($row['receipts_amount']);
	   		}
   		endif;		
		return $sum_receipts_amount;
    }

    function save_user(){

    	if(isset($_GET['add_fname'])):
	    	date_default_timezone_set("Asia/Singapore"); 
			$date = date('Y-M-d');
			$year = date('Y');
			$month = date('m');
			$day = date('d');

			$query = $this->db->query("SELECT * from users where users_username='".$_GET['add_uname']."'");
		
			if ($query->num_rows() > 0){
				echo $output = "1";
			} else {

				$data['profile'] = $this->session->userdata('User');
	    		date_default_timezone_set("Asia/Singapore"); 

	    		$date1 = date('Y-m-d');
			    $date2 = date('h:i a');

			    $query1 = $this->db->query("INSERT INTO  `ssagroup_thereceipt`.`transaction_history` (
				`th_no` ,
				`th_user` ,
				`th_transaction` ,
				`th_date` ,
				`th_time`
				)
				VALUES (
				NULL ,  '".$data['profile']['users_id']."',  'has added new user( ".$_GET['add_uname']." ).',  '".$date1."',  '".$date2."'
				)");

				$data = array(
					   'users_username' => $_GET['add_uname'],
					   'users_password' => $_GET['add_pass'],
					   'users_email' => $_GET['add_email'],
					   'users_fullname' => $_GET['add_fname'],
					   'branch_id' => $_GET['add_branch']
					);
			   
			   	$this->db->insert('users', $data); 
			   	echo $output = "0";
		    }
	   	endif;
    }

    function add_receipts(){

    	date_default_timezone_set("Asia/Singapore"); 
		$date = date('Y-M-d');
		$year = date('Y');
		$month = date('m');
		$day = date('d');

		$data['profile'] = $this->session->userdata('User');

		
		$query = $this->db->query("SELECT MAX(receipts_id) as ids from receipts");
		
		if ($query->num_rows() > 0)
		{
		   foreach ($query->result() as $row)
		   {
		    	$count = $row->ids + 1;
		   }
		}	else {
			$count = 1;
		}

		$counts = "0";

		if($count<10){
			$counts = '00000'.$count;
		}
		else if(($count<=99) && ($count>=10)){
			$counts = '0000'.$count;
		}
		else if(($count<=999) && ($count>=100)){
			$counts = '000'.$count;
		}	
		else if(($count<=9999) && ($count>=1000)){
			$counts = '00'.$count;
		}

    	$this->db->select('participants_id')->from('participants')->where('participants_nric', $_GET['add_nric']);
		$query2 = $this->db->get();
		foreach ($query2->result() as $row){
			$id = $row->participants_id;
		}

		$this->db->select('branch_id')->from('users')->where('users_id',$data['profile']['users_id']);
		$query = $this->db->get();
		foreach ($query->result() as $row){

			$this->db->select('branch_slug')->from('branch')->where('branch_id',$row->branch_id);
			$query1 = $this->db->get();
			foreach ($query1->result() as $row1){
				$user_loc = $row1->branch_slug;
			}

		}

		if($query2->num_rows == 1){

			$data = array(
			   'receipts_or' => $user_loc.'-'.substr($year, -2).'/'.$month.'/'.$counts ,
			   'participants_id' => $id ,
			   'users_id' => $data['profile']['users_id'],
			   'receipts_trans_type' => $_GET['add_trans_type'],
			   'receipts_ref_no' => $_GET['add_trans_ref_no'],
			   'receipts_course_desc' => $_GET['add_course_desc'],
			   'receipts_amount' => $_GET['add_amount'],
			   'receipts_remarks' => $_GET['add_remarks'],
			   'receipts_date' => $date,
			   'receipts_status' => 'Received'
			);

	    	$this->db->insert('receipts', $data); 
	    	echo $user_loc.'-'.substr($year, -2).'-'.$month.'-'.$counts;
		} else {
			
			$data1 = array(
			   'participants_nric' => $_GET['add_nric'],
			   'participants_fullname' => $_GET['add_fname'],
			   'participants_referral' => $data['profile']['users_fullname'],
			   'participants_date' => $date
			);

			$this->db->insert('participants', $data1); 

			$query3 = $this->db->query("SELECT * from participants ORDER BY participants_id ASC");
			$counter = 1;
			if ($query3->num_rows() > 0)
			{
			   foreach ($query3->result() as $row)
			   {
			      	if($row->participants_id==$counter):
					else:
					break; break;
					endif;
					$counter++;
			   }
			}
			$counter--;

			$data = array(
			   'receipts_or' => $user_loc.'-'.substr($year, -2).'/'.$month.'/'.$counts ,
			   'participants_id' => $counter,
			   'users_id' => $data['profile']['users_id'],
			   'receipts_trans_type' => $_GET['add_trans_type'],
			   'receipts_ref_no' => $_GET['add_trans_ref_no'],
			   'receipts_course_desc' => $_GET['add_course_desc'],
			   'receipts_amount' => $_GET['add_amount'],
			   'receipts_remarks' => $_GET['add_remarks'],
			   'receipts_date' => $date,
			   'receipts_status' => 'Received'
			);

	    	$this->db->insert('receipts', $data); 
	    	echo $user_loc.'-'.substr($year, -2).'-'.$month.'-'.$counts;			

		}

    	$data['profile'] = $this->session->userdata('User');
		date_default_timezone_set("Asia/Singapore"); 
		$receipts = $user_loc.'-'.substr($year, -2).'/'.$month.'/'.$counts;
		$date1 = date('Y-m-d');
	    $date2 = date('h:i a');

	    $query1 = $this->db->query("INSERT INTO  `ssagroup_thereceipt`.`transaction_history` (
		`th_no` ,
		`th_user` ,
		`th_transaction` ,
		`th_date` ,
		`th_time`
		)
		VALUES (
		NULL ,  '".$data['profile']['users_id']."',  'has added new receipt( ".$receipts." ).',  '".$date1."',  '".$date2."'
		)");

    }


}