<?php

/**
 * Description of Sports Model
 *
 * @author Mark
 */
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Users_model extends Crud_model {

    public function __construct() {
        parent::__construct('users', 'users_id');
    }
    
    public function checkUsernameAndPassword($username = false,$password = false){
        return $this->getRowWhere(array('users_username' => $username,'users_password' => $password));
    }
}