<body id="add-user">

        <!-- Aside Start-->
        <aside class="left-panel">

            <!-- brand -->
            <div class="logo text-center">
                <a href="<?php echo base_url(); ?>admin/dashboard" class="logo-expanded">
                    <img src="<?php echo base_url('assets/img/logo3.png'); ?>" alt="logo" style="width:70%">
                    <span class="nav-label">theRECEIPT</span>
                </a>
            </div>
            <!-- / brand -->
        
            <!-- Navbar Start -->
            <nav class="navigation">
            <ul class="list-unstyled">
                <li>
                    <a href="<?php echo base_url(); ?>admin/dashboard"><i class="ion-home"></i> <span class="nav-label">Dashboard</span></a>                        
                </li>
                <li>
                    <a href="<?php echo base_url(); ?>admin/participants"><i class="ion-android-contacts"></i> <span class="nav-label">Participants</span></a>                        
                </li>
                <li class="has-submenu active"><a href="#"><i class="ion-android-social"></i> <span class="nav-label">Users</span></a>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo base_url(); ?>admin/users">All Users</a></li>
                        <li class="active"><a href="#">Add New</a></li>
                        
                    </ul>
                </li>
                <li class="has-submenu"><a href="#"><i class="ion-ios7-printer"></i> <span class="nav-label">Receipts</span></a>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo base_url(); ?>admin/receipts">All Receipts</a></li>
                        <li><a href="<?php echo base_url(); ?>admin/receipts/add">Add New</a></li>
                        
                    </ul>
                </li>
                <li>
                    <a href="<?php echo base_url(); ?>admin/timestamp"><i class="ion-ios7-time"></i> <span class="nav-label">Timestamp</span></a>                        
                </li>
                <li><a href="<?php echo base_url(); ?>admin/myprofile"><i class="ion-gear-a"></i> <span class="nav-label">My Profile</span></a>                       
                </li>
                
            </ul>
        </nav>
                
        </aside>
        <!-- Aside Ends-->


        <!--Main Content Start -->
        <section class="content">
            
            <!-- Header -->
            <header class="top-head container-fluid">
                <button type="button" class="navbar-toggle pull-left">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                
                <!-- Search -->
                <form role="search" class="navbar-left app-search pull-left hidden-xs">
                  <input type="text" placeholder="Search..." class="form-control">
                </form>
                
                
                
                <!-- Right navbar -->
                <ul class="list-inline navbar-right top-menu top-right-menu">  
                    <!-- mesages -->  
                    <li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <i class="fa fa-envelope-o "></i>
                            <span class="badge badge-sm up bg-purple count">4</span>
                        </a>
                        <ul class="dropdown-menu extended fadeInUp animated nicescroll" tabindex="5001">
                            <li>
                                <p>Messages</p>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><img src="<?php echo base_url('assets/img/avatar-2.jpg'); ?>" class="img-circle thumb-sm m-r-15" alt="img"></span>
                                    <span class="block"><strong>John smith</strong></span>
                                    <span class="media-body block">New tasks needs to be done<br><small class="text-muted">10 seconds ago</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><img src="<?php echo base_url('assets/img/avatar-3.jpg'); ?>" class="img-circle thumb-sm m-r-15" alt="img"></span>
                                    <span class="block"><strong>John smith</strong></span>
                                    <span class="media-body block">New tasks needs to be done<br><small class="text-muted">3 minutes ago</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><img src="<?php echo base_url('assets/img/avatar-4.jpg'); ?>" class="img-circle thumb-sm m-r-15" alt="img"></span>
                                    <span class="block"><strong>John smith</strong></span>
                                    <span class="media-body block">New tasks needs to be done<br><small class="text-muted">10 minutes ago</small></span>
                                </a>
                            </li>
                            <li>
                                <p><a href="inbox.html" class="text-right">See all Messages</a></p>
                            </li>
                        </ul>
                    </li>
                    <!-- /messages -->
                    <!-- Notification -->
                    <li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <i class="fa fa-bell-o"></i>
                            <span class="badge badge-sm up bg-pink count">3</span>
                        </a>
                        <ul class="dropdown-menu extended fadeInUp animated nicescroll" tabindex="5002">
                            <li class="noti-header">
                                <p>Notifications</p>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><i class="fa fa-user-plus fa-2x text-info"></i></span>
                                    <span>New user registered<br><small class="text-muted">5 minutes ago</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><i class="fa fa-diamond fa-2x text-primary"></i></span>
                                    <span>Use animate.css<br><small class="text-muted">5 minutes ago</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><i class="fa fa-bell-o fa-2x text-danger"></i></span>
                                    <span>Send project demo files to client<br><small class="text-muted">1 hour ago</small></span>
                                </a>
                            </li>
                            
                            <li>
                                <p><a href="#" class="text-right">See all notifications</a></p>
                            </li>
                        </ul>
                    </li>
                    <!-- /Notification -->

                    <!-- user login dropdown start-->
                    <li class="dropdown text-center">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <img alt="" src="<?php echo base_url('assets/img/avatar-2.jpg'); ?>" class="img-circle profile-img thumb-sm">
                            <span class="username"><?php echo $profile['users_fullname']; ?> </span> <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu extended pro-menu fadeInUp animated" tabindex="5003" style="overflow: hidden; outline: none;">
                            <li><a href="<?php echo base_url(); ?>admin/myprofile"><i class="fa fa-briefcase"></i>Profile</a></li>                 
                            <li><a href="<?php echo base_url(); ?>logout"><i class="fa fa-sign-out"></i> Log Out</a></li>
                        </ul>
                    </li>
                    <!-- user login dropdown end -->       
                </ul>
                <!-- End right navbar -->

            </header>
            <!-- Header Ends -->


            <!-- Page Content Start -->
            <!-- ================== -->

            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title"><?php echo $template['sub_title']; ?></h3> 
                </div>

                

                




                <div class="row">
                    <div class="col-lg-8">
                        <div class="form-holder">
                            <form role="form" id="add_form">

                              

                                
                                <div class="form-group col-sm-6 pad-zero-left">
                                    <label for="add_trans_ref_no">FULLNAME</label>
                                    <input type="text" class="form-control input-lg" id="user_fname" name="user_fname">
                                    <span class="user_fname_error"></span>
                                </div>

                                <div class="form-group col-sm-6 pad-zero-right">
                                    <label for="add_trans_type">BRANCH</label>
                                    <select class="form-control input-lg" id="user_branch" name="user_branch">
                                        <option value="" id="selectnull">Please select a branch</option>
                                        <?php 
                                            foreach($results as $row){
                                                echo "<option value='".$row->branch_id."'>".$row->branch_name."</option>";                                         
                                            }                                  
                                        ?>
                                    </select>
                                    <span class="user_branch_error"></span>
                                </div>

                                <div class="form-group col-sm-6 pad-zero-right pull-right">
                                    <label for="add_trans_ref_no">EMAIL ADDRESS</label>
                                    <input type="text" class="form-control input-lg" id="user_email" name="user_email">
                                    <span class="user_email_error"></span>
                                </div>

                                <div class="form-group col-sm-6 pad-zero-left">
                                    <label for="add_trans_ref_no">USERNAME</label>
                                    <input type="text" class="form-control input-lg" id="user_uname" name="user_pass">
                                    <span class="user_uname_error"></span>                                    
                                </div>
                                <div class="clearfix"></div>

                                <div class="form-group col-sm-6 pad-zero-left">
                                    <label for="add_trans_ref_no">PASSWORD</label>
                                    <input type="password" class="form-control input-lg" id="user_pass" name="user_pass">
                                    <span class="user_pass_error"></span>                                    
                                </div>
                                
                                <div class="form-group col-sm-6 pad-zero-right">
                                    <label for="add_trans_ref_no">RE-PASSWORD</label>
                                    <input type="password" class="form-control input-lg" id="user_repass" name="user_repass">
                                    <span class="user_repass_error"></span>                                       
                                </div>

                                <div class="clearfix"></div>
                                
                                <div class="form-group" style="margin-top:10px">
                                    <button type="button" class="btn btn-info input-lg" id="add_user_button">Add New User</button>
                                </div>

                            
                        </div>
                    </div>

                    <div class="col-lg-4" style="margin-top:27px">
                        
                        <div class="portlet"><!-- /primary heading -->
                            <div class="portlet-heading">
                                <h3 class="portlet-title text-dark text-uppercase">
                                    User Role
                                </h3>
                            </div>
                            <div id="portlet1" class="panel-collapse collapse in">
                                <div class="portlet-body">
                                    <div class="row">                                

                                        <div class="col-sm-12">
                                            <div class="radio">
                                                <label class="cr-styled" for="example-radio1">
                                                    <input type="radio" id="example-radio1" name="user-role" value="admin"> 
                                                    <i class="fa"></i>
                                                    Admin
                                                </label>
                                            </div>
                                            <div class="radio">
                                                <label class="cr-styled" for="example-radio2">
                                                    <input type="radio" id="example-radio2" name="user-role" value="user"> 
                                                    <i class="fa"></i>
                                                    User
                                                </label>
                                            </div>
                                           
                                            <div class="col-sm-12">
                                                <span class="user_role_error"></span>
                                                <p>
                                                Please select a role for the user to be register.
                                                </p>
                                            </div>    
                                            
                                        </div><div class="clearfix"></div>                                        

                                    </div>                              
                                </div>
                                </form><!--end form-->
                            </div>
                        </div> <!-- /Portlet -->

                    </div> <!-- end col -->

                    
                </div> <!-- End row -->

            </div>
            <!-- Page Content Ends -->
            <!-- ================== -->

            <!-- Footer Start -->
            <footer class="footer">
                2015 © theRECEIPT SSA Consulting Group Pte. Ltd.
            </footer>
            <!-- Footer Ends -->



        </section>
        <!-- Main Content Ends -->
        
        