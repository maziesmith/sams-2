<?php

if($_GET['page'])
{
$page = $_GET['page'];
$cur_page = $page;
$page -= 1;
date_default_timezone_set("Asia/Singapore"); 
$date = date('Y-m-d h:i:s');
$per_page = 5;
$previous_btn = true;
$next_btn = true;
$value = 0;
$first_btn = true;
$pagess = 0;
$last_btn = true;
$start = $page * $per_page;

$msg = '
<table class="table table-hover table-striped">
<thead>
<tr>
<th width="2%">
    <label class="cr-styled">
    <input type="checkbox">
    <i class="fa"></i>       
    </label>                              
</th>
<th width="15%">Username</th>
<th width="20%">Email Address</th>
<th width="20%">Name</th>
<th width="15%">Branch</th>
<th width="15%">Date Register</th>
</tr>
</thead>
';


    if(isset($_GET['value'])){


        $query1 = $this->db->query("SELECT * FROM users INNER JOIN branch on users.branch_id = branch.branch_id where (users_username like '%".$_GET['value']."%' and branch_slug = 'OR')  or (users_email like '%".$_GET['value']."%' and branch_slug = 'OR') or (users_fullname like '%".$_GET['value']."%' and branch_slug = 'OR')  or (users_date_created like '%".$_GET['value']."%' and branch_slug = 'OR') ORDER BY users_id ASC LIMIT $start, $per_page");
        

        if($query1->num_rows > 0){

        foreach ($query1->result() as $row){

        if($row->branch_slug == "OR"):
            $branch = "Main";
        else:
            $branch = "Branch";
        endif;

       
        $msg .='<tr>
                <td>
                    <label class="cr-styled">
                    <input type="checkbox">
                    <i class="fa"></i>       
                    </label>                              
                    </td>
                <td id="record-'.$row->users_id.'">
                    '.$row->users_username.'
                    <p class="options">
                    
                    <a href="javascript:;;" class="text-info md-trigger edit-user-modal" data-modal="edit-user-modal">
                    edit
                    </a>
                    
                    </p>
                </td>
                <td>
                    '.$row->users_email.'
                </td>
                <td>
                    '.$row->users_fullname.'
                </td>
                <td>
                    '.$branch.'
                </td>
                          
                <td>
                '.date('Y/m/d',strtotime($row->users_date_created)).'
               
                </td>
                </tr>';

            }
       
        $msg .= '
        
        <thead>
        <tr>
        <th width="2%">
            <label class="cr-styled">
            <input type="checkbox">
            <i class="fa"></i>       
            </label>                              
        </th>
        <th width="15%">Username</th>
        <th width="8%">Email Address</th>
        <th width="15%">Name</th>
        <th width="25%">Branch</th>
        <th width="10%">Date Register</th>
        </tr>
        </thead>
        </table>
        ';    

        $query_pag_num = "SELECT COUNT(users_id) AS count FROM users INNER JOIN branch on users.branch_id = branch.branch_id where (users_username like '%".$_GET['value']."%' and branch_slug = 'OR')  or (users_email like '%".$_GET['value']."%' and branch_slug = 'OR') or (users_fullname like '%".$_GET['value']."%' and branch_slug = 'OR')  or (users_date_created like '%".$_GET['value']."%' and branch_slug = 'OR')";

        $result_pag_num = mysql_query($query_pag_num);
        $row = mysql_fetch_array($result_pag_num);
        $count = $row['count'];

        $no_of_paginations = ceil($count / $per_page);

        /* ---------------Calculating the starting and endign values for the loop----------------------------------- */
        if ($cur_page >= 5) {
        $start_loop = $cur_page - 3;
        if ($no_of_paginations > $cur_page + 3)
        $end_loop = $cur_page + 3;
        else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 4) {
        $start_loop = $no_of_paginations - 4;
        $end_loop = $no_of_paginations;
        } else {
        $end_loop = $no_of_paginations;
        }
        } else {
        $start_loop = 1;
        if ($no_of_paginations > 5)
        $end_loop = 5;
        else
        $end_loop = $no_of_paginations;
        }
        /* ----------------------------------------------------------------------------------------------------------- */


        $msg .='
            <div class="row">
            <div class="col-sm-7 action-holder">
            <label class="pull-left control-label pad-zero">
                <select class="form-control bulk-options">
                    <option value="">Bulk Actions</option>
                    <option value="Edit">Edit</option>
                    <option value="Cancel">Cancel</option>
                </select>
            </label>
            <div class="pull-left">
                <button type="button" class="btn btn-default apply-options">Apply</button>
            </div>
            <label class="pull-left control-label pad-zero">
                <select class="form-control bulk-options">
                    <option value="">Export as</option>
                    <option value="CSV">Export as CSV</option>
                    <option value="XLS">Export as XLS</option>
                    <option value="PDF">Export as PDF</option>
                    <option value="SQL">Export as SQL</option>
                </select>
            </label>
            <div class="pull-left">
                <button type="button" class="btn btn-default apply-options">Export</button>
            </div>                                             
        </div>';


        $msg .= "<div class='col-sm-5'><ul class='pull-right pagination'>";

        // FOR ENABLING THE PREVIOUS BUTTON
        if ($previous_btn && $cur_page > 1) {
        $pre = $cur_page - 1;

        $msg .= "<li p='$pre' class='ping'><a href='javascript:;'>&laquo;</a></li>";
        } else if ($previous_btn) {
        $msg .= "<li class='active'><a href='javascript:;'>&laquo;</a></li>";
        }
        for ($i = $start_loop; $i <= $end_loop; $i++) {

        if ($cur_page == $i)
        $msg .= "<li p='$i' style='color:#fff;background-color:#006699;' class='active ping'><a href='javascript:;'>{$i}</a></li>";
        else
        $msg .= "<li p='$i' class='ping'><a href='javascript:;'>{$i}</a></li>";
        }

        // TO ENABLE THE NEXT BUTTON
        if ($next_btn && $cur_page < $no_of_paginations) {
        $nex = $cur_page + 1;
        $msg .= "<li p='$nex' class='ping'><a href='javascript:;'>&raquo;</a></li>";
        } else if ($next_btn) {
        $msg .= "<li class='active'><a href='javascript:;'>&raquo;</a></li>";
        }

        $msg .= "</ul><em class='pull-right text-right all-item'>".$count." items</em></div><div class='clearfix'></div></div>";




        $msg1 ='
            <div class="row">
            <div class="col-sm-7 action-holder">
            <label class="pull-left control-label pad-zero">
                <select class="form-control bulk-options">
                    <option value="">Bulk Actions</option>
                    <option value="Edit">Edit</option>
                    <option value="Cancel">Cancel</option>
                </select>
            </label>
            <div class="pull-left">
                <button type="button" class="btn btn-default apply-options">Apply</button>
            </div>
            <label class="pull-left control-label pad-zero">
                <select class="form-control bulk-options">
                    <option value="">Export as</option>
                    <option value="CSV">Export as CSV</option>
                    <option value="XLS">Export as XLS</option>
                    <option value="PDF">Export as PDF</option>
                    <option value="SQL">Export as SQL</option>
                </select>
            </label>
            <div class="pull-left">
                <button type="button" class="btn btn-default apply-options">Export</button>
            </div>                                             
        </div>';

        $msg1 .= "<div class='col-sm-5'><ul class='pull-right pagination'>";

        // FOR ENABLING THE PREVIOUS BUTTON
        if ($previous_btn && $cur_page > 1) {
        $pre = $cur_page - 1;

        $msg1 .= "<li p='$pre' class='ping'><a href='javascript:;'>&laquo;</a></li>";
        } else if ($previous_btn) {
        $msg1 .= "<li class='active'><a href='javascript:;'>&laquo;</a></li>";
        }
        for ($i = $start_loop; $i <= $end_loop; $i++) {

        if ($cur_page == $i)
        $msg1 .= "<li p='$i' style='color:#fff;background-color:#006699;' class='active ping'><a href='javascript:;'>{$i}</a></li>";
        else
        $msg1 .= "<li p='$i' class='ping'><a href='javascript:;'>{$i}</a></li>";
        }

        // TO ENABLE THE NEXT BUTTON
        if ($next_btn && $cur_page < $no_of_paginations) {
        $nex = $cur_page + 1;
        $msg1 .= "<li p='$nex' class='ping'><a href='javascript:;'>&raquo;</a></li>";
        } else if ($next_btn) {
        $msg1 .= "<li class='active'><a href='javascript:;'>&raquo;</a></li>";
        }

        $msg1 .= "</ul><em class='pull-right text-right all-item'>".$count." items</em></div><div class='clearfix'></div></div>";


        echo $msg1.$msg;

        } else {
            echo "There are no records found.";
        }
    } //if value close
    else {
    $query1 = $this->db->query("SELECT * FROM users INNER JOIN branch on users.branch_id = branch.branch_id where branch_slug='OR' ORDER BY users_id ASC LIMIT $start, $per_page");

        if($query1->num_rows > 0){

        foreach ($query1->result() as $row){

        /*$val2 = str_replace("/","-",substr($row->receipts_or, 4));  
        $val1 = substr($row->receipts_or, 0, 4);
        $val = $val1.''.$val2;    */

        if($row->branch_slug == "OR"):
            $branch = "Main";
        else:
            $branch = "Branch";
        endif;

       
        $msg .='<tr>
                <td>
                    <label class="cr-styled">
                    <input type="checkbox">
                    <i class="fa"></i>       
                    </label>                              
                    </td>
                <td id="record-'.$row->users_id.'">
                    '.$row->users_username.'
                    <p class="options">
                    
                    <a href="javascript:;;" class="text-info md-trigger edit-user-modal" data-modal="edit-user-modal">
                    edit
                    </a>
                    
                    </p>
                </td>
                <td>
                    '.$row->users_email.'
                </td>
                <td>
                    '.$row->users_fullname.'
                </td>
                <td>
                    '.$branch.'
                </td>
                          
                <td>
                '.date('Y/m/d',strtotime($row->users_date_created)).'
               
                </td>
                </tr>';

            }
       
        $msg .= '
        
        <thead>
        <tr>
        <th width="2%">
            <label class="cr-styled">
            <input type="checkbox">
            <i class="fa"></i>       
            </label>                              
        </th>
        <th width="15%">Username</th>
        <th width="8%">Email Address</th>
        <th width="15%">Name</th>
        <th width="25%">Branch</th>
        <th width="10%">Date Register</th>
        </tr>
        </thead>
        </table>
        ';    

        $query_pag_num = "SELECT COUNT(users_id) AS count FROM users INNER JOIN branch on users.branch_id = branch.branch_id where branch_slug='OR'";

        $result_pag_num = mysql_query($query_pag_num);
        $row = mysql_fetch_array($result_pag_num);
        $count = $row['count'];

        $no_of_paginations = ceil($count / $per_page);

        /* ---------------Calculating the starting and endign values for the loop----------------------------------- */
        if ($cur_page >= 5) {
        $start_loop = $cur_page - 3;
        if ($no_of_paginations > $cur_page + 3)
        $end_loop = $cur_page + 3;
        else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 4) {
        $start_loop = $no_of_paginations - 4;
        $end_loop = $no_of_paginations;
        } else {
        $end_loop = $no_of_paginations;
        }
        } else {
        $start_loop = 1;
        if ($no_of_paginations > 5)
        $end_loop = 5;
        else
        $end_loop = $no_of_paginations;
        }
        /* ----------------------------------------------------------------------------------------------------------- */


        $msg .='
            <div class="row">
            <div class="col-sm-7 action-holder">
            <label class="pull-left control-label pad-zero">
                <select class="form-control bulk-options">
                    <option value="">Bulk Actions</option>
                    <option value="Edit">Edit</option>
                    <option value="Cancel">Cancel</option>
                </select>
            </label>
            <div class="pull-left">
                <button type="button" class="btn btn-default apply-options">Apply</button>
            </div>
            <label class="pull-left control-label pad-zero">
                <select class="form-control bulk-options">
                    <option value="">Export as</option>
                    <option value="CSV">Export as CSV</option>
                    <option value="XLS">Export as XLS</option>
                    <option value="PDF">Export as PDF</option>
                    <option value="SQL">Export as SQL</option>
                </select>
            </label>
            <div class="pull-left">
                <button type="button" class="btn btn-default apply-options">Export</button>
            </div>                                             
        </div>';


        $msg .= "<div class='col-sm-5'><ul class='pull-right pagination'>";

        // FOR ENABLING THE PREVIOUS BUTTON
        if ($previous_btn && $cur_page > 1) {
        $pre = $cur_page - 1;

        $msg .= "<li p='$pre' class='ping'><a href='javascript:;'>&laquo;</a></li>";
        } else if ($previous_btn) {
        $msg .= "<li class='active'><a href='javascript:;'>&laquo;</a></li>";
        }
        for ($i = $start_loop; $i <= $end_loop; $i++) {

        if ($cur_page == $i)
        $msg .= "<li p='$i' style='color:#fff;background-color:#006699;' class='active ping'><a href='javascript:;'>{$i}</a></li>";
        else
        $msg .= "<li p='$i' class='ping'><a href='javascript:;'>{$i}</a></li>";
        }

        // TO ENABLE THE NEXT BUTTON
        if ($next_btn && $cur_page < $no_of_paginations) {
        $nex = $cur_page + 1;
        $msg .= "<li p='$nex' class='ping'><a href='javascript:;'>&raquo;</a></li>";
        } else if ($next_btn) {
        $msg .= "<li class='active'><a href='javascript:;'>&raquo;</a></li>";
        }

        $msg .= "</ul><em class='pull-right text-right all-item'>".$count." items</em></div><div class='clearfix'></div></div>";




        $msg1 ='
            <div class="row">
            <div class="col-sm-7 action-holder">
            <label class="pull-left control-label pad-zero">
                <select class="form-control bulk-options">
                    <option value="">Bulk Actions</option>
                    <option value="Edit">Edit</option>
                    <option value="Cancel">Cancel</option>
                </select>
            </label>
            <div class="pull-left">
                <button type="button" class="btn btn-default apply-options">Apply</button>
            </div>
            <label class="pull-left control-label pad-zero">
                <select class="form-control bulk-options">
                    <option value="">Export as</option>
                    <option value="CSV">Export as CSV</option>
                    <option value="XLS">Export as XLS</option>
                    <option value="PDF">Export as PDF</option>
                    <option value="SQL">Export as SQL</option>
                </select>
            </label>
            <div class="pull-left">
                <button type="button" class="btn btn-default apply-options">Export</button>
            </div>                                             
        </div>';

        $msg1 .= "<div class='col-sm-5'><ul class='pull-right pagination'>";

        // FOR ENABLING THE PREVIOUS BUTTON
        if ($previous_btn && $cur_page > 1) {
        $pre = $cur_page - 1;

        $msg1 .= "<li p='$pre' class='ping'><a href='javascript:;'>&laquo;</a></li>";
        } else if ($previous_btn) {
        $msg1 .= "<li class='active'><a href='javascript:;'>&laquo;</a></li>";
        }
        for ($i = $start_loop; $i <= $end_loop; $i++) {

        if ($cur_page == $i)
        $msg1 .= "<li p='$i' style='color:#fff;background-color:#006699;' class='active ping'><a href='javascript:;'>{$i}</a></li>";
        else
        $msg1 .= "<li p='$i' class='ping'><a href='javascript:;'>{$i}</a></li>";
        }

        // TO ENABLE THE NEXT BUTTON
        if ($next_btn && $cur_page < $no_of_paginations) {
        $nex = $cur_page + 1;
        $msg1 .= "<li p='$nex' class='ping'><a href='javascript:;'>&raquo;</a></li>";
        } else if ($next_btn) {
        $msg1 .= "<li class='active'><a href='javascript:;'>&raquo;</a></li>";
        }

        $msg1 .= "</ul><em class='pull-right text-right all-item'>".$count." items</em></div><div class='clearfix'></div></div>";


        echo $msg1.$msg;

        } else {
            echo "There are no records found.";
        }
    }//else value close
}

?>

