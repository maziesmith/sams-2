

<?php

$db_username = 'root';
$db_password = 'root';
$db_name = 'ssagroup_thereceipt';
$db_host = 'localhost';
$items_per_group = 5;

$mysqli = new mysqli($db_host, $db_username, $db_password, $db_name);
//Output any connection error
if ($mysqli->connect_error) {
    die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
}

if($_POST)
{
	//sanitize post value
	$group_number = filter_var($_POST["group_no"], FILTER_SANITIZE_NUMBER_INT, FILTER_FLAG_STRIP_HIGH);
	
	//throw HTTP error if group number is not valid
	if(!is_numeric($group_number)){
		header('HTTP/1.1 500 Invalid number!');
		exit();
	}
	
	//get current starting point of records
	$position = ($group_number * $items_per_group);
	
	
	//Limit our results within a specified range. 


	$results = $mysqli->prepare("SELECT th_user, th_transaction, th_date, th_time FROM transaction_history ORDER BY th_no DESC LIMIT $position, $items_per_group");
	$results->execute(); //Execute prepared Query
	$results->bind_result($th_user, $th_transaction, $th_date, $th_time); //bind variables to prepared statement

	$this->load->helper('date');
	$format = 'DATE_ATOM';
	while($results->fetch()){ //fetch values
	//$myDateTime = DateTime::createFromFormat('Y-m-d', $th_date.' '.$th_time);
	//$newDateString = $myDateTime->format('M d, Y at h:i a');

             // returns Saturday, January 30 10 02:06:34

	//echo standard_date($format, $th_date.' '.$th_time); 
	

	$datetime = standard_date($format, strtotime($th_date.' '.$th_time)); 

	$date = strtotime($th_date.' '.$th_time);
	$new_date = date("F d, Y",$date);

		echo '
		<div class="time-item">
		    <div class="item-info">
		        <div class="text-muted"><time title="'.$datetime.'" datetime="'.$datetime.'">'.$new_date.' '.$th_time.'</time></div>
		        <p><strong><a href="#" class="text-info">'.$this->main_model->search_username($th_user).'</a></strong> '.$th_transaction.'</p>
		    </div>
		</div>';
		
	}


	$mysqli->close();
}
?>