<?php 
	
	$value_act=0;
	foreach($results as $row){	
		$value_act++;
	}   
	$arr = array (
		'value_act'=>$value_act	
		);
	
	header('Content-Type: application/json');
    echo json_encode( $arr );
?>