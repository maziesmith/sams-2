<?php 
	
	$value_del=0;
	foreach($results as $row){	
		$value_del++;
	}   
	$arr = array (
		'value_all_cancelled'=>$value_del	
		);
	
	header('Content-Type: application/json');
    echo json_encode( $arr );
?>