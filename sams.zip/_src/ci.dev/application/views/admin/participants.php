<body id="participants">

        <!-- Aside Start-->
        <aside class="left-panel">

            <!-- brand -->
            <div class="logo text-center">
                <a href="<?php echo base_url(); ?>admin/dashboard" class="logo-expanded">
                    <img src="<?php echo base_url('assets/img/logo3.png'); ?>" alt="logo" style="width:70%">
                    <span class="nav-label">theRECEIPT</span>
                </a>
            </div>
            <!-- / brand -->
        
            <!-- Navbar Start -->
            <nav class="navigation">
                <ul class="list-unstyled">
                    <li>
                        <a href="<?php echo base_url(); ?>admin/dashboard"><i class="ion-home"></i> <span class="nav-label">Dashboard</span></a>                        
                    </li>
                    <li class="active">
                        <a href="#"><i class="ion-android-contacts"></i> <span class="nav-label">Participants</span></a>                        
                    </li>
                    <li class="has-submenu"><a href="#"><i class="ion-android-social"></i> <span class="nav-label">Users</span></a>
                        <ul class="list-unstyled">
                            <li><a href="<?php echo base_url(); ?>admin/users">All Users</a></li>
                            <li><a href="<?php echo base_url(); ?>admin/users/add">Add New</a></li>
                            
                        </ul>
                    </li>
                    <li class="has-submenu"><a href="#"><i class="ion-ios7-printer"></i> <span class="nav-label">Receipts</span></a>
                        <ul class="list-unstyled">
                            <li><a href="<?php echo base_url(); ?>admin/receipts">All Receipts</a></li>
                            <li><a href="<?php echo base_url(); ?>admin/receipts/add">Add New</a></li>
                            
                        </ul>
                    </li>
                    <li>
                        <a href="<?php echo base_url(); ?>admin/timestamp"><i class="ion-ios7-time"></i> <span class="nav-label">Timestamp</span></a>                        
                    </li>
                    <li><a href="<?php echo base_url(); ?>admin/myprofile"><i class="ion-gear-a"></i> <span class="nav-label">My Profile</span></a>                       
                    </li>
                    
                </ul>
            </nav>
                
        </aside>
        <!-- Aside Ends-->


        <!--Main Content Start -->
        <section class="content">
            
            <!-- Header -->
            <header class="top-head container-fluid">
                <button type="button" class="navbar-toggle pull-left">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                
                <!-- Search -->
                <form role="search" class="navbar-left app-search pull-left hidden-xs">
                  <input type="text" placeholder="Search..." class="form-control">
                </form>
                
                
                
                <!-- Right navbar -->
                <ul class="list-inline navbar-right top-menu top-right-menu">  
                    <!-- mesages -->  
                    <li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <i class="fa fa-envelope-o "></i>
                            <span class="badge badge-sm up bg-purple count">4</span>
                        </a>
                        <ul class="dropdown-menu extended fadeInUp animated nicescroll" tabindex="5001">
                            <li>
                                <p>Messages</p>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><img src="<?php echo base_url('assets/img/avatar-2.jpg'); ?>" class="img-circle thumb-sm m-r-15" alt="img"></span>
                                    <span class="block"><strong>John smith</strong></span>
                                    <span class="media-body block">New tasks needs to be done<br><small class="text-muted">10 seconds ago</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><img src="<?php echo base_url('assets/img/avatar-3.jpg'); ?>" class="img-circle thumb-sm m-r-15" alt="img"></span>
                                    <span class="block"><strong>John smith</strong></span>
                                    <span class="media-body block">New tasks needs to be done<br><small class="text-muted">3 minutes ago</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><img src="<?php echo base_url('assets/img/avatar-4.jpg'); ?>" class="img-circle thumb-sm m-r-15" alt="img"></span>
                                    <span class="block"><strong>John smith</strong></span>
                                    <span class="media-body block">New tasks needs to be done<br><small class="text-muted">10 minutes ago</small></span>
                                </a>
                            </li>
                            <li>
                                <p><a href="inbox.html" class="text-right">See all Messages</a></p>
                            </li>
                        </ul>
                    </li>
                    <!-- /messages -->
                    <!-- Notification -->
                    <li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <i class="fa fa-bell-o"></i>
                            <span class="badge badge-sm up bg-pink count">3</span>
                        </a>
                        <ul class="dropdown-menu extended fadeInUp animated nicescroll" tabindex="5002">
                            <li class="noti-header">
                                <p>Notifications</p>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><i class="fa fa-user-plus fa-2x text-info"></i></span>
                                    <span>New user registered<br><small class="text-muted">5 minutes ago</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><i class="fa fa-diamond fa-2x text-primary"></i></span>
                                    <span>Use animate.css<br><small class="text-muted">5 minutes ago</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><i class="fa fa-bell-o fa-2x text-danger"></i></span>
                                    <span>Send project demo files to client<br><small class="text-muted">1 hour ago</small></span>
                                </a>
                            </li>
                            
                            <li>
                                <p><a href="#" class="text-right">See all notifications</a></p>
                            </li>
                        </ul>
                    </li>
                    <!-- /Notification -->

                    <!-- user login dropdown start-->
                    <li class="dropdown text-center">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <img alt="" src="<?php echo base_url('assets/img/avatar-2.jpg'); ?>" class="img-circle profile-img thumb-sm">
                            <span class="username"><?php echo $profile['users_fullname']; ?> </span> <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu extended pro-menu fadeInUp animated" tabindex="5003" style="overflow: hidden; outline: none;">
                            <li><a href="<?php echo base_url(); ?>admin/myprofile"><i class="fa fa-briefcase"></i>Profile</a></li>                 
                            <li><a href="<?php echo base_url(); ?>logout"><i class="fa fa-sign-out"></i> Log Out</a></li>
                        </ul>
                    </li>
                    <!-- user login dropdown end -->       
                </ul>
                <!-- End right navbar -->

            </header>
            <!-- Header Ends -->


            <!-- Page Content Start -->
            <!-- ================== -->

            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">All Participants</h3> 
                </div>

                

                




                <div class="row">
                        
                        <div class="col-lg-12">
                            <div class="prog-search-holder">
                                <div class="col-sm-6 pad-zero-left">
                                    <ul class="nav nav-tabs tab-actions" role="tablist">
                                        <li role="act-tab" class="active">
                                            <a href="#act-holder-participants" role="tab" data-toggle="tab">
                                                <span class="text-info">Active</span> (<co><?php echo $this->main_model->all_active_participants(); ?></co>)
                                            </a>
                                        </li>
                                        <li role="del-tab">
                                            <a href="#del-holder-participants" role="tab" data-toggle="tab">
                                                <span class="text-info">Deleted</span> (<co><?php echo $this->main_model->all_deleted_participants(); ?></co>)
                                            </a>
                                        </li>                                   
                                    </ul>       
                                </div>
                                <div class="col-sm-6 pad-zero-right">
                                    <div class="form-group">
                                        <label class="col-md-6 control-label pad-zero-right">
                                             <input type="text" class="form-control" id="prog_searchs" name="prog_searchs">
                                        </label>
                                        <div class="col-md-6 pad-zero-right">
                                            <button type="button" class="btn btn-default btn-searchz ">Search Participants</button>
                                        </div>
                                    </div>
                                </div><div class="clearfix"></div>
                            </div>
                        </div>

                    <div class="tab-content">
                    
                        <div role="tabpanel" class="col-lg-12 tab-pane fade in active" id="act-holder-participants">
                        
                            <div class="portlet"><!-- /primary heading -->
                                <div class="portlet-heading">
                                    <h3 class="portlet-title text-dark text-uppercase">
                                        All Active Participants
                                    </h3>
                                    <div class="portlet-widgets">
                                        <a href="javascript:;" data-toggle="reload"><i class="ion-refresh"></i></a>
                                        <span class="divider"></span>
                                        <a data-toggle="collapse" data-parent="#accordion1" href="#portlet1"><i class="ion-minus-round"></i></a>                            
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                                <div id="portlet1" class="panel-collapse collapse in">
                                    <div class="portlet-body">
                                        <div class="row">   
                                            <div class="col-sm-12">
                                                <div id="containers-all-part" class="col-sm-12 table-responsive">
                                                    <div class="data"></div>                                      
                                                </div>                                                
                                            </div><div class="clearfix"></div>                                  
                                        </div>                              
                                    </div>
                                </div>
                            </div> <!-- /Portlet -->

                        </div> <!-- end col -->


                        <div role="tabpanel" class="col-lg-12 tab-pane fade" id="del-holder-participants">

                            

                            <div class="portlet"><!-- /primary heading -->
                                <div class="portlet-heading">
                                    <h3 class="portlet-title text-dark text-uppercase">
                                        All Deleted Participants
                                    </h3>
                                    <div class="portlet-widgets">
                                        <a href="javascript:;" data-toggle="reload"><i class="ion-refresh"></i></a>
                                        <span class="divider"></span>
                                        <a data-toggle="collapse" data-parent="#accordion1" href="#portlet1"><i class="ion-minus-round"></i></a>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                                <div id="portlet1" class="panel-collapse collapse in">
                                    <div class="portlet-body">
                                        <div class="row">   
                                            <div class="col-sm-12">
                                                <div id="containers-all-del-part" class="col-sm-12 table-responsive">
                                                    <div class="data"></div>                                      
                                                </div>                                                
                                            </div><div class="clearfix"></div>  
                                           
                                        </div>                              
                                    </div>
                                </div>
                            </div> <!-- /Portlet -->

                        </div> <!-- end col -->

                    </div><!--tab content-->

                    
                </div> <!-- End row -->

            </div>
            <!-- Page Content Ends -->
            <!-- ================== -->

            <!-- Footer Start -->
            <footer class="footer">
                2015 © theRECEIPT SSA Consulting Group Pte. Ltd.
            </footer>
            <!-- Footer Ends -->



        </section>
        <!-- Main Content Ends -->


        <div class="md-modal md-effect-14" id="edit-part-modal">
            <div class="md-content">
                <h3>Edit <strong>(<span id="p_id"></span>)</strong> <br>
                <span class="text-info">PARTICIPANT(<ids id="p_nrics"></ids>)</span></h3>
                <div class="transaction-content">                   
                    <div class="form-group">
                        <label for="prog_slug">NRIC/FIN/PASSPORT</label>
                        <input type="text" class="form-control" id="p_nric" name="p_nric">
                        
                    </div>
                    <div class="form-group">
                        <label for="prog_slug">FULLNAME</label>
                        <input type="text" class="form-control" id="p_fname" name="p_fname">
                        
                    </div>
                    
                    <div class="form-group">
                        <label for="prog_slug">REFERRAL</label>
                        <input type="text" class="form-control" id="p_ref" name="p_ref">
                        
                    </div>
                    <span class="pull-left text-center" style="width:100%;margin:0">
                    <h3 style="margin:0">Do you wish to update this participant?</h3>
                    <button class="md-close btn-info btns yes-edit">Yes</button>
                    <button class="btn-danger btns nifty-close">No</button>
                    </span><div class="clearfix"></div>
                </div>
            </div>
        </div>

        <div class="md-modal md-effect-14" id="del-part-modal">
            <div class="md-content">
                <h3>Delete <strong>(<span id="pd_id"></span>)</strong> <br>
                <span class="text-info">PARTICIPANT(<ids id="pd_nrics"></ids>)</span></h3>
                <div class="transaction-content">                   
                    <p>
                        <strong>NRIC/FIN/PASSPORT </strong>: &nbsp;  <span id="pd_nric">Cash</span><br/>                  
                        <strong>FULLNAME </strong>: &nbsp;  <span id="pd_fname">0</span><br/>
                        <strong>REFERRED BY </strong>: &nbsp;  <span id="pd_ref">Duis autem vel eum iriure dolor in hendrerit in </span><br/>
                    </p> 

                    <span class="pull-left text-center" style="width:100%;margin:0">
                    <h3 style="margin:0">Do you wish to delete this participant?</h3>
                    <button class="md-close btn-info btns yes-delete">Yes</button>
                    <button class="btn-danger btns nifty-close">No</button>
                    </span><div class="clearfix"></div>
                </div>
            </div>
        </div>

        <div class="md-overlay"></div><!-- the overlay element -->