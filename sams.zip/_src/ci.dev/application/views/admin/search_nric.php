<?php 
	foreach($results as $row){	
		$arr = array (
		'p_nric'=>$row->participants_nric,
		'p_fname'=>$row->participants_fullname);
	}   
	header('Content-Type: application/json');
    echo json_encode( $arr );
?>