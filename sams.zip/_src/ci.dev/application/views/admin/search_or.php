<?php 
	foreach($results as $row){	
		$arr = array (
		'r_id'=>$row->receipts_id,
		'r_or'=>$row->receipts_or,
		'r_nric'=>$this->main_model->search_participants_nric($row->participants_id),
		'r_trans'=>$row->receipts_trans_type,
		'r_ref'=>$row->receipts_ref_no,
		'r_course'=>$row->receipts_course_desc,
		'r_remarks'=>$row->receipts_remarks,
		'r_amount'=>$row->receipts_amount,
		);
	}   
	header('Content-Type: application/json');
    echo json_encode( $arr );
?>