<?php 
	foreach($results as $row){	
		$arr = array (
		'p_id'=>$row->participants_id,
		'p_nric'=>$row->participants_nric,
		'p_fname'=>$row->participants_fullname,
		'p_ref'=>$row->participants_referral
		
		);
	}   
	header('Content-Type: application/json');
    echo json_encode( $arr );
?>