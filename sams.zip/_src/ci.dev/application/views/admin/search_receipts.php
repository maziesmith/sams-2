<?php

if($_GET['page'])
{
$page = $_GET['page'];
$cur_page = $page;
$page -= 1;
date_default_timezone_set("Asia/Singapore"); 
$date = date('Y-m-d h:i:s');
$per_page = 3;
$previous_btn = true;
$next_btn = true;
$value = 0;
$first_btn = true;
$pagess = 0;
$last_btn = true;
$start = $page * $per_page;

$msg = "
<table class='table table-hover table-striped'>
<thead>
<tr>                               
<th style='width:60%'>OR No.</th>
<th>Date</th>
</tr>
</thead>
";


if(isset($_GET['nric'])):

$query3 = $this->db->query("SELECT * FROM participants where participants_nric='".$_GET['nric']."'");
    
    if( $this->db->_error_message()  ){
        echo 'There are no records found.';    
    } else {

        if($query3->num_rows > 0){

            foreach ($query3->result() as $row3){
                $id = $row3->participants_id;
            }

            $query1 = $this->db->query("SELECT * FROM receipts where participants_id = ".$id." ORDER BY receipts_id ASC LIMIT $start, $per_page");

            if($query1->num_rows > 0){
                  
            foreach ($query1->result() as $row){
                $msg .="<tr><td>".$row->receipts_or."
                <p class='options'>            
                <a href='javascript:;;' class='text-info md-trigger' data-modal='edit-modal'>
                edit
                </a>
                <a href='javascript:;;' class='text-danger md-trigger' data-modal='delete-modal'>
                cancel
                </a>
                <a href='invoice/".str_replace("/", '-',$row->receipts_or)."' target='_blank' class='text-warning'>
                view
                </a>
                </p>
                </td>";
                $msg .="<td>".$row->receipts_date."<p>".$row->receipts_status."</p></td>";

            }
            $msg .= "
            <thead>
            <tr>                               
            <th style='width:60%'>OR No.</th>
            <th>Date</th>
            </tr>
            </thead></table>
            ";


            $query_pag_num = "SELECT COUNT(receipts_id) AS count FROM receipts where participants_id = ".$id."";

            $result_pag_num = mysql_query($query_pag_num);
            $row = mysql_fetch_array($result_pag_num);
            $count = $row['count'];

            $no_of_paginations = ceil($count / $per_page);

            /* ---------------Calculating the starting and endign values for the loop----------------------------------- */
            if ($cur_page >= 7) {
                $start_loop = $cur_page - 3;
                if ($no_of_paginations > $cur_page + 3)
                    $end_loop = $cur_page + 3;
                else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 6) {
                    $start_loop = $no_of_paginations - 6;
                    $end_loop = $no_of_paginations;
                } else {
                    $end_loop = $no_of_paginations;
                }
            } else {
                $start_loop = 1;
                if ($no_of_paginations > 7)
                    $end_loop = 7;
                else
                    $end_loop = $no_of_paginations;
            }
            /* ----------------------------------------------------------------------------------------------------------- */


            $msg .= "<div class='row'><div class='col-sm-12 paginations'><ul class='pull-right pagination'>";

            // FOR ENABLING THE PREVIOUS BUTTON
            if ($previous_btn && $cur_page > 1) {
                $pre = $cur_page - 1;

                $msg .= "<li p='$pre' class='ping'><a href='javascript:;'>&laquo;</a></li>";
            } else if ($previous_btn) {
                $msg .= "<li class='active'><a href='javascript:;'>&laquo;</a></li>";
            }
            for ($i = $start_loop; $i <= $end_loop; $i++) {

                if ($cur_page == $i)
                    $msg .= "<li p='$i' style='color:#fff;background-color:#006699;' class='active ping'><a href='javascript:;'>{$i}</a></li>";
                else
                    $msg .= "<li p='$i' class='ping'><a href='javascript:;'>{$i}</a></li>";
            }

            // TO ENABLE THE NEXT BUTTON
            if ($next_btn && $cur_page < $no_of_paginations) {
                $nex = $cur_page + 1;
                $msg .= "<li p='$nex' class='ping'><a href='javascript:;'>&raquo;</a></li>";
            } else if ($next_btn) {
                $msg .= "<li class='active'><a href='javascript:;'>&raquo;</a></li>";
            }

            $msg .= "</ul><em class='pull-right text-right all-item'>".$count." items</em></div><div class='clearfix'></div></div>";





            $msg1 = "<div class='row'><div class='col-sm-12 paginations'><ul class='pull-right pagination'>";

            // FOR ENABLING THE PREVIOUS BUTTON
            if ($previous_btn && $cur_page > 1) {
                $pre = $cur_page - 1;

                $msg1 .= "<li p='$pre' class='ping'><a href='javascript:;'>&laquo;</a></li>";
            } else if ($previous_btn) {
                $msg1 .= "<li class='active'><a href='javascript:;'>&laquo;</a></li>";
            }
            for ($i = $start_loop; $i <= $end_loop; $i++) {

                if ($cur_page == $i)
                    $msg1 .= "<li p='$i' style='color:#fff;background-color:#006699;' class='active ping'><a href='javascript:;'>{$i}</a></li>";
                else
                    $msg1 .= "<li p='$i' class='ping'><a href='javascript:;'>{$i}</a></li>";
            }

            // TO ENABLE THE NEXT BUTTON
            if ($next_btn && $cur_page < $no_of_paginations) {
                $nex = $cur_page + 1;
                $msg1 .= "<li p='$nex' class='ping'><a href='javascript:;'>&raquo;</a></li>";
            } else if ($next_btn) {
                $msg1 .= "<li class='active'><a href='javascript:;'>&raquo;</a></li>";
            }

            $msg1 .= "</ul><em class='pull-right text-right all-item'>".$count." items</em></div><div class='clearfix'></div></div>";


            echo $msg1.$msg;

            } else { //else 

                echo 'There are no records found.';

            }
        } else {
            echo 'There are no records found.';
        }
    } //if db error


elseif(isset($_GET['participants'])):

$query3 = $this->db->query("SELECT * FROM participants where participants_fullname like '%".$_GET['participants']."%' or participants_nric = '".$_GET['participants']."'");
    
    if( $this->db->_error_message()  ){
        echo 'There are no records found.';    
    } else {

        if($query3->num_rows > 0){

            foreach ($query3->result() as $row3){
                $id = $row3->participants_id;
            }

            $query1 = $this->db->query("SELECT * FROM receipts where participants_id = ".$id." ORDER BY receipts_id ASC LIMIT $start, $per_page");

            if($query1->num_rows > 0){
                  
            foreach ($query1->result() as $row){
                $msg .="<tr><td>".$row->receipts_or."
                <p class='options'>            
                <a href='javascript:;;' class='text-info md-trigger' data-modal='edit-modal'>
                edit
                </a>
                <a href='javascript:;;' class='text-danger md-trigger' data-modal='delete-modal'>
                cancel
                </a>
                <a href='invoice/".str_replace("/", '-',$row->receipts_or)."' target='_blank' class='text-warning'>
                view
                </a>
                </p>
                </td>";
                $msg .="<td>".$row->receipts_date."<p>".$row->receipts_status."</p></td>";

            }
            $msg .= "
            <thead>
            <tr>                               
            <th style='width:60%'>OR No.</th>
            <th>Date</th>
            </tr>
            </thead></table>
            ";


            $query_pag_num = "SELECT COUNT(receipts_id) AS count FROM receipts where participants_id = ".$id."";

            $result_pag_num = mysql_query($query_pag_num);
            $row = mysql_fetch_array($result_pag_num);
            $count = $row['count'];

            $no_of_paginations = ceil($count / $per_page);

            /* ---------------Calculating the starting and endign values for the loop----------------------------------- */
            if ($cur_page >= 7) {
                $start_loop = $cur_page - 3;
                if ($no_of_paginations > $cur_page + 3)
                    $end_loop = $cur_page + 3;
                else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 6) {
                    $start_loop = $no_of_paginations - 6;
                    $end_loop = $no_of_paginations;
                } else {
                    $end_loop = $no_of_paginations;
                }
            } else {
                $start_loop = 1;
                if ($no_of_paginations > 7)
                    $end_loop = 7;
                else
                    $end_loop = $no_of_paginations;
            }
            /* ----------------------------------------------------------------------------------------------------------- */


            $msg .= "<div class='row'><div class='col-sm-12 paginations'><ul class='pull-right pagination'>";

            // FOR ENABLING THE PREVIOUS BUTTON
            if ($previous_btn && $cur_page > 1) {
                $pre = $cur_page - 1;

                $msg .= "<li p='$pre' class='ping'><a href='javascript:;'>&laquo;</a></li>";
            } else if ($previous_btn) {
                $msg .= "<li class='active'><a href='javascript:;'>&laquo;</a></li>";
            }
            for ($i = $start_loop; $i <= $end_loop; $i++) {

                if ($cur_page == $i)
                    $msg .= "<li p='$i' style='color:#fff;background-color:#006699;' class='active ping'><a href='javascript:;'>{$i}</a></li>";
                else
                    $msg .= "<li p='$i' class='ping'><a href='javascript:;'>{$i}</a></li>";
            }

            // TO ENABLE THE NEXT BUTTON
            if ($next_btn && $cur_page < $no_of_paginations) {
                $nex = $cur_page + 1;
                $msg .= "<li p='$nex' class='ping'><a href='javascript:;'>&raquo;</a></li>";
            } else if ($next_btn) {
                $msg .= "<li class='active'><a href='javascript:;'>&raquo;</a></li>";
            }

            $msg .= "</ul><em class='pull-right text-right all-item'>".$count." items</em></div><div class='clearfix'></div></div>";





            $msg1 = "<div class='row'><div class='col-sm-12 paginations'><ul class='pull-right pagination'>";

            // FOR ENABLING THE PREVIOUS BUTTON
            if ($previous_btn && $cur_page > 1) {
                $pre = $cur_page - 1;

                $msg1 .= "<li p='$pre' class='ping'><a href='javascript:;'>&laquo;</a></li>";
            } else if ($previous_btn) {
                $msg1 .= "<li class='active'><a href='javascript:;'>&laquo;</a></li>";
            }
            for ($i = $start_loop; $i <= $end_loop; $i++) {

                if ($cur_page == $i)
                    $msg1 .= "<li p='$i' style='color:#fff;background-color:#006699;' class='active ping'><a href='javascript:;'>{$i}</a></li>";
                else
                    $msg1 .= "<li p='$i' class='ping'><a href='javascript:;'>{$i}</a></li>";
            }

            // TO ENABLE THE NEXT BUTTON
            if ($next_btn && $cur_page < $no_of_paginations) {
                $nex = $cur_page + 1;
                $msg1 .= "<li p='$nex' class='ping'><a href='javascript:;'>&raquo;</a></li>";
            } else if ($next_btn) {
                $msg1 .= "<li class='active'><a href='javascript:;'>&raquo;</a></li>";
            }

            $msg1 .= "</ul><em class='pull-right text-right all-item'>".$count." items</em></div><div class='clearfix'></div></div>";


            echo $msg1.$msg;

            } else { //else 

                echo 'There are no records found.';

            }
        } else {
            echo 'There are no records found.';
        }
    } //if db error
else:
    echo 'There are no records found.';
endif;

}