<?php 
	foreach($results as $row){	
		$arr = array (
		'u_id'=>$row->users_id,
		'u_username'=>$row->users_username,
		'u_password'=>$row->users_password,
		'u_email'=>$row->users_email,
		'u_fname'=>$row->users_fullname,
		'u_branchname'=> $this->main_model->search_branch($row->branch_id),
		'u_brselect'=>$row->branch_id
		);
	}   
	header('Content-Type: application/json');
    echo json_encode( $arr );
?>