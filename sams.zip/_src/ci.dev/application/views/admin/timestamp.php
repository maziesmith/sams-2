<body id="timestamp">

        <!-- Aside Start-->
        <aside class="left-panel">

            <!-- brand -->
            <div class="logo text-center">
                <a href="<?php echo base_url(); ?>admin/dashboard" class="logo-expanded">
                    <img src="<?php echo base_url('assets/img/logo3.png'); ?>" alt="logo" style="width:70%">
                    <span class="nav-label">theRECEIPT</span>
                </a>
            </div>
            <!-- / brand -->
        
            <!-- Navbar Start -->
            <nav class="navigation">
                <ul class="list-unstyled">
                    <li>
                        <a href="<?php echo base_url(); ?>admin/dashboard"><i class="ion-home"></i> <span class="nav-label">Dashboard</span></a>                        
                    </li>
                    <li>
                        <a href="<?php echo base_url(); ?>admin/participants"><i class="ion-android-contacts"></i> <span class="nav-label">Participants</span></a>                        
                    </li>
                    <li class="has-submenu"><a href="#"><i class="ion-android-social"></i> <span class="nav-label">Users</span></a>
                        <ul class="list-unstyled">
                            <li><a href="<?php echo base_url(); ?>admin/users">All Users</a></li>
                            <li><a href="<?php echo base_url(); ?>admin/users/add">Add New</a></li>
                            
                        </ul>
                    </li>
                    <li class="has-submenu"><a href="#"><i class="ion-ios7-printer"></i> <span class="nav-label">Receipts</span></a>
                        <ul class="list-unstyled">
                            <li><a href="<?php echo base_url(); ?>admin/receipts">All Receipts</a></li>
                            <li><a href="<?php echo base_url(); ?>admin/receipts/add">Add New</a></li>
                            
                        </ul>
                    </li>
                    <li class="active">
                        <a href="<?php echo base_url(); ?>admin/timestamp"><i class="ion-ios7-time"></i> <span class="nav-label">Timestamp</span></a>                        
                    </li>
                    <li><a href="<?php echo base_url(); ?>admin/myprofile"><i class="ion-gear-a"></i> <span class="nav-label">My Profile</span></a>                       
                    </li>
                    
                </ul>
            </nav>
                
        </aside>
        <!-- Aside Ends-->


        <!--Main Content Start -->
        <section class="content">
            
            <!-- Header -->
            <header class="top-head container-fluid">
                <button type="button" class="navbar-toggle pull-left">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                
                <!-- Search -->
                <form role="search" class="navbar-left app-search pull-left hidden-xs">
                  <input type="text" placeholder="Search..." class="form-control">
                </form>
                
                
                
                <!-- Right navbar -->
                <ul class="list-inline navbar-right top-menu top-right-menu">  
                    <!-- mesages -->  
                    <li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <i class="fa fa-envelope-o "></i>
                            <span class="badge badge-sm up bg-purple count">4</span>
                        </a>
                        <ul class="dropdown-menu extended fadeInUp animated nicescroll" tabindex="5001">
                            <li>
                                <p>Messages</p>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><img src="<?php echo base_url('assets/img/avatar-2.jpg'); ?>" class="img-circle thumb-sm m-r-15" alt="img"></span>
                                    <span class="block"><strong>John smith</strong></span>
                                    <span class="media-body block">New tasks needs to be done<br><small class="text-muted">10 seconds ago</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><img src="<?php echo base_url('assets/img/avatar-3.jpg'); ?>" class="img-circle thumb-sm m-r-15" alt="img"></span>
                                    <span class="block"><strong>John smith</strong></span>
                                    <span class="media-body block">New tasks needs to be done<br><small class="text-muted">3 minutes ago</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><img src="<?php echo base_url('assets/img/avatar-4.jpg'); ?>" class="img-circle thumb-sm m-r-15" alt="img"></span>
                                    <span class="block"><strong>John smith</strong></span>
                                    <span class="media-body block">New tasks needs to be done<br><small class="text-muted">10 minutes ago</small></span>
                                </a>
                            </li>
                            <li>
                                <p><a href="inbox.html" class="text-right">See all Messages</a></p>
                            </li>
                        </ul>
                    </li>
                    <!-- /messages -->
                    <!-- Notification -->
                    <li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <i class="fa fa-bell-o"></i>
                            <span class="badge badge-sm up bg-pink count">3</span>
                        </a>
                        <ul class="dropdown-menu extended fadeInUp animated nicescroll" tabindex="5002">
                            <li class="noti-header">
                                <p>Notifications</p>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><i class="fa fa-user-plus fa-2x text-info"></i></span>
                                    <span>New user registered<br><small class="text-muted">5 minutes ago</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><i class="fa fa-diamond fa-2x text-primary"></i></span>
                                    <span>Use animate.css<br><small class="text-muted">5 minutes ago</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><i class="fa fa-bell-o fa-2x text-danger"></i></span>
                                    <span>Send project demo files to client<br><small class="text-muted">1 hour ago</small></span>
                                </a>
                            </li>
                            
                            <li>
                                <p><a href="#" class="text-right">See all notifications</a></p>
                            </li>
                        </ul>
                    </li>
                    <!-- /Notification -->

                    <!-- user login dropdown start-->
                    <li class="dropdown text-center">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <img alt="" src="<?php echo base_url('assets/img/avatar-2.jpg'); ?>" class="img-circle profile-img thumb-sm">
                            <span class="username"><?php echo $profile['users_fullname']; ?> </span> <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu extended pro-menu fadeInUp animated" tabindex="5003" style="overflow: hidden; outline: none;">
                            <li><a href="<?php echo base_url(); ?>admin/myprofile"><i class="fa fa-briefcase"></i>Profile</a></li>                 
                            <li><a href="<?php echo base_url(); ?>logout"><i class="fa fa-sign-out"></i> Log Out</a></li>
                        </ul>
                    </li>
                    <!-- user login dropdown end -->       
                </ul>
                <!-- End right navbar -->

            </header>
            <!-- Header Ends -->


            <!-- Page Content Start -->
            <!-- ================== -->

            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Timestamp</h3> 
                </div>

                

                




                <div class="row">
                        
                   

                        <div class="col-lg-6" id="act-holder-participants">
                        
                            <div class="portlet"><!-- /primary heading -->
                                <div class="portlet-heading">
                                    <h3 class="portlet-title text-dark text-uppercase">
                                        All Activities
                                    </h3>                                    
                                    <div class="clearfix"></div>
                                </div>
                                <div id="portlet1" class="panel-collapse collapse in">
                                    <div class="portlet-body">
                                        <div class="row">   
                                            <div class="col-sm-12">
                                               
                                                <div class="col-sm-offset-1 col-sm-10">    
                                                    <div id="results" class="timeline-2">

                                                    </div>
                                                    <div class="animation_image" style="display:none" align="center">
                                                    <img src="../assets/img/ajax-loader.gif">
                                                    </div>
                                                </div>

                                            </div><div class="clearfix"></div>                                  
                                        </div>                              
                                    </div>
                                </div>
                            </div> <!-- /Portlet -->

                        </div> <!-- end col -->

                        <div class="col-lg-6" id="act-holder-participants">
                        
                            <div class="portlet"><!-- /primary heading -->
                                <div class="portlet-heading">
                                    <h3 class="portlet-title text-dark text-uppercase">
                                        Reports
                                    </h3>                                    
                                <div class="clearfix"></div>
                                </div>
                                <div id="portlet1" class="panel-collapse collapse in">
                                    <div class="portlet-body">
                                        <div class="row">   
                                            <div class="col-sm-12">
                                            
                                            <div class="col-sm-12">
                                                <div class="form-group">
                                                <label>CATEGORY</label>
                                                <select class="form-control " id="category" name="category">
                                                <option value="">Select Category</option>
                                                <option value="ALL">ALL</option>
                                                <?php 
                                                    foreach($results as $row){
                                                        echo "<option value='".$row->users_id."'>".$row->users_fullname."</option>";
                                                    }                                 
                                                ?>

                                                </select>

                                                </div>

                                                

                                                <div class="form-group">
                                                <label>Select Date From</label>
                                                <div class="input-group">
                                                    <input type="text" class="pick-date form-control" placeholder="yyyy-mm-dd" id="date_from" name="date_from">
                                                    <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                                                </div><!-- input-group -->
                                                </div>

                                                
                                                <div class="form-group">
                                                <label>Select Date To</label>
                                                <div class="input-group">
                                                    <input type="text" class="pick-date form-control" placeholder="yyyy-mm-dd" name="date_to" id="date_to">
                                                    <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                                                </div><!-- input-group -->
                                                </div>

                                                <div class="form-group mt-20">
                                                    <button type="button" class="btn btn-info" id="view-activity">View Activity</button>
                                                </div>

                                            </div> 

                                            </div><div class="clearfix"></div>                                  
                                        </div>                              
                                    </div>
                                </div>
                            </div> <!-- /Portlet -->

                        </div> <!-- end col -->


                    
                </div> <!-- End row -->

            </div>
            <!-- Page Content Ends -->
            <!-- ================== -->

            <!-- Footer Start -->
            <footer class="footer">
                2015 © theRECEIPT SSA Consulting Group Pte. Ltd.
            </footer>
            <!-- Footer Ends -->



        </section>
        <!-- Main Content Ends -->


        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
          <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title text-uppercase text-left" id="myModalLabel" style="margin-bottom:10px">Modal title</h4>
              </div>
              <div class="modal-body" style="padding:0">
                    <table class="table table-striped table-hover" style="margin:00">

                    </table>
              </div>
              
            </div>
          </div>
        </div>

