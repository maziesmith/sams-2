<?php
	
		$arr = array (
		'p_id'=>2
		'p_nric'=>1);
	
	header('Content-Type: application/json');
    echo json_encode( $arr );
?>