<body id="users">

    <!-- Aside Start-->
    <aside class="left-panel">

        <!-- brand -->
        <div class="logo text-center">
            <a href="<?php echo base_url(); ?>admin/dashboard" class="logo-expanded">
                <img src="<?php echo base_url('assets/img/logo3.png'); ?>" alt="logo" style="width:70%">
                <span class="nav-label">theRECEIPT</span>
            </a>
        </div>
        <!-- / brand -->
    
        <!-- Navbar Start -->
        <nav class="navigation">
            <ul class="list-unstyled">
                <li>
                    <a href="<?php echo base_url(); ?>admin/dashboard"><i class="ion-home"></i> <span class="nav-label">Dashboard</span></a>                        
                </li>
                <li>
                    <a href="<?php echo base_url(); ?>admin/participants"><i class="ion-android-contacts"></i> <span class="nav-label">Participants</span></a>                        
                </li>
                <li class="has-submenu active"><a href="#"><i class="ion-android-social"></i> <span class="nav-label">Users</span></a>
                    <ul class="list-unstyled">
                        <li><a href="#">All Users</a></li>
                        <li class="active"><a href="<?php echo base_url(); ?>admin/users/add">Add New</a></li>
                        
                    </ul>
                </li>
                <li class="has-submenu"><a href="#"><i class="ion-ios7-printer"></i> <span class="nav-label">Receipts</span></a>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo base_url(); ?>admin/receipts">All Receipts</a></li>
                        <li><a href="<?php echo base_url(); ?>admin/receipts/add">Add New</a></li>
                        
                    </ul>
                </li>
                <li>
                    <a href="<?php echo base_url(); ?>admin/timestamp"><i class="ion-ios7-time"></i> <span class="nav-label">Timestamp</span></a>                        
                </li>
                <li><a href="<?php echo base_url(); ?>admin/myprofile"><i class="ion-gear-a"></i> <span class="nav-label">My Profile</span></a>                       
                </li>
                
            </ul>
        </nav>
        
    </aside>
    <!-- Aside Ends-->


    <!--Main Content Start -->
    <section class="content">
        
        <!-- Header -->
        <header class="top-head container-fluid">
            <button type="button" class="navbar-toggle pull-left">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            
            <!-- Search -->
            <form role="search" class="navbar-left app-search pull-left hidden-xs">
              <input type="text" placeholder="Search..." class="form-control">
            </form>
            
            
            
            <!-- Right navbar -->
            <ul class="list-inline navbar-right top-menu top-right-menu">  
                <!-- mesages -->  
                <li class="dropdown">
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                        <i class="fa fa-envelope-o "></i>
                        <span class="badge badge-sm up bg-purple count">4</span>
                    </a>
                    <ul class="dropdown-menu extended fadeInUp animated nicescroll" tabindex="5001">
                        <li>
                            <p>Messages</p>
                        </li>
                        <li>
                            <a href="#">
                                <span class="pull-left"><img src="<?php echo base_url('assets/img/avatar-2.jpg'); ?>" class="img-circle thumb-sm m-r-15" alt="img"></span>
                                <span class="block"><strong>John smith</strong></span>
                                <span class="media-body block">New tasks needs to be done<br><small class="text-muted">10 seconds ago</small></span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span class="pull-left"><img src="<?php echo base_url('assets/img/avatar-3.jpg'); ?>" class="img-circle thumb-sm m-r-15" alt="img"></span>
                                <span class="block"><strong>John smith</strong></span>
                                <span class="media-body block">New tasks needs to be done<br><small class="text-muted">3 minutes ago</small></span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span class="pull-left"><img src="<?php echo base_url('assets/img/avatar-4.jpg'); ?>" class="img-circle thumb-sm m-r-15" alt="img"></span>
                                <span class="block"><strong>John smith</strong></span>
                                <span class="media-body block">New tasks needs to be done<br><small class="text-muted">10 minutes ago</small></span>
                            </a>
                        </li>
                        <li>
                            <p><a href="inbox.html" class="text-right">See all Messages</a></p>
                        </li>
                    </ul>
                </li>
                <!-- /messages -->
                <!-- Notification -->
                <li class="dropdown">
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                        <i class="fa fa-bell-o"></i>
                        <span class="badge badge-sm up bg-pink count">3</span>
                    </a>
                    <ul class="dropdown-menu extended fadeInUp animated nicescroll" tabindex="5002">
                        <li class="noti-header">
                            <p>Notifications</p>
                        </li>
                        <li>
                            <a href="#">
                                <span class="pull-left"><i class="fa fa-user-plus fa-2x text-info"></i></span>
                                <span>New user registered<br><small class="text-muted">5 minutes ago</small></span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span class="pull-left"><i class="fa fa-diamond fa-2x text-primary"></i></span>
                                <span>Use animate.css<br><small class="text-muted">5 minutes ago</small></span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span class="pull-left"><i class="fa fa-bell-o fa-2x text-danger"></i></span>
                                <span>Send project demo files to client<br><small class="text-muted">1 hour ago</small></span>
                            </a>
                        </li>
                        
                        <li>
                            <p><a href="#" class="text-right">See all notifications</a></p>
                        </li>
                    </ul>
                </li>
                <!-- /Notification -->

                <!-- user login dropdown start-->
                <li class="dropdown text-center">
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                        <img alt="" src="<?php echo base_url('assets/img/avatar-2.jpg'); ?>" class="img-circle profile-img thumb-sm">
                        <span class="username"><?php echo $profile['users_fullname']; ?> </span> <span class="caret"></span>
                    </a>
                    <ul class="dropdown-menu extended pro-menu fadeInUp animated" tabindex="5003" style="overflow: hidden; outline: none;">
                        <li><a href="<?php echo base_url(); ?>admin/myprofile"><i class="fa fa-briefcase"></i>Profile</a></li>                 
                        <li><a href="<?php echo base_url(); ?>logout"><i class="fa fa-sign-out"></i> Log Out</a></li>
                    </ul>
                </li>
                <!-- user login dropdown end -->       
            </ul>
            <!-- End right navbar -->

        </header>
        <!-- Header Ends -->


        <!-- Page Content Start -->
        <!-- ================== -->

        <div class="wraper container-fluid">
            <div class="page-title"> 
                <h3 class="title">
                <?php echo $template['sub_title']; ?> <a href="<?php echo base_url(); ?>admin/users/add" class="btn btn-default btn-addnew">Add New</a></h3> 
            </div>

            

            




            <div class="row">
                <div class="col-lg-12">
                    <div class="prog-search-holder">
                        <div class="col-sm-6 pad-zero-left">                              
                            <ul class="nav nav-tabs tab-actions" role="tablist">
                                <li role="presentation" class="active">
                                    <a href="#all-holder" aria-controls="home" role="tab" data-toggle="tab">
                                        <span class="text-info">All</span> (<?php echo $all_users; ?>)
                                    </a>
                                </li>
                                <li role="presentation">
                                    <a href="#received-holder" aria-controls="profile" role="tab" data-toggle="tab">
                                        <span class="text-info">Main</span> (<?php echo $all_main_users; ?>)
                                    </a>
                                </li>
                                <li role="presentation">
                                    <a href="#cancelled-holder" aria-controls="messages" role="tab" data-toggle="tab">
                                        <span class="text-info">Branch</span> (<?php echo $all_branch_users; ?>)
                                    </a>
                                </li>                                        
                            </ul>                     
                        </div>
                        <div class="col-sm-6 pad-zero-right">
                            <div class="form-group">
                                <label class="col-md-6 control-label pad-zero-right">
                                     <input type="text" class="form-control" id="user_search" name="user_search">
                                </label>
                                <div class="col-md-6 pad-zero-right">
                                    <button type="button" class="btn btn-default btn-user-search">Search Receipts</button>
                                </div>
                            </div>
                        </div><div class="clearfix"></div>
                    </div>

                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane fade in active" id="all-holder">
                            <div class="portlet"><!-- /primary heading -->
                                <div class="portlet-heading">
                                    <h3 class="portlet-title text-dark text-uppercase">
                                        All Users
                                    </h3>
                                    <div class="portlet-widgets">
                                        <a href="javascript:;" data-toggle="reload"><i class="ion-refresh"></i></a>
                                        <span class="divider"></span>
                                        <a data-toggle="collapse" data-parent="#accordion1" href="#portlet1"><i class="ion-minus-round"></i></a>
                                        <span class="divider"></span>
                                        
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                                <div id="portlet1" class="panel-collapse collapse in">
                                    <div class="portlet-body">
                                        <div class="row">                                       
                                           
                                            <div class="col-sm-12">
                                                <div id="all-users" class="col-sm-12 table-responsive">
                                                    <div class="data"></div>                                      
                                                </div>                                                
                                            </div><div class="clearfix"></div>

                                            

                                        </div>                              
                                    </div>
                                </div>
                            </div> <!-- /Portlet -->
                        </div>

                        
                        <div role="tabpanel" class="tab-pane fade" id="received-holder">
                            <div class="portlet"><!-- /primary heading -->
                                <div class="portlet-heading">
                                    <h3 class="portlet-title text-dark text-uppercase">
                                        All Main Users
                                    </h3>
                                    <div class="portlet-widgets">
                                        <a href="javascript:;" data-toggle="reload"><i class="ion-refresh"></i></a>
                                        <span class="divider"></span>
                                        <a data-toggle="collapse" data-parent="#accordion1" href="#portlet1"><i class="ion-minus-round"></i></a>
                                        <span class="divider"></span>
                                        
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                                <div id="portlet1" class="panel-collapse collapse in">
                                    <div class="portlet-body">
                                        <div class="row">                                       
                                            <div class="col-sm-12">
                                                <div id="all-main" class="col-sm-12 table-responsive">
                                                    <div class="data"></div>                                      
                                                </div>                                                
                                            </div><div class="clearfix"></div>
                                        </div>                              
                                    </div>
                                </div>
                            </div> <!-- /Portlet -->
                        </div>

                        <div role="tabpanel" class="tab-pane fade" id="cancelled-holder">
                            <div class="portlet"><!-- /primary heading -->
                                <div class="portlet-heading">
                                    <h3 class="portlet-title text-dark text-uppercase">
                                        All Branch Users
                                    </h3>
                                    <div class="portlet-widgets">
                                        <a href="javascript:;" data-toggle="reload"><i class="ion-refresh"></i></a>
                                        <span class="divider"></span>
                                        <a data-toggle="collapse" data-parent="#accordion1" href="#portlet1"><i class="ion-minus-round"></i></a>
                                        <span class="divider"></span>
                                        
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                                <div id="portlet1" class="panel-collapse collapse in">
                                    <div class="portlet-body">
                                        <div class="row">                                       
                                            <div class="col-sm-12">
                                                <div id="all-branch" class="col-sm-12 table-responsive">
                                                    <div class="data"></div>                                      
                                                </div>                                                
                                            </div><div class="clearfix"></div>
                                        </div>                              
                                    </div>
                                </div>
                            </div> <!-- /Portlet -->
                        </div>    


                    </div>                        

                </div> <!-- end col -->

                
            </div> <!-- End row -->

        </div>
        <!-- Page Content Ends -->
        <!-- ================== -->

        <!-- Footer Start -->
        <footer class="footer">
            2015 © theRECEIPT SSA Consulting Group Pte. Ltd.
        </footer>
        <!-- Footer Ends -->



    </section>
    <!-- Main Content Ends -->

    <div class="md-modal md-effect-14" id="edit-user-modal">
        <div class="md-content">
            <h3>Edit <strong>(<span id="u_id"></span>)</strong> <br>
            <span class="text-info">USER(<ids id="u_unames"></ids>)</span></h3>
            <div class="transaction-content">

                <div class="col-sm-6 form-group pad-zero-left">
                    <label for="prog_slug">FULLNAME</label>
                    <input type="text" class="form-control" id="u_fname" name="u_fname">
                    
                </div>
                <div class="col-sm-6 form-group pad-zero-right">
                    <label for="prog_slug">EMAIL ADDRESS</label>
                    <input type="text" class="form-control" id="u_email" name="u_email">
                    
                </div>
                
                <div class="col-sm-6 form-group pad-zero-left">
                    <label for="prog_slug">USERNAME</label>
                    <input type="text" class="form-control" id="u_uname" name="u_uname">
                    
                </div>
                <div class="col-sm-6 form-group pad-zero-right">
                    <label for="prog_slug">PASSWORD</label>
                    <input type="password" class="form-control" id="u_pass" name="u_pass">
                    
                </div>

                <div class="form-group">
                    <label for="prog_slug">BRANCH</label>
                    <select class="form-control" id="u_branch" name="u_branch">
                        <option id="u_brselect" value=""></option>                        
                        <?php 
                            foreach($results as $row){
                                echo "<option value='".$row->branch_id."'>".$row->branch_name."</option>";                                         
                            }                                  
                        ?>
                    </select>                    
                </div>



                <span class="pull-left text-center" style="width:100%;margin:0">
                <h3 style="margin:0">Do you wish to update this user?</h3>
                <button class="md-close btn-info btns yes-edit-user">Yes</button>
                <button class="btn-danger btns nifty-closes">No</button>
                </span><div class="clearfix"></div>
            </div>
        </div>
    </div>    

    <div class="md-overlay"></div><!-- the overlay element -->