<?php 

	$data = array();

	foreach($results as $row){	
		
		$item = array (
		'th_user'=>$this->main_model->search_username($row->th_user),
		'th_transaction'=>$row->th_transaction,
		'th_date'=>$row->th_date,
		'th_time'=>$row->th_time);
		array_push($data, $item);
	}   


	header('Content-Type: application/json');
    echo json_encode(array("data" => $data));
?>