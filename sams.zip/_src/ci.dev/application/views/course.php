<body id="course">
<div class="preload">
    <img src="<?php echo base_url('assets/images/loading.gif'); ?>">
</div>
        <?php 

        $code = $this->uri->segment(2);
        if($code!="all"):
        foreach($result as $row){
                    $id = $row->program_id;
                    $code = $row->program_code;
                    $name = $row->program_name;
                    $desc = $row->program_desc;
        }
        endif;
        ?>
        
        <header class="intro-header" <?php if($code=="all"): ?> style="background-image: url('<?php echo base_url('assets/images/all-courses.jpg'); ?>')" <?php else: ?> style="background-image: url('<?php echo base_url('assets/images/program/'.$code.'.jpg'); ?>')" <?php endif; ?>>
            <div class="overlay"></div>
            <div class="container">

                <div class="row nav-wrapper">
                    <nav class="navbar navbar-custom">
                        <div class="container-fluid">
                            <!-- Brand and toggle get grouped for better mobile display -->
                            <div class="navbar-header">
                                <button type="button" class="mt40 navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                                <a class="navbar-brand" href="<?php echo base_url(); ?>">
                                    <img src="<?php echo base_url('assets/images/logo.png'); ?>" alt="logo">
                                </a>
                            </div>

                            <!-- Collect the nav links, forms, and other content for toggling -->
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav navbar-right">
                                    <li><a href="<?php echo base_url(); ?>">Home</a></li>
                                    <li><a href="<?php echo base_url(); ?>course/all">Courses</a></li>
                                    <li><a href="<?php echo base_url(); ?>course-schedule">Schedule</a></li>
                                    <li><a href="<?php echo base_url(); ?>contact-us">Contact Us</a></li>
                                    <li><a class="toggle-search" href="#search-holder">Search</a></li>
                                </ul>
                            </div><!-- /.navbar-collapse -->
                        </div><!-- /.container-fluid -->
                    </nav> <!-- end nav -->
                </div> <!-- End row -->

                <div class="row">
                    <div id="search-holder" class="col-sm-offset-1 col-sm-10 search-holder mt50">
                    <div class="col-sm-3">
                        <select class="form-control input-lg" id="programme" name="programme">
                          <option value="">Select Program</option>
                          <option value="icdl">International Computer Driving License (ICDL)</option>
                          <option value="wpln">Workplace Literacy and Numeracy (WPLN)</option>
                          <option value="edge">Executive Development for Growth &amp; Excellence (EDGE)</option>
                          <option value="wps">Workplace Skills (WPS)</option>
                          <option value="etw">Egnlish That Works (ETW)</option>
                          <option value="eatw">English @ Workplace (E@W)</option>
                          <option value="gms">Generic Manufacturing Skills (GMS)</option>
                          <option value="tmp">Tailor Made Programs (TMP)</option>
                        </select>
                    </div>    
                    <div class="col-sm-3">
                        <input class="form-control input-lg" id="keyword" name="keyword" placeholder="Enter Keyword"/>
                    </div>
                    <div class="col-sm-3">
                        <select class="form-control input-lg" id="level" name="level">
                              <option value="">Select Level</option>
                              <option value="General">General</option>
                              <option value="Core">Core</option>
                              <option value="Beginner">Beginner</option>
                              <option value="Intermediate">Intermediate</option>
                              <option value="Advanced">Advanced</option>
                              <option value="Level 1">Level 1</option>
                              <option value="Level 2">Level 2</option>
                              <option value="Level 3">Level 3</option>
                              <option value="Level 4">Level 4</option>
                              <option value="Entry-Level">Entry-Level</option>
                              <option value="Mid-Level">Mid-Level</option>
                              <option value="Experienced-Level">Mid-Level</option>
                            </select>
                    </div>
                    <div class="col-sm-3">
                        <button type="button" class="go-btn btn btn-primary input-lg">Go</button>
                    </div><div class="clearfix"></div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="site-heading">

                            

                            <h1><?php if(isset($name)): echo $name; else: echo 'SSA Course'; endif; ?></h1>
                            <hr class="small">
                            <span class="subheading"><?php if(isset($desc)): echo $desc; else: echo 'All Courses'; endif; ?></span>
                        </div>
                    </div><div class="clearfix"></div>
                </div>
            </div>
        </header>

        <section id="courses" class="courses">
            <div class="container">
                <div class="row">
                    <div class="col-sm-3 left">
                        <a href="<?php echo base_url(); ?>course/wpln#courses" <?php if($code=="wpln"): ?> class="active" <?php endif; ?>><li>WPLN</li></a>
                        <a href="<?php echo base_url(); ?>course/edge#courses" <?php if($code=="edge"): ?> class="active" <?php endif; ?>><li>EDGE</li></a>
                        <a href="<?php echo base_url(); ?>course/icdl#courses" <?php if($code=="icdl"): ?> class="active" <?php endif; ?>><li>ICDL</li></a>
                        <a href="<?php echo base_url(); ?>course/etw#courses" <?php if($code=="etw"): ?> class="active" <?php endif; ?>><li>ETW</li></a>
                        <a href="<?php echo base_url(); ?>course/eatw#courses" <?php if($code=="eatw"): ?> class="active" <?php endif; ?>><li>E@W</li></a>
                        <a href="<?php echo base_url(); ?>course/gms#courses" <?php if($code=="gms"): ?> class="active" <?php endif; ?>><li>GMS</li></a>
                        <a href="<?php echo base_url(); ?>course/wps#courses" <?php if($code=="wps"): ?> class="active" <?php endif; ?>><li>WPS</li></a>
                        <a href="<?php echo base_url(); ?>course/tmp#courses" <?php if($code=="tmp"): ?> class="active" <?php endif; ?>><li class="last-child">TMP</li></a>
                        <div class="ads mt30 mb30">
                        <a href="<?php echo base_url('assets/images/Training - 08-27-15-Spread-Training-Website.pdf'); ?>" target="_blank"><img src="<?php echo base_url(); ?>assets/images/Training Cover - Thumbnail.png" title="Training Cover - Thumbnail"/></a>
                        </div>
                    </div>

                    <div class="col-sm-3 right mb30">
                        <div class="right-box">
                        <h3 class="text-center mt10 mb20"><strong>Filter Results</strong></h3>
                        <h4><strong>Target Audience</strong></h4>
                        <form id="filters-form" method="get" action="<?php if($code=='all'): echo '../wpln/.'; else: echo ''; endif; ?>">
                        <select class="form-control" onchange="filterable();" name="caudience" id="caudience">
                            <option value="">Select Target Audience</option>
                            <option value="Rank and File1">Rank and File 1</option>
                            <option value="Rank and File2">Rank and File 2</option>
                            <option value="Rank and File3">Rank and File 3</option>
                        </select>
                                

                        <h4><strong>Duration</strong></h4>
                        <select class="form-control" onchange="filterable();" name="cduration" id="cduration">
                            <?php if((isset($_GET['cduration'])) && ($_GET['cduration']!="")) : echo '<option value="'.$_GET['cduration'].'">'.$_GET['cduration'].'hrs</option>'; endif; ?>
                            <option value="">Select Duration</option>
                            <option value="13.5">13.5hrs</option>
                            <option value="15">15hrs</option>
                            <option value="16">16hrs</option>
                            <option value="17.5">17.5hrs</option>
                            <option value="17.75">17.75hrs</option>
                            <option value="18">18hrs</option>
                            <option value="18.5">18.5hrs</option>
                            <option value="16+4">20hrs</option>
                            <option value="18+4">22hrs</option>
                            <option value="17.5+4">21.5hrs</option>
                            <option value="17.75+4">21.75hrs</option>
                            <option value="24">24hrs</option>
                            <option value="28">28hrs</option>
                            <option value="30">30hrs</option>
                            <option value="35">35hrs</option>
                            <option value="40">40hrs</option>
                            <option value="45">45hrs</option>
                            <option value="64">64hrs</option>
                            <option value="90">90hrs</option>
                        </select>

                        <h4><strong>Level</strong></h4>
                        <select class="form-control" onchange="filterable();" id="clevel" name="clevel">
                          
                          <?php if((isset($_GET['clevel'])) && ($_GET['clevel']!="")) : echo '<option value="'.$_GET['clevel'].'">'.$_GET['clevel'].'</option>'; endif; ?>
                          
                          <option value="">Select Level</option>
                          <option value="General">General</option>
                          <option value="Core">Core</option>
                          <option value="Beginner">Beginner</option>
                          <option value="Intermediate">Intermediate</option>
                          <option value="Advanced">Advanced</option>
                          <option value="Level 1">Level 1</option>
                          <option value="Level 2">Level 2</option>
                          <option value="Level 3">Level 3</option>
                          <option value="Level 4">Level 4</option>
                          <option value="Entry-Level">Entry-Level</option>
                          <option value="Mid-Level">Mid-Level</option>
                          <option value="Experienced-Level">Experienced-Level</option>
                        </select>
                      

                        <h4><strong>Program</strong></h4>
                        <div class="form-group">
                            <label class="cr-styled">
                                <input type="radio" value="wpln" name="cprogram" onclick="filterable();"
                                <?php 
                                    if(isset($_GET['cprogram'])):
                                        if($_GET['cprogram']=="wpln"):
                                            echo "checked";
                                        endif;
                                    endif;
                                ?>
                                >
                                <i class="fa"></i> 
                                WPLN
                            </label>
                        </div>
                        <div class="form-group">
                            <label class="cr-styled">
                                <input type="radio" value="edge" name="cprogram" onclick="filterable();" 
                                <?php 
                                    if(isset($_GET['cprogram'])):
                                        if($_GET['cprogram']=="edge"):
                                            echo "checked";
                                        endif;
                                    endif;
                                ?>
                                >
                                <i class="fa"></i> 
                                EDGE
                            </label>
                        </div>
                        <div class="form-group">
                            <label class="cr-styled">
                                <input type="radio" value="icdl" name="cprogram" onclick="filterable();"
                                <?php 
                                    if(isset($_GET['cprogram'])):
                                        if($_GET['cprogram']=="icdl"):
                                            echo "checked";
                                        endif;
                                    endif;
                                ?>
                                >
                                <i class="fa"></i> 
                                ICDL
                            </label>
                        </div>
                        <div class="form-group">
                            <label class="cr-styled">
                                <input type="radio" value="etw" name="cprogram" onclick="filterable();"
                                <?php 
                                    if(isset($_GET['cprogram'])):
                                        if($_GET['cprogram']=="etw"):
                                            echo "checked";
                                        endif;
                                    endif;
                                ?>
                                >
                                <i class="fa"></i> 
                                ETW
                            </label>
                        </div>
                        <div class="form-group">
                            <label class="cr-styled">
                                <input type="radio" value="eatw" name="cprogram" onclick="filterable();"
                                <?php 
                                    if(isset($_GET['cprogram'])):
                                        if($_GET['cprogram']=="eatw"):
                                            echo "checked";
                                        endif;
                                    endif;
                                ?>
                                >
                                <i class="fa"></i> 
                                E@W
                            </label>
                        </div>
                        <div class="form-group">
                            <label class="cr-styled">
                                <input type="radio" value="gms" name="cprogram" onclick="filterable();"
                                <?php 
                                    if(isset($_GET['cprogram'])):
                                        if($_GET['cprogram']=="gms"):
                                            echo "checked";
                                        endif;
                                    endif;
                                ?>
                                >
                                <i class="fa"></i> 
                                GMS
                            </label>
                        </div>
                        <div class="form-group">
                            <label class="cr-styled">
                                <input type="radio" value="wps" name="cprogram" onclick="filterable();"
                                <?php 
                                    if(isset($_GET['cprogram'])):
                                        if($_GET['cprogram']=="wps"):
                                            echo "checked";
                                        endif;
                                    endif;
                                ?>
                                >
                                <i class="fa"></i> 
                                WPS
                            </label>
                        </div>
                        <div class="form-group">
                            <label class="cr-styled">
                                <input type="radio" value="tmp" name="cprogram" onclick="filterable();"
                                <?php 
                                    if(isset($_GET['cprogram'])):
                                        if($_GET['cprogram']=="tmp"):
                                            echo "checked";
                                        endif;
                                    endif;
                                ?>
                                >
                                <i class="fa"></i> 
                                TMP
                            </label>
                        </div>
                        </div>
                    </div>
                    
                    <div class="col-sm-6">
                        <ul id="course-list">
                            <?php                      

                            if($code=="all"):
                                $query1 = $this->db->query("SELECT * FROM course ORDER BY course_name ASC");
                            else:

                            if(((isset($_GET['cduration']))) && ((isset($_GET['clevel']))) && ((isset($_GET['cprogram'])))):

                                if(($_GET['cduration']!="") && ($_GET['cprogram']!="") && ($_GET['clevel']!="")):

                                $query1 = $this->db->query("SELECT * FROM course where program_id = '$id' and course_level = '".$_GET['clevel']."' and course_duration = '".$_GET['cduration']."'");
                                
                                elseif(($_GET['cduration']!="") && ($_GET['cprogram']!="") && ($_GET['clevel']=="")):

                                $query1 = $this->db->query("SELECT * FROM course where program_id = '$id' and course_duration = '".$_GET['cduration']."'");
                                
                                elseif(($_GET['clevel']!="") && ($_GET['cprogram']!="") && ($_GET['cduration']=="")):

                                $query1 = $this->db->query("SELECT * FROM course where program_id = '$id' and course_level = '".$_GET['clevel']."'");
                                
                                else: 

                                $query1 = $this->db->query("SELECT * FROM course where program_id = '$id'");
                                
                                endif;

                            elseif(((isset($_GET['keyword']))) && ((isset($_GET['clevel'])))):

                                if(($_GET['clevel']!="") && ($_GET['keyword']!="")):
                                $query1 = $this->db->query("SELECT * FROM course where program_id = '$id' and course_name like '%".$_GET['keyword']."%' and course_level = '".$_GET['clevel']."'");
                                elseif(($_GET['clevel']!="") && ($_GET['keyword']=="")):
                                $query1 = $this->db->query("SELECT * FROM course where program_id = '$id' and course_level = '".$_GET['clevel']."'");
                                elseif(($_GET['clevel']=="") && ($_GET['keyword']!="")):
                                $query1 = $this->db->query("SELECT * FROM course where program_id = '$id' and course_name like '%".$_GET['keyword']."%'");
                                else:    
                                $query1 = $this->db->query("SELECT * FROM course where program_id = '$id'");
                                endif;

                            else: 

                                $query1 = $this->db->query("SELECT * FROM course where program_id = '$id'");

                            endif;

                            endif; //all
                            if($query1->num_rows != 0):
                            foreach ($query1->result() as $row){
                                $cpid = $row->program_id;
                                $cname = $row->course_name;
                                $cdesc = $row->course_desc;
                                $cslug = $row->course_slug;

                                $query2 = $this->db->query("SELECT * FROM programs where program_id = '".$cpid."'");
                                foreach ($query2->result() as $row2){
                                    $program = $row2->program_code;
                                }

                            ?>
                            <li><div class="col-sm-6">
                                <div class="box">
                                    <a href="<?php echo base_url();?>course-page/<?php echo $program.'/'.$cslug; ?>" title="<?php echo $cname; ?>" class="img-holder2">
                                    <div class="img-holder">                                
                                        <div class="overlay"></div>
                                        <img src="<?php echo base_url('assets/images/'.$program.'/'.$cname.'.jpg');?>"/>
                                        <div class="desc">
                                            <h1 class="nsize"><strong><?php echo substr($cname,0,40).'...'; ?></strong></h1>
                                            <h5 class="ssizes">
                                                <?php echo substr($cdesc,0,40).'...'; ?>
                                            </h5>
                                        </div>
                                    </div>
                                    <p>
                                        <span href="#" class="text-pink">
                                            <i class="ion-ios7-heart-outline"></i>
                                            <span>9</span>
                                        </span> 
                                        <span class="pull-right" data-toggle="tooltip" data-placement="left" title="" data-original-title="3.1">
                                            <i class="ion-star text-warning"></i>
                                            <i class="ion-star text-warning"></i>
                                            <i class="ion-star text-warning"></i>
                                            <i class="ion-star"></i>
                                            <i class="ion-star"></i>
                                        </span>                               
                                    </p>
                                    </a>
                                </div>
                            </div></li>
                            <?php }
                            else: 
                            echo "<p class='nsize bg-gray border'>To know more please contact our corporate sales at <strong>+65-684-2282</strong>.</p>";
                            endif;
                             ?>
                            
                            <div class="clearfix"></div>
                        </ul>
                    </div>

                    <div class="clearfix"></div>
                    </form>

                    <div class="col-sm-12 loads mt0">
                        <p class="text-right"><a href="#" id="load-more">click here to show more..</a></p>
                    </div><div class="clearfix"></div>

                   
                </div>
            </div>            
        </section>

        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-sm-4 text-center">
                        <p class="wcolor nsize">
                            <i class="ion-ios7-telephone"></i> &nbsp;Call
                        </p>
                        <p class="info">
                            Tel: +65 6842 2282<br/>
                            Fax: +65 6842 2202
                        </p>             
                    </div>
                    <div class="col-sm-4 text-center">
                        <p class="wcolor nsize">
                            <i class="fa fa-map-marker"></i> &nbsp;Visit
                        </p>
                        <p class="info">
                            11 Eunos Road 8 #06-01 Lobby A, Lifelong learning Institute, Singapore 408601
                        </p>             
                    </div>
                    <div class="col-sm-4 text-center">
                        <p class="wcolor nsize">
                            <i class="ion-ios7-email"></i> &nbsp;Email
                        </p>
                        <p class="info">
                            contact@ssagroup.com
                        </p>      
                    </div><div class="clearfix"></div>                    
                </div>
            </div>
            <hr/>
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <p class="pull-left">&copy; 2015 SSA Consulting Group Pte. Ltd. All rights reserved.</p>
            
                        <ul class="nav navbar-nav navbar-right">
                            <li><a href="<?php echo base_url(); ?>">Home</a></li>
                            <li><a href="<?php echo base_url(); ?>course/wpln">Courses</a></li>
                            <li><a href="<?php echo base_url(); ?>course-schedule">Schedule</a></li>
                            <li><a href="<?php echo base_url(); ?>contact-us">Contact Us</a></li>
                        </ul>
                    </div><div class="clearfix"></div>                    
                </div>
            </div>
        </footer>