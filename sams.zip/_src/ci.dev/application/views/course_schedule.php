<body id="schedule">
<div class="preload">
    <img src="<?php echo base_url('assets/images/loading.gif'); ?>">
</div>
        <header class="intro-header" style="background-image: url('<?php echo base_url('assets/images/course-banner.jpg'); ?>')">
            <div class="overlay"></div>
            <div class="container">

                <div class="row nav-wrapper">
                    <nav class="navbar navbar-custom">
                        <div class="container-fluid">
                            <!-- Brand and toggle get grouped for better mobile display -->
                            <div class="navbar-header">
                                <button type="button" class="mt40 navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                                <a class="navbar-brand" href="<?php echo base_url(); ?>">
                                   <img src="<?php echo base_url('assets/images/logo.png'); ?>" alt="logo">
                                </a>
                            </div>

                            <!-- Collect the nav links, forms, and other content for toggling -->
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav navbar-right">
                                    <li><a href="<?php echo base_url(); ?>">Home</a></li>
                                    <li><a href="<?php echo base_url(); ?>course/all">Courses</a></li>
                                    <li><a href="<?php echo base_url(); ?>course-schedule">Schedule</a></li>
                                    <li><a href="<?php echo base_url(); ?>contact-us">Contact Us</a></li>
                                    <li><a class="toggle-search" href="#search-holder">Search</a></li>
                                </ul>
                            </div><!-- /.navbar-collapse -->
                        </div><!-- /.container-fluid -->
                    </nav> <!-- end nav -->
                </div> <!-- End row -->

                <div class="row">
                    <div id="search-holder" class="col-sm-offset-1 col-sm-10 search-holder mt50">
                    <div class="col-sm-3">
                        <select class="form-control input-lg" id="programme" name="programme">
                          <option value="">Select Program</option>
                          <option value="icdl">International Computer Driving License (ICDL)</option>
                          <option value="wpln">Workplace Literacy and Numeracy (WPLN)</option>
                          <option value="edge">Executive Development for Growth &amp; Excellence (EDGE)</option>
                          <option value="wps">Workplace Skills (WPS)</option>
                          <option value="etw">Egnlish That Works (ETW)</option>
                          <option value="eatw">English @ Workplace (E@W)</option>
                          <option value="gms">Generic Manufacturing Skills (GMS)</option>
                          <option value="tmp">Tailor Made Programs (TMP)</option>
                        </select>
                    </div>    
                    <div class="col-sm-3">
                        <input class="form-control input-lg" id="keyword" name="keyword" placeholder="Enter Keyword"/>
                    </div>
                    <div class="col-sm-3">
                        <select class="form-control input-lg" id="level" name="level">
                              <option value="">Select Level</option>
                              <option value="General">General</option>
                              <option value="Core">Core</option>
                              <option value="Beginner">Beginner</option>
                              <option value="Intermediate">Intermediate</option>
                              <option value="Advanced">Advanced</option>
                              <option value="Level 1">Level 1</option>
                              <option value="Level 2">Level 2</option>
                              <option value="Level 3">Level 3</option>
                              <option value="Level 4">Level 4</option>
                              <option value="Entry-Level">Entry-Level</option>
                              <option value="Mid-Level">Mid-Level</option>
                              <option value="Experienced-Level">Mid-Level</option>
                            </select>
                    </div>
                    <div class="col-sm-3">
                        <button type="button" class="go-btn btn btn-primary input-lg">Go</button>
                    </div><div class="clearfix"></div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="site-heading">
                            <h1>Course Schedule</h1>
                            <hr class="small">
                            <span class="subheading text-uppercase">Start enroling in your favorite course.</span>
                        </div>
                    </div>
                </div>
            </div>
        </header>

       

        <section id="course-schedule" class="course-schedule">
            <div class="container">
                <div class="row">
                        <form method="get">
                        <div class="col-sm-3">
                            <div class="form-group">                                 
                                <select class="form-control input-lg" id="programmes" name="programmes">
                                  <option value="">Select Program</option>
                                  <option value="icdl">International Computer Driving License (ICDL)</option>
                                  <option value="wpln">Workplace Literacy and Numeracy (WPLN)</option>
                                  <option value="edge">Executive Development for Growth &amp; Excellence (EDGE)</option>
                                  <option value="wps">Workplace Skills (WPS)</option>
                                  <option value="etw">Egnlish That Works (ETW)</option>
                                  <option value="eatw">English @ Workplace (E@W)</option>
                                  <option value="gms">Generic Manufacturing Skills (GMS)</option>
                                  <option value="tms">Tailor Made Programs (TMS)</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">                                 
                                <input type="text" class="form-control input-lg" id="modules" name="modules" placeholder="Module Title" >
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">                                 
                                <select class="form-control input-lg" id="levels" name="levels" >
                                  <option value="">Select Level</option>
                                  <option value="General">General</option>
                                  <option value="Core">Core</option>
                                  <option value="Beginner">Beginner</option>
                                  <option value="Intermediate">Intermediate</option>
                                  <option value="Advanced">Advanced</option>
                                  <option value="Level 1">Level 1</option>
                                  <option value="Level 2">Level 2</option>
                                  <option value="Level 3">Level 3</option>
                                  <option value="Level 4">Level 4</option>
                                  <option value="Entry-Level">Entry-Level</option>
                                  <option value="Mid-Level">Mid-Level</option>
                                  <option value="Experienced-Level">Mid-Level</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">   
                                <select class="form-control input-lg" name="venues" id="venues" >
                                  <option value="">Select Venue</option>
                                  <option value="Paya Lebar">
                                    Lifelong Learning Institute (PAYA LEBAR)
                                  </option>
                                  <option value="Jurong East">
                                    Jurong Gateway Road (EAST)
                                  </option>
                                  <option value="OSC Somerset">
                                    Orchard Shopping Centre (SOMERSET)
                                  </option>
                                </select>                              
                                
                            </div>
                        </div><div class="clearfix"></div> 
                        </form>

                </div>     

                <div class="row">
                    <div class="col-sm-12 mt0 reprep">                       
                        <div id="containers" class="table-responsive">            
                            <div class="data"></div>
                            <div class="pagination"></div> 
                        </div>                          
                    </div>
                </div>           
            </div>            
        </section>

        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-sm-4 text-center">
                        <p class="wcolor nsize">
                            <i class="ion-ios7-telephone"></i> &nbsp;Call
                        </p>
                        <p class="info">
                            Tel: +65 6842 2282<br/>
                            Fax: +65 6842 2202
                        </p>             
                    </div>
                    <div class="col-sm-4 text-center">
                        <p class="wcolor nsize">
                            <i class="fa fa-map-marker"></i> &nbsp;Visit
                        </p>
                        <p class="info">
                            11 Eunos Road 8 #06-01 Lobby A, Lifelong learning Institute, Singapore 408601
                        </p>             
                    </div>
                    <div class="col-sm-4 text-center">
                        <p class="wcolor nsize">
                            <i class="ion-ios7-email"></i> &nbsp;Email
                        </p>
                        <p class="info">
                            contact@ssagroup.com
                        </p>      
                    </div><div class="clearfix"></div>                    
                </div>
            </div>
            <hr/>
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <p class="pull-left">&copy; 2015 SSA Consulting Group Pte. Ltd. All rights reserved.</p>
            
                        <ul class="nav navbar-nav navbar-right">
                            <li><a href="<?php echo base_url(); ?>">Home</a></li>
                            <li><a href="<?php echo base_url(); ?>course/wpln">Courses</a></li>
                            <li><a href="<?php echo base_url(); ?>course-schedule">Schedule</a></li>
                            <li><a href="<?php echo base_url(); ?>contact-us">Contact Us</a></li>
                        </ul>
                    </div><div class="clearfix"></div>                    
                </div>
            </div>
        </footer>