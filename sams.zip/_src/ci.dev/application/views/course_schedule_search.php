<body style="background:#fff">
<?php
if($_GET['page'])
{
$page = $_GET['page'];
$cur_page = $page;
$page -= 1;
date_default_timezone_set("Asia/Singapore"); 
$date = date('Y-m-d h:i:s');
$per_page = 10;
$previous_btn = true;
$next_btn = true;
$value = 0;
$first_btn = true;
$pagess = 0;
$last_btn = true;
$start = $page * $per_page;

$msg = "
<table class='table table-striped table-hover mt0'>
 <tr>
   <th>PROGRAM</th> 
   <th>MODULE</th>  
   <th>VENUE</th>
   <th>START</th>
   <th>END</th>
   <th class='text-center'>DAYS</th>
   <th class='text-center'>TIME</th>
   <th class='text-center'>REGISTER</th>
 </tr>
";

//---------------programmes,modules,levels,venues
if(($_GET['programmes']!="") && ($_GET['modules']!="") && ($_GET['levels']!="") && ($_GET['venues']!="")): 

$query1 = $this->db->query("SELECT * FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and programs.program_code =  '".$_GET['programmes']."'
    and course.course_name like '%".$_GET['modules']."%'
    and course.course_level = '".$_GET['levels']."'
    and event_venue.event_venue_location = '".$_GET['venues']."'
    ORDER BY event_id ASC LIMIT $start, $per_page");
      
foreach ($query1->result() as $row){
    $msg .="<tr><td class='text-uppercase'>".$row->program_code."</td>";
    $msg .="<td>".$row->course_name."</td>";
    $msg .="<td>".$row->event_venue_location."</td>";
    $msg .="<td>".$row->event_start_date."</td>";
    $msg .="<td>".$row->event_end_date."</td>";
    $msg .="<td class='text-center'>".$row->event_days."</td>";
    $msg .="<td class='text-center'>".$row->event_time_start." - ".$row->event_time_end."</td>";
    $msg .="<td class='text-center'><a class='reg-course label bg-info'>Register Now</a></td>";

}

$query_pag_num = "SELECT COUNT(event_id) AS count FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and programs.program_code =  '".$_GET['programmes']."'
    and course.course_name like '%".$_GET['modules']."%'
    and course.course_level = '".$_GET['levels']."'
    and event_venue.event_venue_location = '".$_GET['venues']."'";

$result_pag_num = mysql_query($query_pag_num);
$row = mysql_fetch_array($result_pag_num);
$count = $row['count'];

$no_of_paginations = ceil($count / $per_page);

/* ---------------Calculating the starting and endign values for the loop----------------------------------- */
if ($cur_page >= 7) {
    $start_loop = $cur_page - 3;
    if ($no_of_paginations > $cur_page + 3)
        $end_loop = $cur_page + 3;
    else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 6) {
        $start_loop = $no_of_paginations - 6;
        $end_loop = $no_of_paginations;
    } else {
        $end_loop = $no_of_paginations;
    }
} else {
    $start_loop = 1;
    if ($no_of_paginations > 7)
        $end_loop = 7;
    else
        $end_loop = $no_of_paginations;
}
/* ----------------------------------------------------------------------------------------------------------- */
$msg .= "<div class='col-sm-6 ul-right pad-right-zero'><ul class='pull-right pagination' style='background:red'>";



// FOR ENABLING THE PREVIOUS BUTTON
if ($previous_btn && $cur_page > 1) {
    $pre = $cur_page - 1;

    $msg .= "<li p='$pre' class='ping'><a href='#course-schedule''>&laquo;</a></li>";
} else if ($previous_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&laquo;</a></li>";
}
for ($i = $start_loop; $i <= $end_loop; $i++) {

    if ($cur_page == $i)
        $msg .= "<li p='$i' style='color:#fff;background-color:#006699;' class='active ping'><a href='#course-schedule'>{$i}</a></li>";
    else
        $msg .= "<li p='$i' class='ping'><a href='#course-schedule'>{$i}</a></li>";
}

// TO ENABLE THE NEXT BUTTON
if ($next_btn && $cur_page < $no_of_paginations) {
    $nex = $cur_page + 1;
    $msg .= "<li p='$nex' class='ping'><a href='#course-schedule''>&raquo;</a></li>";
} else if ($next_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&raquo;</a></li>";
}


$total_string = "<span class='total' a='$no_of_paginations'>Page <b>" . $cur_page . "</b> of <b>$no_of_paginations</b></span>";
$msg = $msg . "</ul></div>";  // Content for pagination

$msg .="<div class='col-sm-6 totalstring' >".$total_string."</div><div class='clearfix'></div>";

echo $msg;

//---------------programmes,modules,levels,venues end



//---------------programmes,modules,levels
elseif(($_GET['programmes']!="") && ($_GET['modules']!="") && ($_GET['levels']!="") && ($_GET['venues']=="")): 

$query1 = $this->db->query("SELECT * FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and programs.program_code =  '".$_GET['programmes']."'
    and course.course_name like '%".$_GET['modules']."%'
    and course.course_level = '".$_GET['levels']."'
    ORDER BY event_id ASC LIMIT $start, $per_page");
      
foreach ($query1->result() as $row){
    $msg .="<tr><td class='text-uppercase'>".$row->program_code."</td>";
    $msg .="<td>".$row->course_name."</td>";
    $msg .="<td>".$row->event_venue_location."</td>";
    $msg .="<td>".$row->event_start_date."</td>";
    $msg .="<td>".$row->event_end_date."</td>";
    $msg .="<td class='text-center'>".$row->event_days."</td>";
    $msg .="<td class='text-center'>".$row->event_time_start." - ".$row->event_time_end."</td>";
    $msg .="<td class='text-center'><a class='reg-course label bg-info'>Register Now</a></td>";

}

$query_pag_num = "SELECT COUNT(event_id) AS count FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and programs.program_code =  '".$_GET['programmes']."'
    and course.course_name like '%".$_GET['modules']."%'
    and course.course_level = '".$_GET['levels']."'";

$result_pag_num = mysql_query($query_pag_num);
$row = mysql_fetch_array($result_pag_num);
$count = $row['count'];

$no_of_paginations = ceil($count / $per_page);

/* ---------------Calculating the starting and endign values for the loop----------------------------------- */
if ($cur_page >= 7) {
    $start_loop = $cur_page - 3;
    if ($no_of_paginations > $cur_page + 3)
        $end_loop = $cur_page + 3;
    else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 6) {
        $start_loop = $no_of_paginations - 6;
        $end_loop = $no_of_paginations;
    } else {
        $end_loop = $no_of_paginations;
    }
} else {
    $start_loop = 1;
    if ($no_of_paginations > 7)
        $end_loop = 7;
    else
        $end_loop = $no_of_paginations;
}
/* ----------------------------------------------------------------------------------------------------------- */
$msg .= "<div class='col-sm-6 ul-right pad-right-zero'><ul class='pull-right pagination' style='background:red'>";



// FOR ENABLING THE PREVIOUS BUTTON
if ($previous_btn && $cur_page > 1) {
    $pre = $cur_page - 1;

    $msg .= "<li p='$pre' class='ping'><a href='#course-schedule''>&laquo;</a></li>";
} else if ($previous_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&laquo;</a></li>";
}
for ($i = $start_loop; $i <= $end_loop; $i++) {

    if ($cur_page == $i)
        $msg .= "<li p='$i' style='color:#fff;background-color:#006699;' class='active ping'><a href='#course-schedule'>{$i}</a></li>";
    else
        $msg .= "<li p='$i' class='ping'><a href='#course-schedule'>{$i}</a></li>";
}

// TO ENABLE THE NEXT BUTTON
if ($next_btn && $cur_page < $no_of_paginations) {
    $nex = $cur_page + 1;
    $msg .= "<li p='$nex' class='ping'><a href='#course-schedule''>&raquo;</a></li>";
} else if ($next_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&raquo;</a></li>";
}


$total_string = "<span class='total' a='$no_of_paginations'>Page <b>" . $cur_page . "</b> of <b>$no_of_paginations</b></span>";
$msg = $msg . "</ul></div>";  // Content for pagination

$msg .="<div class='col-sm-6 totalstring' >".$total_string."</div><div class='clearfix'></div>";

echo $msg;
//---------------programmes,modules,levels end


//---------------programmes,modules,venue
elseif(($_GET['programmes']!="") && ($_GET['modules']!="") && ($_GET['levels']=="") && ($_GET['venues']!="")): 

$query1 = $this->db->query("SELECT * FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and programs.program_code =  '".$_GET['programmes']."'
    and course.course_name like '%".$_GET['modules']."%'
    and event_venue.event_venue_location = '".$_GET['venues']."'
    ORDER BY event_id ASC LIMIT $start, $per_page");
      
foreach ($query1->result() as $row){
    $msg .="<tr><td class='text-uppercase'>".$row->program_code."</td>";
    $msg .="<td>".$row->course_name."</td>";
    $msg .="<td>".$row->event_venue_location."</td>";
    $msg .="<td>".$row->event_start_date."</td>";
    $msg .="<td>".$row->event_end_date."</td>";
    $msg .="<td class='text-center'>".$row->event_days."</td>";
    $msg .="<td class='text-center'>".$row->event_time_start." - ".$row->event_time_end."</td>";
    $msg .="<td class='text-center'><a class='reg-course label bg-info'>Register Now</a></td>";

}

$query_pag_num = "SELECT COUNT(event_id) AS count FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and programs.program_code =  '".$_GET['programmes']."'
    and course.course_name like '%".$_GET['modules']."%'
    and event_venue.event_venue_location = '".$_GET['venues']."'";

$result_pag_num = mysql_query($query_pag_num);
$row = mysql_fetch_array($result_pag_num);
$count = $row['count'];

$no_of_paginations = ceil($count / $per_page);

/* ---------------Calculating the starting and endign values for the loop----------------------------------- */
if ($cur_page >= 7) {
    $start_loop = $cur_page - 3;
    if ($no_of_paginations > $cur_page + 3)
        $end_loop = $cur_page + 3;
    else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 6) {
        $start_loop = $no_of_paginations - 6;
        $end_loop = $no_of_paginations;
    } else {
        $end_loop = $no_of_paginations;
    }
} else {
    $start_loop = 1;
    if ($no_of_paginations > 7)
        $end_loop = 7;
    else
        $end_loop = $no_of_paginations;
}
/* ----------------------------------------------------------------------------------------------------------- */
$msg .= "<div class='col-sm-6 ul-right pad-right-zero'><ul class='pull-right pagination' style='background:red'>";



// FOR ENABLING THE PREVIOUS BUTTON
if ($previous_btn && $cur_page > 1) {
    $pre = $cur_page - 1;

    $msg .= "<li p='$pre' class='ping'><a href='#course-schedule''>&laquo;</a></li>";
} else if ($previous_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&laquo;</a></li>";
}
for ($i = $start_loop; $i <= $end_loop; $i++) {

    if ($cur_page == $i)
        $msg .= "<li p='$i' style='color:#fff;background-color:#006699;' class='active ping'><a href='#course-schedule'>{$i}</a></li>";
    else
        $msg .= "<li p='$i' class='ping'><a href='#course-schedule'>{$i}</a></li>";
}

// TO ENABLE THE NEXT BUTTON
if ($next_btn && $cur_page < $no_of_paginations) {
    $nex = $cur_page + 1;
    $msg .= "<li p='$nex' class='ping'><a href='#course-schedule''>&raquo;</a></li>";
} else if ($next_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&raquo;</a></li>";
}


$total_string = "<span class='total' a='$no_of_paginations'>Page <b>" . $cur_page . "</b> of <b>$no_of_paginations</b></span>";
$msg = $msg . "</ul></div>";  // Content for pagination

$msg .="<div class='col-sm-6 totalstring' >".$total_string."</div><div class='clearfix'></div>";

echo $msg;
//---------------programmes,modules,venue end


//---------------modules,levels,venue
elseif(($_GET['programmes']=="") && ($_GET['modules']!="") && ($_GET['levels']!="") && ($_GET['venues']!="")): 

$query1 = $this->db->query("SELECT * FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and course.course_level = '".$_GET['levels']."'
    and course.course_name like '%".$_GET['modules']."%'
    and event_venue.event_venue_location = '".$_GET['venues']."'
    ORDER BY event_id ASC LIMIT $start, $per_page");
      
foreach ($query1->result() as $row){
    $msg .="<tr><td class='text-uppercase'>".$row->program_code."</td>";
    $msg .="<td>".$row->course_name."</td>";
    $msg .="<td>".$row->event_venue_location."</td>";
    $msg .="<td>".$row->event_start_date."</td>";
    $msg .="<td>".$row->event_end_date."</td>";
    $msg .="<td class='text-center'>".$row->event_days."</td>";
    $msg .="<td class='text-center'>".$row->event_time_start." - ".$row->event_time_end."</td>";
    $msg .="<td class='text-center'><a class='reg-course label bg-info'>Register Now</a></td>";

}

$query_pag_num = "SELECT COUNT(event_id) AS count FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and course.course_level = '".$_GET['levels']."'
    and course.course_name like '%".$_GET['modules']."%'
    and event_venue.event_venue_location = '".$_GET['venues']."'";

$result_pag_num = mysql_query($query_pag_num);
$row = mysql_fetch_array($result_pag_num);
$count = $row['count'];

$no_of_paginations = ceil($count / $per_page);

/* ---------------Calculating the starting and endign values for the loop----------------------------------- */
if ($cur_page >= 7) {
    $start_loop = $cur_page - 3;
    if ($no_of_paginations > $cur_page + 3)
        $end_loop = $cur_page + 3;
    else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 6) {
        $start_loop = $no_of_paginations - 6;
        $end_loop = $no_of_paginations;
    } else {
        $end_loop = $no_of_paginations;
    }
} else {
    $start_loop = 1;
    if ($no_of_paginations > 7)
        $end_loop = 7;
    else
        $end_loop = $no_of_paginations;
}
/* ----------------------------------------------------------------------------------------------------------- */
$msg .= "<div class='col-sm-6 ul-right pad-right-zero'><ul class='pull-right pagination' style='background:red'>";



// FOR ENABLING THE PREVIOUS BUTTON
if ($previous_btn && $cur_page > 1) {
    $pre = $cur_page - 1;

    $msg .= "<li p='$pre' class='ping'><a href='#course-schedule''>&laquo;</a></li>";
} else if ($previous_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&laquo;</a></li>";
}
for ($i = $start_loop; $i <= $end_loop; $i++) {

    if ($cur_page == $i)
        $msg .= "<li p='$i' style='color:#fff;background-color:#006699;' class='active ping'><a href='#course-schedule'>{$i}</a></li>";
    else
        $msg .= "<li p='$i' class='ping'><a href='#course-schedule'>{$i}</a></li>";
}

// TO ENABLE THE NEXT BUTTON
if ($next_btn && $cur_page < $no_of_paginations) {
    $nex = $cur_page + 1;
    $msg .= "<li p='$nex' class='ping'><a href='#course-schedule''>&raquo;</a></li>";
} else if ($next_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&raquo;</a></li>";
}


$total_string = "<span class='total' a='$no_of_paginations'>Page <b>" . $cur_page . "</b> of <b>$no_of_paginations</b></span>";
$msg = $msg . "</ul></div>";  // Content for pagination

$msg .="<div class='col-sm-6 totalstring' >".$total_string."</div><div class='clearfix'></div>";

echo $msg;
//---------------modules,levels,venue end



//---------------programs, modules
elseif(($_GET['programmes']!="") && ($_GET['modules']!="") && ($_GET['levels']=="") && ($_GET['venues']=="")): 

$query1 = $this->db->query("SELECT * FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and programs.program_code =  '".$_GET['programmes']."'
    and course.course_name like '%".$_GET['modules']."%'
    ORDER BY event_id ASC LIMIT $start, $per_page");
      
foreach ($query1->result() as $row){
    $msg .="<tr><td class='text-uppercase'>".$row->program_code."</td>";
    $msg .="<td>".$row->course_name."</td>";
    $msg .="<td>".$row->event_venue_location."</td>";
    $msg .="<td>".$row->event_start_date."</td>";
    $msg .="<td>".$row->event_end_date."</td>";
    $msg .="<td class='text-center'>".$row->event_days."</td>";
    $msg .="<td class='text-center'>".$row->event_time_start." - ".$row->event_time_end."</td>";
    $msg .="<td class='text-center'><a class='reg-course label bg-info'>Register Now</a></td>";

}

$query_pag_num = "SELECT COUNT(event_id) AS count FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and programs.program_code =  '".$_GET['programmes']."'
    and course.course_name like '%".$_GET['modules']."%'";

$result_pag_num = mysql_query($query_pag_num);
$row = mysql_fetch_array($result_pag_num);
$count = $row['count'];

$no_of_paginations = ceil($count / $per_page);

/* ---------------Calculating the starting and endign values for the loop----------------------------------- */
if ($cur_page >= 7) {
    $start_loop = $cur_page - 3;
    if ($no_of_paginations > $cur_page + 3)
        $end_loop = $cur_page + 3;
    else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 6) {
        $start_loop = $no_of_paginations - 6;
        $end_loop = $no_of_paginations;
    } else {
        $end_loop = $no_of_paginations;
    }
} else {
    $start_loop = 1;
    if ($no_of_paginations > 7)
        $end_loop = 7;
    else
        $end_loop = $no_of_paginations;
}
/* ----------------------------------------------------------------------------------------------------------- */
$msg .= "<div class='col-sm-6 ul-right pad-right-zero'><ul class='pull-right pagination' style='background:red'>";



// FOR ENABLING THE PREVIOUS BUTTON
if ($previous_btn && $cur_page > 1) {
    $pre = $cur_page - 1;

    $msg .= "<li p='$pre' class='ping'><a href='#course-schedule''>&laquo;</a></li>";
} else if ($previous_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&laquo;</a></li>";
}
for ($i = $start_loop; $i <= $end_loop; $i++) {

    if ($cur_page == $i)
        $msg .= "<li p='$i' style='color:#fff;background-color:#006699;' class='active ping'><a href='#course-schedule'>{$i}</a></li>";
    else
        $msg .= "<li p='$i' class='ping'><a href='#course-schedule'>{$i}</a></li>";
}

// TO ENABLE THE NEXT BUTTON
if ($next_btn && $cur_page < $no_of_paginations) {
    $nex = $cur_page + 1;
    $msg .= "<li p='$nex' class='ping'><a href='#course-schedule''>&raquo;</a></li>";
} else if ($next_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&raquo;</a></li>";
}


$total_string = "<span class='total' a='$no_of_paginations'>Page <b>" . $cur_page . "</b> of <b>$no_of_paginations</b></span>";
$msg = $msg . "</ul></div>";  // Content for pagination

$msg .="<div class='col-sm-6 totalstring' >".$total_string."</div><div class='clearfix'></div>";

echo $msg;
//---------------programs, modules end


//---------------programs, levels
elseif(($_GET['programmes']!="") && ($_GET['modules']=="") && ($_GET['levels']!="") && ($_GET['venues']=="")): 

$query1 = $this->db->query("SELECT * FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and programs.program_code =  '".$_GET['programmes']."'
    and course.course_level = '".$_GET['levels']."'
    ORDER BY event_id ASC LIMIT $start, $per_page");
      
foreach ($query1->result() as $row){
    $msg .="<tr><td class='text-uppercase'>".$row->program_code."</td>";
    $msg .="<td>".$row->course_name."</td>";
    $msg .="<td>".$row->event_venue_location."</td>";
    $msg .="<td>".$row->event_start_date."</td>";
    $msg .="<td>".$row->event_end_date."</td>";
    $msg .="<td class='text-center'>".$row->event_days."</td>";
    $msg .="<td class='text-center'>".$row->event_time_start." - ".$row->event_time_end."</td>";
    $msg .="<td class='text-center'><a class='reg-course label bg-info'>Register Now</a></td>";

}

$query_pag_num = "SELECT COUNT(event_id) AS count FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and programs.program_code =  '".$_GET['programmes']."'
    and course.course_level = '".$_GET['levels']."'";

$result_pag_num = mysql_query($query_pag_num);
$row = mysql_fetch_array($result_pag_num);
$count = $row['count'];

$no_of_paginations = ceil($count / $per_page);

/* ---------------Calculating the starting and endign values for the loop----------------------------------- */
if ($cur_page >= 7) {
    $start_loop = $cur_page - 3;
    if ($no_of_paginations > $cur_page + 3)
        $end_loop = $cur_page + 3;
    else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 6) {
        $start_loop = $no_of_paginations - 6;
        $end_loop = $no_of_paginations;
    } else {
        $end_loop = $no_of_paginations;
    }
} else {
    $start_loop = 1;
    if ($no_of_paginations > 7)
        $end_loop = 7;
    else
        $end_loop = $no_of_paginations;
}
/* ----------------------------------------------------------------------------------------------------------- */
$msg .= "<div class='col-sm-6 ul-right pad-right-zero'><ul class='pull-right pagination' style='background:red'>";



// FOR ENABLING THE PREVIOUS BUTTON
if ($previous_btn && $cur_page > 1) {
    $pre = $cur_page - 1;

    $msg .= "<li p='$pre' class='ping'><a href='#course-schedule''>&laquo;</a></li>";
} else if ($previous_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&laquo;</a></li>";
}
for ($i = $start_loop; $i <= $end_loop; $i++) {

    if ($cur_page == $i)
        $msg .= "<li p='$i' style='color:#fff;background-color:#006699;' class='active ping'><a href='#course-schedule'>{$i}</a></li>";
    else
        $msg .= "<li p='$i' class='ping'><a href='#course-schedule'>{$i}</a></li>";
}

// TO ENABLE THE NEXT BUTTON
if ($next_btn && $cur_page < $no_of_paginations) {
    $nex = $cur_page + 1;
    $msg .= "<li p='$nex' class='ping'><a href='#course-schedule''>&raquo;</a></li>";
} else if ($next_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&raquo;</a></li>";
}


$total_string = "<span class='total' a='$no_of_paginations'>Page <b>" . $cur_page . "</b> of <b>$no_of_paginations</b></span>";
$msg = $msg . "</ul></div>";  // Content for pagination

$msg .="<div class='col-sm-6 totalstring' >".$total_string."</div><div class='clearfix'></div>";

echo $msg;
//---------------programs, levels end



//---------------programs, venues
elseif(($_GET['programmes']!="") && ($_GET['modules']=="") && ($_GET['levels']=="") && ($_GET['venues']!="")): 

$query1 = $this->db->query("SELECT * FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and programs.program_code =  '".$_GET['programmes']."'
    and event_venue.event_venue_location = '".$_GET['venues']."'
    ORDER BY event_id ASC LIMIT $start, $per_page");
      
foreach ($query1->result() as $row){
    $msg .="<tr><td class='text-uppercase'>".$row->program_code."</td>";
    $msg .="<td>".$row->course_name."</td>";
    $msg .="<td>".$row->event_venue_location."</td>";
    $msg .="<td>".$row->event_start_date."</td>";
    $msg .="<td>".$row->event_end_date."</td>";
    $msg .="<td class='text-center'>".$row->event_days."</td>";
    $msg .="<td class='text-center'>".$row->event_time_start." - ".$row->event_time_end."</td>";
    $msg .="<td class='text-center'><a class='reg-course label bg-info'>Register Now</a></td>";

}

$query_pag_num = "SELECT COUNT(event_id) AS count FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and programs.program_code =  '".$_GET['programmes']."'
    and event_venue.event_venue_location = '".$_GET['venues']."'";

$result_pag_num = mysql_query($query_pag_num);
$row = mysql_fetch_array($result_pag_num);
$count = $row['count'];

$no_of_paginations = ceil($count / $per_page);

/* ---------------Calculating the starting and endign values for the loop----------------------------------- */
if ($cur_page >= 7) {
    $start_loop = $cur_page - 3;
    if ($no_of_paginations > $cur_page + 3)
        $end_loop = $cur_page + 3;
    else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 6) {
        $start_loop = $no_of_paginations - 6;
        $end_loop = $no_of_paginations;
    } else {
        $end_loop = $no_of_paginations;
    }
} else {
    $start_loop = 1;
    if ($no_of_paginations > 7)
        $end_loop = 7;
    else
        $end_loop = $no_of_paginations;
}
/* ----------------------------------------------------------------------------------------------------------- */
$msg .= "<div class='col-sm-6 ul-right pad-right-zero'><ul class='pull-right pagination' style='background:red'>";



// FOR ENABLING THE PREVIOUS BUTTON
if ($previous_btn && $cur_page > 1) {
    $pre = $cur_page - 1;

    $msg .= "<li p='$pre' class='ping'><a href='#course-schedule''>&laquo;</a></li>";
} else if ($previous_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&laquo;</a></li>";
}
for ($i = $start_loop; $i <= $end_loop; $i++) {

    if ($cur_page == $i)
        $msg .= "<li p='$i' style='color:#fff;background-color:#006699;' class='active ping'><a href='#course-schedule'>{$i}</a></li>";
    else
        $msg .= "<li p='$i' class='ping'><a href='#course-schedule'>{$i}</a></li>";
}

// TO ENABLE THE NEXT BUTTON
if ($next_btn && $cur_page < $no_of_paginations) {
    $nex = $cur_page + 1;
    $msg .= "<li p='$nex' class='ping'><a href='#course-schedule''>&raquo;</a></li>";
} else if ($next_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&raquo;</a></li>";
}


$total_string = "<span class='total' a='$no_of_paginations'>Page <b>" . $cur_page . "</b> of <b>$no_of_paginations</b></span>";
$msg = $msg . "</ul></div>";  // Content for pagination

$msg .="<div class='col-sm-6 totalstring' >".$total_string."</div><div class='clearfix'></div>";

echo $msg;
//---------------programs, venues end




//---------------modules, levels
elseif(($_GET['programmes']=="") && ($_GET['modules']!="") && ($_GET['levels']!="") && ($_GET['venues']=="")): 

$query1 = $this->db->query("SELECT * FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and course.course_name like '%".$_GET['modules']."%'
    and course.course_level = '".$_GET['levels']."'
    ORDER BY event_id ASC LIMIT $start, $per_page");
      
foreach ($query1->result() as $row){
    $msg .="<tr><td class='text-uppercase'>".$row->program_code."</td>";
    $msg .="<td>".$row->course_name."</td>";
    $msg .="<td>".$row->event_venue_location."</td>";
    $msg .="<td>".$row->event_start_date."</td>";
    $msg .="<td>".$row->event_end_date."</td>";
    $msg .="<td class='text-center'>".$row->event_days."</td>";
    $msg .="<td class='text-center'>".$row->event_time_start." - ".$row->event_time_end."</td>";
    $msg .="<td class='text-center'><a class='reg-course label bg-info'>Register Now</a></td>";

}

$query_pag_num = "SELECT COUNT(event_id) AS count FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and course.course_name like '%".$_GET['modules']."%'
    and course.course_level = '".$_GET['levels']."'";

$result_pag_num = mysql_query($query_pag_num);
$row = mysql_fetch_array($result_pag_num);
$count = $row['count'];

$no_of_paginations = ceil($count / $per_page);

/* ---------------Calculating the starting and endign values for the loop----------------------------------- */
if ($cur_page >= 7) {
    $start_loop = $cur_page - 3;
    if ($no_of_paginations > $cur_page + 3)
        $end_loop = $cur_page + 3;
    else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 6) {
        $start_loop = $no_of_paginations - 6;
        $end_loop = $no_of_paginations;
    } else {
        $end_loop = $no_of_paginations;
    }
} else {
    $start_loop = 1;
    if ($no_of_paginations > 7)
        $end_loop = 7;
    else
        $end_loop = $no_of_paginations;
}
/* ----------------------------------------------------------------------------------------------------------- */
$msg .= "<div class='col-sm-6 ul-right pad-right-zero'><ul class='pull-right pagination' style='background:red'>";



// FOR ENABLING THE PREVIOUS BUTTON
if ($previous_btn && $cur_page > 1) {
    $pre = $cur_page - 1;

    $msg .= "<li p='$pre' class='ping'><a href='#course-schedule''>&laquo;</a></li>";
} else if ($previous_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&laquo;</a></li>";
}
for ($i = $start_loop; $i <= $end_loop; $i++) {

    if ($cur_page == $i)
        $msg .= "<li p='$i' style='color:#fff;background-color:#006699;' class='active ping'><a href='#course-schedule'>{$i}</a></li>";
    else
        $msg .= "<li p='$i' class='ping'><a href='#course-schedule'>{$i}</a></li>";
}

// TO ENABLE THE NEXT BUTTON
if ($next_btn && $cur_page < $no_of_paginations) {
    $nex = $cur_page + 1;
    $msg .= "<li p='$nex' class='ping'><a href='#course-schedule''>&raquo;</a></li>";
} else if ($next_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&raquo;</a></li>";
}


$total_string = "<span class='total' a='$no_of_paginations'>Page <b>" . $cur_page . "</b> of <b>$no_of_paginations</b></span>";
$msg = $msg . "</ul></div>";  // Content for pagination

$msg .="<div class='col-sm-6 totalstring' >".$total_string."</div><div class='clearfix'></div>";

echo $msg;
//---------------modules, levels end


//---------------modules, venues
elseif(($_GET['programmes']=="") && ($_GET['modules']!="") && ($_GET['levels']=="") && ($_GET['venues']!="")): 

$query1 = $this->db->query("SELECT * FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and course.course_name like '%".$_GET['modules']."%'
    and event_venue.event_venue_location = '".$_GET['venues']."'
    ORDER BY event_id ASC LIMIT $start, $per_page");
      
foreach ($query1->result() as $row){
    $msg .="<tr><td class='text-uppercase'>".$row->program_code."</td>";
    $msg .="<td>".$row->course_name."</td>";
    $msg .="<td>".$row->event_venue_location."</td>";
    $msg .="<td>".$row->event_start_date."</td>";
    $msg .="<td>".$row->event_end_date."</td>";
    $msg .="<td class='text-center'>".$row->event_days."</td>";
    $msg .="<td class='text-center'>".$row->event_time_start." - ".$row->event_time_end."</td>";
    $msg .="<td class='text-center'><a class='reg-course label bg-info'>Register Now</a></td>";

}

$query_pag_num = "SELECT COUNT(event_id) AS count FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and course.course_name like '%".$_GET['modules']."%'
    and event_venue.event_venue_location = '".$_GET['venues']."'";

$result_pag_num = mysql_query($query_pag_num);
$row = mysql_fetch_array($result_pag_num);
$count = $row['count'];

$no_of_paginations = ceil($count / $per_page);

/* ---------------Calculating the starting and endign values for the loop----------------------------------- */
if ($cur_page >= 7) {
    $start_loop = $cur_page - 3;
    if ($no_of_paginations > $cur_page + 3)
        $end_loop = $cur_page + 3;
    else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 6) {
        $start_loop = $no_of_paginations - 6;
        $end_loop = $no_of_paginations;
    } else {
        $end_loop = $no_of_paginations;
    }
} else {
    $start_loop = 1;
    if ($no_of_paginations > 7)
        $end_loop = 7;
    else
        $end_loop = $no_of_paginations;
}
/* ----------------------------------------------------------------------------------------------------------- */
$msg .= "<div class='col-sm-6 ul-right pad-right-zero'><ul class='pull-right pagination' style='background:red'>";



// FOR ENABLING THE PREVIOUS BUTTON
if ($previous_btn && $cur_page > 1) {
    $pre = $cur_page - 1;

    $msg .= "<li p='$pre' class='ping'><a href='#course-schedule''>&laquo;</a></li>";
} else if ($previous_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&laquo;</a></li>";
}
for ($i = $start_loop; $i <= $end_loop; $i++) {

    if ($cur_page == $i)
        $msg .= "<li p='$i' style='color:#fff;background-color:#006699;' class='active ping'><a href='#course-schedule'>{$i}</a></li>";
    else
        $msg .= "<li p='$i' class='ping'><a href='#course-schedule'>{$i}</a></li>";
}

// TO ENABLE THE NEXT BUTTON
if ($next_btn && $cur_page < $no_of_paginations) {
    $nex = $cur_page + 1;
    $msg .= "<li p='$nex' class='ping'><a href='#course-schedule''>&raquo;</a></li>";
} else if ($next_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&raquo;</a></li>";
}


$total_string = "<span class='total' a='$no_of_paginations'>Page <b>" . $cur_page . "</b> of <b>$no_of_paginations</b></span>";
$msg = $msg . "</ul></div>";  // Content for pagination

$msg .="<div class='col-sm-6 totalstring' >".$total_string."</div><div class='clearfix'></div>";

echo $msg;
//---------------modules, venues end



//---------------levels, venues
elseif(($_GET['programmes']=="") && ($_GET['modules']=="") && ($_GET['levels']!="") && ($_GET['venues']!="")): 

$query1 = $this->db->query("SELECT * FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and course.course_level = '".$_GET['levels']."'
    and event_venue.event_venue_location = '".$_GET['venues']."'
    ORDER BY event_id ASC LIMIT $start, $per_page");
      
foreach ($query1->result() as $row){
    $msg .="<tr><td class='text-uppercase'>".$row->program_code."</td>";
    $msg .="<td>".$row->course_name."</td>";
    $msg .="<td>".$row->event_venue_location."</td>";
    $msg .="<td>".$row->event_start_date."</td>";
    $msg .="<td>".$row->event_end_date."</td>";
    $msg .="<td class='text-center'>".$row->event_days."</td>";
    $msg .="<td class='text-center'>".$row->event_time_start." - ".$row->event_time_end."</td>";
    $msg .="<td class='text-center'><a class='reg-course label bg-info'>Register Now</a></td>";

}

$query_pag_num = "SELECT COUNT(event_id) AS count FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and course.course_level = '".$_GET['levels']."'
    and event_venue.event_venue_location = '".$_GET['venues']."'";

$result_pag_num = mysql_query($query_pag_num);
$row = mysql_fetch_array($result_pag_num);
$count = $row['count'];

$no_of_paginations = ceil($count / $per_page);

/* ---------------Calculating the starting and endign values for the loop----------------------------------- */
if ($cur_page >= 7) {
    $start_loop = $cur_page - 3;
    if ($no_of_paginations > $cur_page + 3)
        $end_loop = $cur_page + 3;
    else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 6) {
        $start_loop = $no_of_paginations - 6;
        $end_loop = $no_of_paginations;
    } else {
        $end_loop = $no_of_paginations;
    }
} else {
    $start_loop = 1;
    if ($no_of_paginations > 7)
        $end_loop = 7;
    else
        $end_loop = $no_of_paginations;
}
/* ----------------------------------------------------------------------------------------------------------- */
$msg .= "<div class='col-sm-6 ul-right pad-right-zero'><ul class='pull-right pagination' style='background:red'>";



// FOR ENABLING THE PREVIOUS BUTTON
if ($previous_btn && $cur_page > 1) {
    $pre = $cur_page - 1;

    $msg .= "<li p='$pre' class='ping'><a href='#course-schedule''>&laquo;</a></li>";
} else if ($previous_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&laquo;</a></li>";
}
for ($i = $start_loop; $i <= $end_loop; $i++) {

    if ($cur_page == $i)
        $msg .= "<li p='$i' style='color:#fff;background-color:#006699;' class='active ping'><a href='#course-schedule'>{$i}</a></li>";
    else
        $msg .= "<li p='$i' class='ping'><a href='#course-schedule'>{$i}</a></li>";
}

// TO ENABLE THE NEXT BUTTON
if ($next_btn && $cur_page < $no_of_paginations) {
    $nex = $cur_page + 1;
    $msg .= "<li p='$nex' class='ping'><a href='#course-schedule''>&raquo;</a></li>";
} else if ($next_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&raquo;</a></li>";
}


$total_string = "<span class='total' a='$no_of_paginations'>Page <b>" . $cur_page . "</b> of <b>$no_of_paginations</b></span>";
$msg = $msg . "</ul></div>";  // Content for pagination

$msg .="<div class='col-sm-6 totalstring' >".$total_string."</div><div class='clearfix'></div>";

echo $msg;
//---------------levels, venues end


//---------------programs
elseif(($_GET['programmes']!="") && ($_GET['modules']=="") && ($_GET['levels']=="") && ($_GET['venues']=="")): 

$query1 = $this->db->query("SELECT * FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and programs.program_code =  '".$_GET['programmes']."'
    ORDER BY event_id ASC LIMIT $start, $per_page");
      
foreach ($query1->result() as $row){
    $msg .="<tr><td class='text-uppercase'>".$row->program_code."</td>";
    $msg .="<td>".$row->course_name."</td>";
    $msg .="<td>".$row->event_venue_location."</td>";
    $msg .="<td>".$row->event_start_date."</td>";
    $msg .="<td>".$row->event_end_date."</td>";
    $msg .="<td class='text-center'>".$row->event_days."</td>";
    $msg .="<td class='text-center'>".$row->event_time_start." - ".$row->event_time_end."</td>";
    $msg .="<td class='text-center'><a class='reg-course label bg-info'>Register Now</a></td>";

}

$query_pag_num = "SELECT COUNT(event_id) AS count FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and programs.program_code =  '".$_GET['programmes']."'";

$result_pag_num = mysql_query($query_pag_num);
$row = mysql_fetch_array($result_pag_num);
$count = $row['count'];

$no_of_paginations = ceil($count / $per_page);

/* ---------------Calculating the starting and endign values for the loop----------------------------------- */
if ($cur_page >= 7) {
    $start_loop = $cur_page - 3;
    if ($no_of_paginations > $cur_page + 3)
        $end_loop = $cur_page + 3;
    else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 6) {
        $start_loop = $no_of_paginations - 6;
        $end_loop = $no_of_paginations;
    } else {
        $end_loop = $no_of_paginations;
    }
} else {
    $start_loop = 1;
    if ($no_of_paginations > 7)
        $end_loop = 7;
    else
        $end_loop = $no_of_paginations;
}
/* ----------------------------------------------------------------------------------------------------------- */
$msg .= "<div class='col-sm-6 ul-right pad-right-zero'><ul class='pull-right pagination' style='background:red'>";



// FOR ENABLING THE PREVIOUS BUTTON
if ($previous_btn && $cur_page > 1) {
    $pre = $cur_page - 1;

    $msg .= "<li p='$pre' class='ping'><a href='#course-schedule''>&laquo;</a></li>";
} else if ($previous_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&laquo;</a></li>";
}
for ($i = $start_loop; $i <= $end_loop; $i++) {

    if ($cur_page == $i)
        $msg .= "<li p='$i' style='color:#fff;background-color:#006699;' class='active ping'><a href='#course-schedule'>{$i}</a></li>";
    else
        $msg .= "<li p='$i' class='ping'><a href='#course-schedule'>{$i}</a></li>";
}

// TO ENABLE THE NEXT BUTTON
if ($next_btn && $cur_page < $no_of_paginations) {
    $nex = $cur_page + 1;
    $msg .= "<li p='$nex' class='ping'><a href='#course-schedule''>&raquo;</a></li>";
} else if ($next_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&raquo;</a></li>";
}


$total_string = "<span class='total' a='$no_of_paginations'>Page <b>" . $cur_page . "</b> of <b>$no_of_paginations</b></span>";
$msg = $msg . "</ul></div>";  // Content for pagination

$msg .="<div class='col-sm-6 totalstring' >".$total_string."</div><div class='clearfix'></div>";

echo $msg;
//---------------programs end



//---------------modules
elseif(($_GET['programmes']=="") && ($_GET['modules']!="") && ($_GET['levels']=="") && ($_GET['venues']=="")): 

$query1 = $this->db->query("SELECT * FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and course.course_name like '%".$_GET['modules']."%'
    ORDER BY event_id ASC LIMIT $start, $per_page");
      
foreach ($query1->result() as $row){
    $msg .="<tr><td class='text-uppercase'>".$row->program_code."</td>";
    $msg .="<td>".$row->course_name."</td>";
    $msg .="<td>".$row->event_venue_location."</td>";
    $msg .="<td>".$row->event_start_date."</td>";
    $msg .="<td>".$row->event_end_date."</td>";
    $msg .="<td class='text-center'>".$row->event_days."</td>";
    $msg .="<td class='text-center'>".$row->event_time_start." - ".$row->event_time_end."</td>";
    $msg .="<td class='text-center'><a class='reg-course label bg-info'>Register Now</a></td>";

}

$query_pag_num = "SELECT COUNT(event_id) AS count FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and course.course_name like '%".$_GET['modules']."%'";

$result_pag_num = mysql_query($query_pag_num);
$row = mysql_fetch_array($result_pag_num);
$count = $row['count'];

$no_of_paginations = ceil($count / $per_page);

/* ---------------Calculating the starting and endign values for the loop----------------------------------- */
if ($cur_page >= 7) {
    $start_loop = $cur_page - 3;
    if ($no_of_paginations > $cur_page + 3)
        $end_loop = $cur_page + 3;
    else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 6) {
        $start_loop = $no_of_paginations - 6;
        $end_loop = $no_of_paginations;
    } else {
        $end_loop = $no_of_paginations;
    }
} else {
    $start_loop = 1;
    if ($no_of_paginations > 7)
        $end_loop = 7;
    else
        $end_loop = $no_of_paginations;
}
/* ----------------------------------------------------------------------------------------------------------- */
$msg .= "<div class='col-sm-6 ul-right pad-right-zero'><ul class='pull-right pagination' style='background:red'>";



// FOR ENABLING THE PREVIOUS BUTTON
if ($previous_btn && $cur_page > 1) {
    $pre = $cur_page - 1;

    $msg .= "<li p='$pre' class='ping'><a href='#course-schedule''>&laquo;</a></li>";
} else if ($previous_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&laquo;</a></li>";
}
for ($i = $start_loop; $i <= $end_loop; $i++) {

    if ($cur_page == $i)
        $msg .= "<li p='$i' style='color:#fff;background-color:#006699;' class='active ping'><a href='#course-schedule'>{$i}</a></li>";
    else
        $msg .= "<li p='$i' class='ping'><a href='#course-schedule'>{$i}</a></li>";
}

// TO ENABLE THE NEXT BUTTON
if ($next_btn && $cur_page < $no_of_paginations) {
    $nex = $cur_page + 1;
    $msg .= "<li p='$nex' class='ping'><a href='#course-schedule''>&raquo;</a></li>";
} else if ($next_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&raquo;</a></li>";
}


$total_string = "<span class='total' a='$no_of_paginations'>Page <b>" . $cur_page . "</b> of <b>$no_of_paginations</b></span>";
$msg = $msg . "</ul></div>";  // Content for pagination

$msg .="<div class='col-sm-6 totalstring' >".$total_string."</div><div class='clearfix'></div>";

echo $msg;
//---------------modules end


//---------------levels
elseif(($_GET['programmes']=="") && ($_GET['modules']=="") && ($_GET['levels']!="") && ($_GET['venues']=="")): 

$query1 = $this->db->query("SELECT * FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and course.course_level = '".$_GET['levels']."'
    ORDER BY event_id ASC LIMIT $start, $per_page");
      
foreach ($query1->result() as $row){
    $msg .="<tr><td class='text-uppercase'>".$row->program_code."</td>";
    $msg .="<td>".$row->course_name."</td>";
    $msg .="<td>".$row->event_venue_location."</td>";
    $msg .="<td>".$row->event_start_date."</td>";
    $msg .="<td>".$row->event_end_date."</td>";
    $msg .="<td class='text-center'>".$row->event_days."</td>";
    $msg .="<td class='text-center'>".$row->event_time_start." - ".$row->event_time_end."</td>";
    $msg .="<td class='text-center'><a class='reg-course label bg-info'>Register Now</a></td>";

}

$query_pag_num = "SELECT COUNT(event_id) AS count FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and course.course_level = '".$_GET['levels']."'";

$result_pag_num = mysql_query($query_pag_num);
$row = mysql_fetch_array($result_pag_num);
$count = $row['count'];

$no_of_paginations = ceil($count / $per_page);

/* ---------------Calculating the starting and endign values for the loop----------------------------------- */
if ($cur_page >= 7) {
    $start_loop = $cur_page - 3;
    if ($no_of_paginations > $cur_page + 3)
        $end_loop = $cur_page + 3;
    else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 6) {
        $start_loop = $no_of_paginations - 6;
        $end_loop = $no_of_paginations;
    } else {
        $end_loop = $no_of_paginations;
    }
} else {
    $start_loop = 1;
    if ($no_of_paginations > 7)
        $end_loop = 7;
    else
        $end_loop = $no_of_paginations;
}
/* ----------------------------------------------------------------------------------------------------------- */
$msg .= "<div class='col-sm-6 ul-right pad-right-zero'><ul class='pull-right pagination' style='background:red'>";



// FOR ENABLING THE PREVIOUS BUTTON
if ($previous_btn && $cur_page > 1) {
    $pre = $cur_page - 1;

    $msg .= "<li p='$pre' class='ping'><a href='#course-schedule''>&laquo;</a></li>";
} else if ($previous_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&laquo;</a></li>";
}
for ($i = $start_loop; $i <= $end_loop; $i++) {

    if ($cur_page == $i)
        $msg .= "<li p='$i' style='color:#fff;background-color:#006699;' class='active ping'><a href='#course-schedule'>{$i}</a></li>";
    else
        $msg .= "<li p='$i' class='ping'><a href='#course-schedule'>{$i}</a></li>";
}

// TO ENABLE THE NEXT BUTTON
if ($next_btn && $cur_page < $no_of_paginations) {
    $nex = $cur_page + 1;
    $msg .= "<li p='$nex' class='ping'><a href='#course-schedule''>&raquo;</a></li>";
} else if ($next_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&raquo;</a></li>";
}


$total_string = "<span class='total' a='$no_of_paginations'>Page <b>" . $cur_page . "</b> of <b>$no_of_paginations</b></span>";
$msg = $msg . "</ul></div>";  // Content for pagination

$msg .="<div class='col-sm-6 totalstring' >".$total_string."</div><div class='clearfix'></div>";

echo $msg;
//---------------levels end


//---------------venues
elseif(($_GET['programmes']=="") && ($_GET['modules']=="") && ($_GET['levels']=="") && ($_GET['venues']!="")): 

$query1 = $this->db->query("SELECT * FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and event_venue.event_venue_location = '".$_GET['venues']."'
    ORDER BY event_id ASC LIMIT $start, $per_page");
      
foreach ($query1->result() as $row){
    $msg .="<tr><td class='text-uppercase'>".$row->program_code."</td>";
    $msg .="<td>".$row->course_name."</td>";
    $msg .="<td>".$row->event_venue_location."</td>";
    $msg .="<td>".$row->event_start_date."</td>";
    $msg .="<td>".$row->event_end_date."</td>";
    $msg .="<td class='text-center'>".$row->event_days."</td>";
    $msg .="<td class='text-center'>".$row->event_time_start." - ".$row->event_time_end."</td>";
    $msg .="<td class='text-center'><a class='reg-course label bg-info'>Register Now</a></td>";

}

$query_pag_num = "SELECT COUNT(event_id) AS count FROM event INNER JOIN course on 
    event.course_id = course.course_id INNER JOIN programs on 
    course.program_id = programs.program_id INNER JOIN event_venue on 
    event.event_venue_id = event_venue.event_venue_id 
    where event_start_date > CURDATE() 
    and event_venue.event_venue_location = '".$_GET['venues']."'";

$result_pag_num = mysql_query($query_pag_num);
$row = mysql_fetch_array($result_pag_num);
$count = $row['count'];

$no_of_paginations = ceil($count / $per_page);

/* ---------------Calculating the starting and endign values for the loop----------------------------------- */
if ($cur_page >= 7) {
    $start_loop = $cur_page - 3;
    if ($no_of_paginations > $cur_page + 3)
        $end_loop = $cur_page + 3;
    else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 6) {
        $start_loop = $no_of_paginations - 6;
        $end_loop = $no_of_paginations;
    } else {
        $end_loop = $no_of_paginations;
    }
} else {
    $start_loop = 1;
    if ($no_of_paginations > 7)
        $end_loop = 7;
    else
        $end_loop = $no_of_paginations;
}
/* ----------------------------------------------------------------------------------------------------------- */
$msg .= "<div class='col-sm-6 ul-right pad-right-zero'><ul class='pull-right pagination' style='background:red'>";



// FOR ENABLING THE PREVIOUS BUTTON
if ($previous_btn && $cur_page > 1) {
    $pre = $cur_page - 1;

    $msg .= "<li p='$pre' class='ping'><a href='#course-schedule''>&laquo;</a></li>";
} else if ($previous_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&laquo;</a></li>";
}
for ($i = $start_loop; $i <= $end_loop; $i++) {

    if ($cur_page == $i)
        $msg .= "<li p='$i' style='color:#fff;background-color:#006699;' class='active ping'><a href='#course-schedule'>{$i}</a></li>";
    else
        $msg .= "<li p='$i' class='ping'><a href='#course-schedule'>{$i}</a></li>";
}

// TO ENABLE THE NEXT BUTTON
if ($next_btn && $cur_page < $no_of_paginations) {
    $nex = $cur_page + 1;
    $msg .= "<li p='$nex' class='ping'><a href='#course-schedule''>&raquo;</a></li>";
} else if ($next_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&raquo;</a></li>";
}


$total_string = "<span class='total' a='$no_of_paginations'>Page <b>" . $cur_page . "</b> of <b>$no_of_paginations</b></span>";
$msg = $msg . "</ul></div>";  // Content for pagination

$msg .="<div class='col-sm-6 totalstring' >".$total_string."</div><div class='clearfix'></div>";

echo $msg;
//---------------venues end



else:

$query1 = $this->db->query("SELECT * FROM event INNER JOIN course on event.course_id = course.course_id INNER JOIN programs on course.program_id = programs.program_id INNER JOIN event_venue on event.event_venue_id = event_venue.event_venue_id where event_start_date > CURDATE() ORDER BY event_id ASC LIMIT $start, $per_page");
      
foreach ($query1->result() as $row){
    $msg .="<tr><td class='text-uppercase'>".$row->program_code."</td>";
    $msg .="<td>".$row->course_name."</td>";
    $msg .="<td>".$row->event_venue_location."</td>";
    $msg .="<td>".$row->event_start_date."</td>";
    $msg .="<td>".$row->event_end_date."</td>";
    $msg .="<td class='text-center'>".$row->event_days."</td>";
    $msg .="<td class='text-center'>".$row->event_time_start." - ".$row->event_time_end."</td>";
    $msg .="<td class='text-center'><a class='reg-course label bg-info'>Register Now</a></td>";

}

$query_pag_num = "SELECT COUNT(event_id) AS count from event where event_start_date > CURDATE()";

$result_pag_num = mysql_query($query_pag_num);
$row = mysql_fetch_array($result_pag_num);
$count = $row['count'];

$no_of_paginations = ceil($count / $per_page);

/* ---------------Calculating the starting and endign values for the loop----------------------------------- */
if ($cur_page >= 7) {
    $start_loop = $cur_page - 3;
    if ($no_of_paginations > $cur_page + 3)
        $end_loop = $cur_page + 3;
    else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 6) {
        $start_loop = $no_of_paginations - 6;
        $end_loop = $no_of_paginations;
    } else {
        $end_loop = $no_of_paginations;
    }
} else {
    $start_loop = 1;
    if ($no_of_paginations > 7)
        $end_loop = 7;
    else
        $end_loop = $no_of_paginations;
}
/* ----------------------------------------------------------------------------------------------------------- */
$msg .= "<div class='col-sm-6 ul-right pad-right-zero'><ul class='pull-right pagination' style='background:red'>";



// FOR ENABLING THE PREVIOUS BUTTON
if ($previous_btn && $cur_page > 1) {
    $pre = $cur_page - 1;

    $msg .= "<li p='$pre' class='ping'><a href='#course-schedule''>&laquo;</a></li>";
} else if ($previous_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&laquo;</a></li>";
}
for ($i = $start_loop; $i <= $end_loop; $i++) {

    if ($cur_page == $i)
        $msg .= "<li p='$i' style='color:#fff;background-color:#006699;' class='active ping'><a href='#course-schedule'>{$i}</a></li>";
    else
        $msg .= "<li p='$i' class='ping'><a href='#course-schedule'>{$i}</a></li>";
}

// TO ENABLE THE NEXT BUTTON
if ($next_btn && $cur_page < $no_of_paginations) {
    $nex = $cur_page + 1;
    $msg .= "<li p='$nex' class='ping'><a href='#course-schedule''>&raquo;</a></li>";
} else if ($next_btn) {
    $msg .= "<li class='active'><a href='#course-schedule''>&raquo;</a></li>";
}


$total_string = "<span class='total' a='$no_of_paginations'>Page <b>" . $cur_page . "</b> of <b>$no_of_paginations</b></span>";
$msg = $msg . "</ul></div>";  // Content for pagination

$msg .="<div class='col-sm-6 totalstring' >".$total_string."</div><div class='clearfix'></div>";

echo $msg;

endif;

}

