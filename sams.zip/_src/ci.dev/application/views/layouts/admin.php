<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="shortcut icon" href="<?php echo base_url('assets/img/logo1.png'); ?>">

        <title>theRECEIPT | <?= $template['title'] ?><?= $template['sub_title'] ?' - ' . $template['sub_title'] : '' ?></title>

        <!-- Google-Fonts -->
        <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:100,300,400,600,700,900,400italic' rel='stylesheet'>

        <!-- Bootstrap core CSS -->
        <link href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>" rel="stylesheet">
        <link href="<?php echo base_url('assets/css/bootstrap-reset.css'); ?>" rel="stylesheet">

        <!--Animation css-->
        <link href="<?php echo base_url('assets/css/animate.css'); ?>" rel="stylesheet">

        <!--Icon-fonts css-->
        <link href="<?php echo base_url('assets/plugin/font-awesome/css/font-awesome.css'); ?>" rel="stylesheet" />
        <link href="<?php echo base_url('assets/plugin/ionicon/css/ionicons.min.css'); ?>" rel="stylesheet" />

        <?php if(($template['sub_title']=="Add New Receipt") || ($template['sub_title']=="All Receipts") || ($template['sub_title']=="All Participants") || ($template['sub_title']=="All Users")) : ?>
        <link href="<?php echo base_url('assets/plugin/modal-effect/css/component.css'); ?>" rel="stylesheet" />
        <?php endif; ?>

        <!-- Custom styles for this template -->
        <link href="<?php echo base_url('assets/css/style.css'); ?>" rel="stylesheet">
        <link href="<?php echo base_url('assets/css/helper.css'); ?>" rel="stylesheet">
        <link href="<?php echo base_url('assets/css/style-responsive.css'); ?>" rel="stylesheet" />


        <?php if($template['sub_title']=="Timestamp") : ?>
        <?php 

        $db_username = 'root';
        $db_password = 'root';
        $db_name = 'ssagroup_thereceipt';
        $db_host = 'localhost';
        $items_per_group = 5;

        $mysqli = new mysqli($db_host, $db_username, $db_password, $db_name);
        //Output any connection error
        if ($mysqli->connect_error) {
            die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
        }

        $get_total_rows = 0;
        $results = $mysqli->query("SELECT COUNT(*) FROM transaction_history");

        if($results){
            $get_total_rows = $results->fetch_row(); 
        }
        //break total records into pages
        $total_groups= ceil($get_total_rows[0]/$items_per_group);   
        

        ?>
        

        <?php endif; ?>
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
        <script type="text/javascript">
            var base_url = '<?= base_url() ?>';
            var controller = '<?= !empty($controller) ? $controller : '' ?>';
        </script>
    </head>

    <body>
        <!--<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>-->
     
        <div id="wrapper">

            <!-- Header -->
            <?php if (isset($template['partials']['header'])) echo $template['partials']['header']; ?>
            <!-- /Header -->

            <div id="page-wrapper">
                <?php echo $template['body']; ?>
            </div>
            <!-- /#page-wrapper -->

        </div>
        <!-- /#wrapper -->

        <!-- js placed at the end of the document so the pages load faster -->

        

        

        <?php if($template['sub_title']=="Search Receipts" || $template['sub_title']=="View All Receipts" || $template['sub_title']=="View All Received Receipts" || $template['sub_title']=="View All Cancelled Receipts" || $template['sub_title']=="View All Participants" || $template['sub_title']=="View All Delete Participants" || $template['sub_title']=="View All Users" || $template['sub_title']=="View All Main Users" || $template['sub_title']=="View All Branch Users"): ?>
        
        <?php else: ?>       
        <script src="<?php echo base_url('assets/js/jquery.js'); ?>"></script>      
        <script src="<?php echo base_url('assets/js/jquery.app.js'); ?>"></script>  
        <script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>    
        <script src="<?php echo base_url('assets/js/pace.min.js'); ?>"></script>
        <script src="<?php echo base_url('assets/js/jquery.scrollTo.min.js'); ?>"></script>

        <script src="<?php echo base_url('assets/js/jquery.nicescroll.js'); ?>"></script>
        <script src="<?php echo base_url('assets/js/waypoints.min.js'); ?>"></script>
        <?php endif; ?>
        
        <script src="<?php echo base_url('assets/js/modernizr.min.js'); ?>"></script> 
        <script src="<?php echo base_url('assets/js/wow.min.js'); ?>"></script>

        <?php if($template['sub_title']=="Timestamp"): ?>

  
        <script type="text/javascript">
            $(document).ready(function() {
                var track_load = 0; //total loaded record group(s)
                var loading  = false; //to prevents multipal ajax loads
                var total_groups = <?=$total_groups;?>; //total record group(s)


                
                $('#results').load("autoload-process", {'group_no':track_load}, function() {track_load++;}); //load first group
                
                $(window).scroll(function() { //detect page scroll
                    
                    if($(window).scrollTop() + $(window).height() == $(document).height())  //user scrolled to bottom of the page?
                    {
                        
                        if(track_load <= total_groups && loading==false) //there's more data to load
                        {
                            loading = true; //prevent further ajax loading
                            $('.animation_image').show(); //show loading image
                            
                            //load data from the server using a HTTP POST request
                            $.post('autoload-process',{'group_no': track_load}, function(data){
                                                
                                $("#results").append(data); //append received data into the element

                                //hide loading image
                                $('.animation_image').hide(); //hide loading image once data is received
                                
                                track_load++; //loaded group increment
                                loading = false; 
                            
                            }).fail(function(xhr, ajaxOptions, thrownError) { //any errors?
                                
                                alert(thrownError); //alert with HTTP error
                                $('.animation_image').hide(); //hide loading image
                                loading = false;
                            
                            });
                            
                        }
                    }
                });
            });
        </script>
        <?php endif; ?>

        <!-- Append additional scripts from controller -->
        <?php echo $template['metadata']; ?>

    </body>

</html>
