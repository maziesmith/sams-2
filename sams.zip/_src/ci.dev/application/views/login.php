<body id="login">

    <div class="wrapper-pages">
        <div class="text-center">
            <div class="moving"></div>
            <img src="<?php echo base_url('assets/img/logo.png'); ?>" class="logoness" style="width:70%;margin-bottom:25px"/>
        </div>
        <div class="wrap-me">
        <div class="panel panel-color panel-primary">
            <div class="panel-heading"> 
               <h3 class="text-center m-t-10"> Sign In to <strong class="title-animation animated">theRECEIPT</strong> </h3>
            </div> 

            <form class="form-horizontal m-t-35" id="LoginForm" role="form" type="POST">
                   <p class="help-block"></p>                     
                <div class="form-group">
                 
                    <div class="col-xs-12">
                        <input class="form-control input-lg login-username"  name="Username" type="text" placeholder="Username">
                    </div>
                </div>
                <div class="form-group">
                    
                    <div class="col-xs-12">
                        <input class="form-control input-lg login-password" name="Password" type="password" placeholder="Password">
                    </div>
                </div>

                
                <div class="col-xs-6">
                    <div class="form-group">
                        <label class="cr-styled">
                            <input type="checkbox" checked>
                            <i class="fa"></i> 
                            Remember me
                        </label>
                    </div>
                </div>
                
                <div class="col-xs-6">
                    <div class="form-group text-right">                        
                        <button id="Login" class="btn btn-info w-md" type="button">Log In</button>
                    </div>
                </div>
                <div class="col-xs-12 text-center ">
                    <div class="form-group">                        
                        <a href="#"><i class="fa fa-lock m-r-5"></i> Forgot your password?</a>
                    </div>                        
                </div><div class="clearfix"></div>
            </form>

        </div><div class="clearfix"></div>
        </div>
    </div>