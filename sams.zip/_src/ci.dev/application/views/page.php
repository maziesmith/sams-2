<body id="page">
<div class="preload">
    <img src="<?php echo base_url('assets/images/loading.gif'); ?>">
</div>
    <?php 
    foreach($result as $row){
                $cid = $row->course_id;
                $pid = $row->program_id;
                $cname = $row->course_name;
                $cdesc = $row->course_desc;
                $cline = $row->course_outline;
                $cdur = $row->course_duration;
                $cfee_non_wts_new = $row->course_fee_non_wts_new;
                $cfee_non_wts_sub = $row->course_fee_non_wts_subsequent;
                $cfee_wts_new = $row->course_fee_wts_new;
                $cfee_wts_sub = $row->course_fee_wts_subsequent;
                $cfee_for_new = $row->course_fee_foreigner_new;
                $cfee_for_sub = $row->course_fee_foreigner_subsequent;
                $clevel = $row->course_level;
                
    }
    $code = $this->uri->segment(2);
    ?>
        <header class="intro-header" style="background-image: url('<?php echo base_url('assets/images/'.$code.'/'.$cname.'.jpg'); ?>')">
            <div class="overlay"></div>
            <div class="container">

                <div class="row nav-wrapper">
                    <nav class="navbar navbar-custom">
                        <div class="container-fluid">
                            <!-- Brand and toggle get grouped for better mobile display -->
                            <div class="navbar-header">
                                <button type="button" class="mt40 navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                                <a class="navbar-brand" href="<?php echo base_url(); ?>">
                                   <img src="<?php echo base_url('assets/images/logo.png'); ?>" alt="logo">
                                </a>
                            </div>

                            <!-- Collect the nav links, forms, and other content for toggling -->
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav navbar-right">
                                    <li><a href="<?php echo base_url(); ?>">Home</a></li>
                                    <li><a href="<?php echo base_url(); ?>course/all">Courses</a></li>
                                    <li><a href="<?php echo base_url(); ?>course-schedule">Schedule</a></li>
                                    <li><a href="<?php echo base_url(); ?>contact-us">Contact Us</a></li>
                                    <li><a class="toggle-search" href="#search-holder">Search</a></li>
                                </ul>
                            </div><!-- /.navbar-collapse -->
                        </div><!-- /.container-fluid -->
                    </nav> <!-- end nav -->
                </div> <!-- End row -->

                <div class="row">
                    <div id="search-holder" class="col-sm-offset-1 col-sm-10 search-holder mt50">
                    <div class="col-sm-3">
                        <select class="form-control input-lg" id="programme" name="programme">
                          <option value="">Select Program</option>
                          <option value="icdl">International Computer Driving License (ICDL)</option>
                          <option value="wpln">Workplace Literacy and Numeracy (WPLN)</option>
                          <option value="edge">Executive Development for Growth &amp; Excellence (EDGE)</option>
                          <option value="wps">Workplace Skills (WPS)</option>
                          <option value="etw">Egnlish That Works (ETW)</option>
                          <option value="eatw">English @ Workplace (E@W)</option>
                          <option value="gms">Generic Manufacturing Skills (GMS)</option>
                          <option value="tmp">Tailor Made Programs (TMP)</option>
                        </select>
                    </div>    
                    <div class="col-sm-3">
                        <input class="form-control input-lg" id="keyword" name="keyword" placeholder="Enter Keyword"/>
                    </div>
                    <div class="col-sm-3">
                        <select class="form-control input-lg" id="level" name="level">
                              <option value="">Select Level</option>
                              <option value="General">General</option>
                              <option value="Core">Core</option>
                              <option value="Beginner">Beginner</option>
                              <option value="Intermediate">Intermediate</option>
                              <option value="Advanced">Advanced</option>
                              <option value="Level 1">Level 1</option>
                              <option value="Level 2">Level 2</option>
                              <option value="Level 3">Level 3</option>
                              <option value="Level 4">Level 4</option>
                              <option value="Entry-Level">Entry-Level</option>
                              <option value="Mid-Level">Mid-Level</option>
                              <option value="Experienced-Level">Mid-Level</option>
                            </select>
                    </div>
                    <div class="col-sm-3">
                        <button type="button" class="go-btn btn btn-primary input-lg">Go</button>
                    </div><div class="clearfix"></div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="site-heading">
                            <h1><?php echo $cname; ?></h1>
                            <hr class="small">
                            <span class="subheading text-uppercase"><?php echo $code; ?> COURSE</span>
                        </div>
                    </div>
                </div>
            </div>
        </header>

       

        <section id="page" class="page">
            <div class="container">

                <div class="row">               
                    <div class="col-sm-3 left mb40">

                        <ul class="nav nav-tabs" role="tablist">

                            <li role="presentation" class="active"><a href="#about-tab" aria-controls="about-tab" role="tab" data-toggle="tab">ABOUT</a></li>
                            <li role="presentation"><a href="#outline-tab" aria-controls="outline-tab" role="tab" data-toggle="tab">COURSE OUTLINE</a></li>
                            <li role="presentation"><a href="#schedule-tab" aria-controls="schedule-tab" role="tab" data-toggle="tab">COURSE SCHEDULE</a></li>
                            <li role="presentation"><a href="#fee-tab" aria-controls="fee-tab" role="tab" data-toggle="tab">COURSE FEE</a></li>

                        </ul> 

                        <span class="focus"><i class="fa fa-caret-right theme-color msize"></i></span>

                      
                        <div class="rate1">
                            <h5 class="nsize mb0 text-center">Like it
                                <a href="#" class="text-pink" title="Like">
                                    <i class="ion-ios7-heart-outline"></i>
                                </a>
                            </h5>
                            <p class="text-center"><i class="ion-ios7-heart text-pink"></i> 125 who likes this course.</p> 
                        </div>
                        <div class="rate2">
                            <h5 class="nsize mb0 text-center">
                                <a href="#" title="Rate as 1 star.">
                                    <i class="ion-ios7-star-outline text-warning"></i>
                                </a>
                                <a href="#" title="Rate as 2 stars.">
                                    <i class="ion-ios7-star-outline text-warning"></i>
                                </a>
                                <a href="#" title="Rate as 3 stars.">
                                    <i class="ion-ios7-star-outline text-warning"></i>
                                </a>
                                <a href="#" title="Rate as 4 stars.">
                                    <i class="ion-ios7-star-outline text-warning"></i>
                                </a>
                                <a href="#" title="Rate as 5 stars.">
                                    <i class="ion-ios7-star-outline text-warning"></i>
                                </a>

                            </h5>
                            <p class="text-center"><i class="ion-star text-warning"></i> rate this course.</p> 
                        </div>
                        

                       
                    </div>
                    <?php 


                        $title=urlencode($cname);                        
                        $url=urlencode(current_url());
                        $string = $cdesc;
                        $limited = substr(strip_tags($string), 0, 200).'..';
                        $summary=urlencode($limited);
                        $image=urlencode(base_url('assets/images/'.$code.'/'.$cname.'.jpg'));

                    ?>
                    <div class="col-sm-9 pad-right-zero right">
                        <div class="tab-content">
                            <div role="tabpanel" class="tab-pane fade in active" id="about-tab">
                                <div class="col-sm-9">
                                    <h1 class="mt0 msizes mb0">
                                        <?php echo $cname; ?>
                                    </h1>
                                    <h5 class="mt0 nsize">
                                        About Course
                                    </h5> 
                                </div>
                                <div class="col-sm-3">
                                    <h1 class="pull-right mt0 msize mb0 social-share">
                                        <a onclick="PopupCenter('http://www.facebook.com/sharer.php?s=100&amp;p[title]=<?php echo $title;?>&amp;p[summary]=<?php echo $summary;?>&amp;p[url]=<?php echo $url; ?>&amp;&p[images][0]=<?php echo $image;?>', 'myPop1',400,400);" href="javascript:void(0);" target="_parent">
                                            <i class="ion-social-facebook"></i>
                                        </a>
                                        <a onclick="PopupCenter('http://twitter.com/share?text=<?php echo $cname; ?>&url=<?php echo current_url(); ?>&via=training_ssa', 'myPop1',400,400);" href="javascript:void(0);" target="_parent">
                                            <i class="ion-social-twitter"></i>
                                        </a>
                                        <a onclick="PopupCenter('http://www.linkedin.com/shareArticle?mini=true&url=<?php echo current_url(); ?>&title=<?php echo $cname; ?>&summary=<?php echo $summary; ?>&source=<?php echo $url; ?>', 'myPop1',400,400);" href="javascript:void(0);" target="_parent">
                                            <i class="fa fa-linkedin"></i>
                                        </a>
                                    </h1>
                                </div><div class="clearfix"></div>

                                <div class="col-sm-12 mt10">
                                    <p class="text-justify">
                                        <?php echo $cdesc; ?>
                                    </p>                                   
                                </div><div class="clearfix"></div>

                                <div class="col-sm-4">
                                    <h3 class="text-center">
                                        Target Audience
                                    </h3>
                                    <p class="target-audience mb0 text-center">
                                        <a href="#">
                                            <i class="fa fa-tag"></i> &nbsp; Rank in File
                                        </a>
                                        <a href="#">
                                            <i class="fa fa-tag"></i> &nbsp; Supervisor
                                        </a>
                                    </p>
                                </div>
                                <div class="col-sm-4">
                                    <h3 class="text-center">
                                        Duration
                                    </h3>
                                    <p class="duration mb0 text-center">
                                        <a href="#">
                                            <i class="ion-ios7-clock"></i> &nbsp; <?php echo $cdur; ?>hrs
                                        </a>
                                        
                                    </p>
                                </div>
                                <div class="col-sm-4">
                                    <h3 class="text-center">
                                        Level
                                    </h3>
                                    <p class="duration mb0 text-center">
                                        <a href="#">
                                            <?php if($clevel!=""):?><i class="fa fa-level-up"></i> &nbsp; <?php echo $clevel; ?> <?php else : echo 'NA'; endif; ?>
                                        </a>
                                        
                                    </p>
                                </div><div class="clearfix"></div>

                                
                            </div>

                            <div role="tabpanel" class="tab-pane fade" id="outline-tab">
                                <div class="col-sm-9">
                                    <h1 class="mt0 msizes mb0">
                                        <?php echo $cname; ?>
                                    </h1>
                                    <h5 class="mt0 nsize">
                                        Course Outline
                                    </h5> 
                                </div>
                                <div class="col-sm-3">
                                    <h1 class="pull-right mt0 msize mb0 social-share">
                                        <a onclick="PopupCenter('http://www.facebook.com/sharer.php?s=100&amp;p[title]=<?php echo $title;?>&amp;p[summary]=<?php echo $summary;?>&amp;p[url]=<?php echo $url; ?>&amp;&p[images][0]=<?php echo $image;?>', 'myPop1',400,400);" href="javascript:void(0);" target="_parent">
                                            <i class="ion-social-facebook"></i>
                                        </a>
                                        <a onclick="PopupCenter('http://twitter.com/share?text=<?php echo $cname; ?>&url=<?php echo current_url(); ?>&via=training_ssa', 'myPop1',400,400);" href="javascript:void(0);" target="_parent">
                                            <i class="ion-social-twitter"></i>
                                        </a>
                                        <a onclick="PopupCenter('http://www.linkedin.com/shareArticle?mini=true&url=<?php echo current_url(); ?>&title=<?php echo $cname; ?>&summary=<?php echo $summary; ?>&source=<?php echo $url; ?>', 'myPop1',400,400);" href="javascript:void(0);" target="_parent">
                                            <i class="fa fa-linkedin"></i>
                                        </a>
                                    </h1>
                                </div><div class="clearfix"></div>

                                <div class="col-sm-12 mt10">
                                    <ul class="outline-info"> 
                                        <?php echo $cline; ?>
                                    </ul>
                                </div><div class="clearfix"></div>
                            </div>

                            <div role="tabpanel" class="tab-pane fade" id="schedule-tab">
                                <div class="col-sm-9">
                                    <h1 class="mt0 msizes mb0">
                                        <?php echo $cname; ?>
                                    </h1>
                                    <h5 class="mt0 nsize">
                                        Course Schedule
                                    </h5> 
                                </div>
                                <div class="col-sm-3">
                                    <h1 class="pull-right mt0 msize mb0 social-share">
                                        <a onclick="PopupCenter('http://www.facebook.com/sharer.php?s=100&amp;p[title]=<?php echo $title;?>&amp;p[summary]=<?php echo $summary;?>&amp;p[url]=<?php echo $url; ?>&amp;&p[images][0]=<?php echo $image;?>', 'myPop1',400,400);" href="javascript:void(0);" target="_parent">
                                            <i class="ion-social-facebook"></i>
                                        </a>
                                        <a onclick="PopupCenter('http://twitter.com/share?text=<?php echo $cname; ?>&url=<?php echo current_url(); ?>&via=training_ssa', 'myPop1',400,400);" href="javascript:void(0);" target="_parent">
                                            <i class="ion-social-twitter"></i>
                                        </a>
                                        <a onclick="PopupCenter('http://www.linkedin.com/shareArticle?mini=true&url=<?php echo current_url(); ?>&title=<?php echo $cname; ?>&summary=<?php echo $summary; ?>&source=<?php echo $url; ?>', 'myPop1',400,400);" href="javascript:void(0);" target="_parent">
                                            <i class="fa fa-linkedin"></i>
                                        </a>
                                    </h1>
                                </div><div class="clearfix"></div>

                                <div class="col-sm-12 mt10">
                                <div class="table-responsive">
                                <table class="table table-hover table-striped">
                                   
                                    <?php 

                                    $query5 = $this->db->query("SELECT * FROM event where course_id = '$cid' and event_start_date > CURDATE()");
                                    if($query5->num_rows != 0):
                                    ?>
                                    <thead>                                        
                                        <th>Venue</th>
                                        <th>Start</th>
                                        <th>End</th>
                                        <th>Days</th>
                                        <th>Time</th>
                                        <th>Register</th>
                                    </thead>
                                    <tbody>
                                    <?php    
                                    foreach ($query5->result() as $row5){

                                        
                                    $query6 = $this->db->query("SELECT * FROM event_venue where event_venue_id = '".$row5->event_venue_id."'");
                                    foreach ($query6->result() as $row6){
                                    ?>
                                        <tr>
                                            <td><?php echo $row6->event_venue_location; ?></td>
                                            <td><?php echo $row5->event_start_date; ?></td>
                                            <td><?php echo $row5->event_end_date; ?></td>
                                            <td><?php echo $row5->event_days; ?></td>
                                            <td><?php echo $row5->event_time_start; ?> - <?php echo $row5->event_time_end; ?></td>
                                            <td><a href="#" class="reg-course label bg-info">Register Now</a></td>
                                        </tr>

                                    <?php     
                                            }    
                                        }

                                        else: 
                                        echo "<p>There are no upcoming events for this course.</p>"; 
                                        endif;
                                    ?>    

                                       
                                    </tbody>
                                </table>
                                </div>
                                </div><div class="clearfix"></div>
                            </div>

                            <div role="tabpanel" class="tab-pane fade" id="fee-tab">
                                <div class="col-sm-9">
                                    <h1 class="mt0 msizes mb0">
                                        <?php echo $cname; ?>
                                    </h1>
                                    <h5 class="mt0 nsize">
                                        Course Fee
                                    </h5> 
                                </div>
                                <div class="col-sm-3">
                                    <h1 class="pull-right mt0 msize mb0 social-share">
                                        <a onclick="PopupCenter('http://www.facebook.com/sharer.php?s=100&amp;p[title]=<?php echo $title;?>&amp;p[summary]=<?php echo $summary;?>&amp;p[url]=<?php echo $url; ?>&amp;&p[images][0]=<?php echo $image;?>', 'myPop1',400,400);" href="javascript:void(0);" target="_parent">
                                            <i class="ion-social-facebook"></i>
                                        </a>
                                        <a onclick="PopupCenter('http://twitter.com/share?text=<?php echo $cname; ?>&url=<?php echo current_url(); ?>&via=training_ssa', 'myPop1',400,400);" href="javascript:void(0);" target="_parent">
                                            <i class="ion-social-twitter"></i>
                                        </a>
                                        <a onclick="PopupCenter('http://www.linkedin.com/shareArticle?mini=true&url=<?php echo current_url(); ?>&title=<?php echo $cname; ?>&summary=<?php echo $summary; ?>&source=<?php echo $url; ?>', 'myPop1',400,400);" href="javascript:void(0);" target="_parent">
                                            <i class="fa fa-linkedin"></i>
                                        </a>
                                    </h1>
                                </div><div class="clearfix"></div>
                                <div class="col-sm-12 mt10">
                                <table class="table-bordered table table-striped">
                                <tbody>
                                <tr>
                                <td rowspan="2">Workfare Training Support Participants</td>
                                <td>(New Registration)</td>
                                <td><?php echo $cfee_non_wts_new; ?> SGD</td>
                                </tr>
                                <tr>
                                <td>(Subsequent Registration)</td>
                                <td><?php if($cfee_non_wts_sub != "NA"): echo $cfee_non_wts_sub.' SGD'; else: echo $cfee_non_wts_sub; endif; ?></td>
                                </tr>
                                <tr>
                                <td rowspan="2">Non-Workfare Training Support Participants Singaporeans and Singapore Permanent Residents</td>
                                <td>(New Registration)</td>
                                <td><?php if($cfee_wts_new != "NA"): echo $cfee_wts_new.' SGD'; else: echo $cfee_wts_new; endif; ?></td>
                                </tr>
                                <tr>
                                <td>(Subsequent Registration)</td>
                                <td><?php if($cfee_wts_sub != "NA"): echo $cfee_wts_sub.' SGD'; else: echo $cfee_wts_sub; endif; ?></td>
                                </tr>
                                <tr>
                                <td rowspan="2">Foreigners</td>
                                <td>(New Registration)</td>
                                <td><?php if($cfee_for_new != "NA"): echo $cfee_for_new.' SGD'; else: echo $cfee_for_new; endif; ?></td>
                                </tr>
                                <tr>
                                <td>(Subsequent Registration)</td>
                                <td><?php if($cfee_for_sub != "NA"): echo $cfee_for_sub.' SGD'; else: echo $cfee_for_sub; endif; ?></td>
                                </tr>
                                </tbody>
                                </table>
                                </div>

                            </div>
                        </div>



                    </div><div class="clearfix"></div>


                    <div class="col-sm-3">
                    <div class="other-info">
                        <p class="contact-details-left mt40">
                            Contact Details
                        </p>
                        <li class="mt20">
                            <span>
                            Full Address
                            </span> 
                            <strong>
                            Lifelong Learning Institute Singapore City
                            </strong>
                        </li>
                        <li>
                            <span>
                            Phone
                            </span> 
                            <strong>
                            +65 6842 2282
                            </strong>
                        </li>
                        <li>
                            <span>
                            Fax
                            </span> 
                            <strong>
                            +65 6842 2202
                            </strong>
                        </li>
                        <li>
                            <span>
                            E-mail
                            </span> 
                            <strong>
                            contact@ssagroup.com
                            </strong>
                        </li>
                        <div class="clearfix"></div>
                        <p class="contact-details-left mt30">
                            Opening Hours
                        </p>
                        
                        <li class="mt20">
                            <span>
                            Days
                            </span> 
                            <strong>
                            Monday - Friday
                            </strong>
                        </li>
                        <li>
                            <span>
                            Time
                            </span> 
                            <strong>
                            09:00 AM - 5:00 PM
                            </strong>
                        </li>
                        </div><div class="clearfix"></div>
                    </div>
                    <div class="col-sm-9 mt40 pad-right-zero msg-container">
                        <div class="col-sm-12">
                            <div class="message-form-holder">
                                <form id="message-form" class="message-form">
                                    <div class="col-sm-4">
                                        <div class="form-group">                                 
                                            <input type="text" required="" aria-required="true" class="form-control input-lg" id="msg_name" name="msg_name" placeholder="Name *">
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group">                                 
                                            <input type="email" required="" aria-required="true" class="form-control input-lg" id="msg_email" name="msg_email" placeholder="Email *">
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group">                                 
                                            <input type="text" required="" aria-required="true" class="form-control input-lg" id="msg_phone" name="msg_phone" placeholder="Phone *">
                                        </div>
                                    </div><div class="clearfix"></div>
                                    <div class="col-sm-12">
                                        <div class="form-group">                                 
                                            <textarea class="form-control" required="" aria-required="true" rows="5" placeholder="Your Comment *" id="msg_comment" name="msg_comment"></textarea>
                                        </div>
                                    </div><div class="clearfix"></div>
                                    <div class="col-sm-12">
                                        <button type="submit" class="btn btn-primary"><i class="ion-email"></i> &nbsp; Send Message</button>
                                    </div><div class="clearfix"></div>
                                </form>
                            </div>
                        </div><div class="clearfix"></div>
                    </div><div class="clearfix"></div>

                </div>  
                
            </div>            
        </section>

        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-sm-4 text-center">
                        <p class="wcolor nsize">
                            <i class="ion-ios7-telephone"></i> &nbsp;Call
                        </p>
                        <p class="info">
                            Tel: +65 6842 2282<br/>
                            Fax: +65 6842 2202
                        </p>             
                    </div>
                    <div class="col-sm-4 text-center">
                        <p class="wcolor nsize">
                            <i class="fa fa-map-marker"></i> &nbsp;Visit
                        </p>
                        <p class="info">
                            11 Eunos Road 8 #06-01 Lobby A, Lifelong learning Institute, Singapore 408601
                        </p>             
                    </div>
                    <div class="col-sm-4 text-center">
                        <p class="wcolor nsize">
                            <i class="ion-ios7-email"></i> &nbsp;Email
                        </p>
                        <p class="info">
                            contact@ssagroup.com
                        </p>      
                    </div><div class="clearfix"></div>                    
                </div>
            </div>
            <hr/>
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <p class="pull-left">&copy; 2015 SSA Consulting Group Pte. Ltd. All rights reserved.</p>
            
                        <ul class="nav navbar-nav navbar-right">
                            <li><a href="<?php echo base_url(); ?>">Home</a></li>
                            <li><a href="<?php echo base_url(); ?>course/wpln">Courses</a></li>
                            <li><a href="<?php echo base_url(); ?>course-schedule">Schedule</a></li>
                            <li><a href="<?php echo base_url(); ?>contact-us">Contact Us</a></li>
                        </ul>
                    </div><div class="clearfix"></div>                    
                </div>
            </div>
        </footer>