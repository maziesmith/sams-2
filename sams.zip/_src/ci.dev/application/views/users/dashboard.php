<body>

        <!-- Aside Start-->
        <aside class="left-panel">

            <!-- brand -->
            <div class="logo text-center">
                <a href="<?php echo base_url(); ?>users/dashboard" class="logo-expanded">
                    <img src="<?php echo base_url('assets/img/logo3.png'); ?>" alt="logo" style="width:70%">
                    <span class="nav-label">theRECEIPT</span>
                </a>
            </div>
            <!-- / brand -->
        
            <!-- Navbar Start -->
            <nav class="navigation">
                <ul class="list-unstyled">
                    <li class="active"><a href="#"><i class="ion-home"></i> <span class="nav-label">Dashboard</span></a>                        
                    </li>
                    <li class="has-submenu"><a href="#"><i class="ion-ios7-printer"></i> <span class="nav-label">Receipts</span></a>
                        <ul class="list-unstyled">
                            <li><a href="<?php echo base_url(); ?>users/receipts">All Receipts</a></li>
                            <li><a href="<?php echo base_url(); ?>users/receipts/add">Add New</a></li>
                            
                        </ul>
                    </li>
                    <li><a href="<?php echo base_url(); ?>users/myprofile"><i class="ion-gear-a"></i> <span class="nav-label">My Profile</span></a>                       
                    </li>
                    
                </ul>
            </nav>
                
        </aside>
        <!-- Aside Ends-->


        <!--Main Content Start -->
        <section class="content">
            
            <!-- Header -->
            <header class="top-head container-fluid">
                <button type="button" class="navbar-toggle pull-left">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                
                <!-- Search -->
                <form role="search" class="navbar-left app-search pull-left hidden-xs">
                  <input type="text" placeholder="Search..." class="form-control">
                </form>
                
                
                <!-- Right navbar -->
                <ul class="list-inline navbar-right top-menu top-right-menu">  
                    <!-- mesages -->  
                    <li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <i class="fa fa-envelope-o "></i>
                            <span class="badge badge-sm up bg-purple count">4</span>
                        </a>
                        <ul class="dropdown-menu extended fadeInUp animated nicescroll" tabindex="5001">
                            <li>
                                <p>Messages</p>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><img src="<?php echo base_url('assets/img/avatar-2.jpg'); ?>" class="img-circle thumb-sm m-r-15" alt="img"></span>
                                    <span class="block"><strong>John smith</strong></span>
                                    <span class="media-body block">New tasks needs to be done<br><small class="text-muted">10 seconds ago</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><img src="<?php echo base_url('assets/img/avatar-3.jpg'); ?>" class="img-circle thumb-sm m-r-15" alt="img"></span>
                                    <span class="block"><strong>John smith</strong></span>
                                    <span class="media-body block">New tasks needs to be done<br><small class="text-muted">3 minutes ago</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><img src="<?php echo base_url('assets/img/avatar-4.jpg'); ?>" class="img-circle thumb-sm m-r-15" alt="img"></span>
                                    <span class="block"><strong>John smith</strong></span>
                                    <span class="media-body block">New tasks needs to be done<br><small class="text-muted">10 minutes ago</small></span>
                                </a>
                            </li>
                            <li>
                                <p><a href="inbox.html" class="text-right">See all Messages</a></p>
                            </li>
                        </ul>
                    </li>
                    <!-- /messages -->
                    <!-- Notification -->
                    <li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <i class="fa fa-bell-o"></i>
                            <span class="badge badge-sm up bg-pink count">3</span>
                        </a>
                        <ul class="dropdown-menu extended fadeInUp animated nicescroll" tabindex="5002">
                            <li class="noti-header">
                                <p>Notifications</p>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><i class="fa fa-user-plus fa-2x text-info"></i></span>
                                    <span>New user registered<br><small class="text-muted">5 minutes ago</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><i class="fa fa-diamond fa-2x text-primary"></i></span>
                                    <span>Use animate.css<br><small class="text-muted">5 minutes ago</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><i class="fa fa-bell-o fa-2x text-danger"></i></span>
                                    <span>Send project demo files to client<br><small class="text-muted">1 hour ago</small></span>
                                </a>
                            </li>
                            
                            <li>
                                <p><a href="#" class="text-right">See all notifications</a></p>
                            </li>
                        </ul>
                    </li>
                    <!-- /Notification -->

                    <!-- user login dropdown start-->
                    <li class="dropdown text-center">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <img alt="" src="<?php echo base_url('assets/img/avatar-2.jpg'); ?>" class="img-circle profile-img thumb-sm">
                            <span class="username"><?php echo $profile['users_fullname']; ?> </span> <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu extended pro-menu fadeInUp animated" tabindex="5003" style="overflow: hidden; outline: none;">
                            <li><a href="<?php echo base_url(); ?>myprofile"><i class="fa fa-briefcase"></i>Profile</a></li>                 
                            <li><a href="<?php echo base_url(); ?>logout"><i class="fa fa-sign-out"></i> Log Out</a></li>
                        </ul>
                    </li>
                    <!-- user login dropdown end -->       
                </ul>
                <!-- End right navbar -->

            </header>
            <!-- Header Ends -->


            <!-- Page Content Start -->
            <!-- ================== -->

            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title"><?php echo $template['sub_title']; ?></h3> 
                </div>

                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="widget-panel widget-style-1 bg-pink">
                            <i class="fa fa-comments-o"></i> 
                            <h2 class="m-0 counter"><?php echo $sum_receipts; ?></h2>
                            <div>Issued Receipts</div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6">
                        <div class="widget-panel widget-style-1 bg-warning">
                            <i class="fa fa-usd"></i> 
                            <h2 class="m-0 counter"><?php echo number_format($sum_receipts_amount, 0); ?></h2>
                            <div>Sales</div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6">
                        <div class="widget-panel widget-style-1 bg-info">
                            <i class="fa fa-shopping-cart"></i> 
                            <h2 class="m-0 counter"><?php echo $sum_events; ?></h2>
                            <div>Events</div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6">
                        <div class="widget-panel widget-style-1 bg-success">
                            <i class="fa fa-user"></i> 
                            <h2 class="m-0 counter"><?php echo $all_participants; ?></h2>
                            <div>Participants</div>
                        </div>
                    </div>
                </div>

                <div class="row">

                    <!-- Area Chart -->
                    <div class="col-lg-6">
                        <div class="portlet"><!-- /primary heading -->
                            <div class="portlet-heading">
                                <h3 class="portlet-title text-dark">
                                    RECENT RECEIPTS
                                </h3>
                                <div class="portlet-widgets">
                                    <a href="javascript:;" data-toggle="reload"><i class="ion-refresh"></i></a>
                                    <span class="divider"></span>
                                    <a data-toggle="collapse" data-parent="#accordion1" href="#portlet2"><i class="ion-minus-round"></i></a>
                                    <span class="divider"></span>
                                   
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div id="portlet2" class="panel-collapse collapse in">
                                <div class="portlet-body">
                                    <div class="col-sm-12">
                                    <table class="table table-hover table-striped">
                                        <thead>
                                            <tr>
                                                <th>OR Number</th>
                                                <th>Name</th>
                                                <th>Payment</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <?php 
                                                foreach($results as $row){
                                            ?>
                                                <tr>
                                                    <td><?php echo $row->receipts_or; ?></td>
                                                    <td class="text-capitalized"><?php echo $this->main_model->search_participant_name($row->participants_id); ?></td>
                                                    <td><?php echo number_format($row->receipts_amount, 2); ?></td>
                                                </tr>
                                            <?php                   
                                                }                                  
                                            ?>
                                            
                                            
                                        </tbody>
                                    </table>
                                    
                                    </div><div class="clearfix"></div>

                                </div>
                                <div id="simplearea"></div> 
                            </div>

                        </div> <!-- /Portlet -->
                    </div>                    
                    
                      

                    <div class="col-lg-6">

                     

                        <div class="portlet"><!-- /primary heading -->
                            <div class="portlet-heading">
                                <h3 class="portlet-title text-dark text-uppercase">
                                    SALES STATISTICS
                                </h3>
                                <div class="portlet-widgets">
                                    <a href="javascript:;" data-toggle="reload"><i class="ion-refresh"></i></a>
                                    <span class="divider"></span>
                                    <a data-toggle="collapse" data-parent="#accordion1" href="#portlet1"><i class="ion-minus-round"></i></a>
                                    <span class="divider"></span>
                                   
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div id="portlet1" class="panel-collapse collapse in">
                                <div class="portlet-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="col-sm-12">
                                            <div style="padding-right:15px;margin-top:10px">
                                            <canvas id="lineChart" data-type="Line" height="220"></canvas>
                                            </div>
                                            <div class="row text-center m-t-30 m-b-30">
                                                <div class="col-sm-4">
                                                    <h4>86,956</h4>
                                                    <small class="text-muted"> Weekly Report</small>
                                                </div>
                                                <div class="col-sm-4">
                                                    <h4>86,69</h4>
                                                    <small class="text-muted">Monthly Report</small>
                                                </div>
                                                <div class="col-sm-4">
                                                    <h4>948,16</h4>
                                                    <small class="text-muted">Yearly Report</small>
                                                </div>

                                            </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div> <!-- /Portlet -->
                    </div>
                </div> <!-- End row-->


                


            </div>
            <!-- Page Content Ends -->
            <!-- ================== -->

            <!-- Footer Start -->
            <footer class="footer">
                2015 © theRECEIPT SSA Consulting Group Pte. Ltd.
            </footer>
            <!-- Footer Ends -->



        </section>
        <!-- Main Content Ends -->