<body id="invoice">

    <?php 
        foreach($results as $row){
            $receipts_or = $row->receipts_or; 
            $receipts_date = $row->receipts_date;
            $receipts_remarks = $row->receipts_remarks;
            $receipts_status = $row->receipts_status;
            $receipts_amount = $row->receipts_amount;
            $receipts_ref_no = $row->receipts_ref_no;
            $receipts_course_desc = $row->receipts_course_desc;
            $receipts_trans_type = $row->receipts_trans_type;
            date_default_timezone_set("Asia/Singapore"); 
            $dateprint = date('Y-M-d/h:i A');

            $query1 = $this->db->query("SELECT * FROM participants where participants_id=".$row->participants_id."");
            foreach ($query1->result() as $row1)
            {
                $participants_fullname = $row1->participants_fullname;
                $participants_nric = $row1->participants_nric;
            }

            $query2 = $this->db->query("SELECT * FROM users INNER JOIN branch on users.branch_id = branch.branch_id where users_id=".$row->users_id."");
            foreach ($query2->result() as $row2)
            {
                $users_fullname = $row2->users_fullname;
                $users_location = $row2->branch_name;
            }

            $query3 = $this->db->query("SELECT * FROM receipts_printed where receipts_id=".$row->receipts_id."");
            if ($query3->num_rows() > 0){
                $receipt_type = "Duplicate Copy";
            } else {
                $receipt_type = "Original Receipt";
            }
            $official_receipt = $this->uri->segment(4);
        }                                  
    ?>

    <!-- Aside Start-->
    <aside class="left-panel">

        <!-- brand -->
        <div class="logo text-center">
            <a href="<?php echo base_url(); ?>users" class="logo-expanded">
                <img src="<?php echo base_url('assets/img/logo3.png'); ?>" alt="logo" style="width:70%">
                <span class="nav-label">theRECEIPT <?php //echo $page_title; ?></span>
            </a>
        </div>
        <!-- / brand -->
    
        <!-- Navbar Start -->
        <nav class="navigation">
            <ul class="list-unstyled">
                <li><a href="<? echo base_url(); ?>users"><i class="ion-home"></i> <span class="nav-label">Dashboard</span></a>                        
                </li>
                <li class="has-submenu active"><a href="#"><i class="ion-ios7-printer"></i> <span class="nav-label">Receipts</span></a>
                    <ul class="list-unstyled">
                        <li><a href="<? echo base_url(); ?>users/receipts">All Receipts</a></li>
                        <li  class="active"><a href="<? echo base_url(); ?>users/receipts/add">Add New</a></li>
                        
                    </ul>
                </li>
                <li><a href="<? echo base_url(); ?>users/myprofile"><i class="ion-gear-a"></i> <span class="nav-label">My Profile</span></a>                       
                </li>
                
            </ul>
        </nav>
            
    </aside>
    <!-- Aside Ends-->


    <!--Main Content Start -->
    <section class="content">
        
        <!-- Header -->
        <header class="top-head container-fluid">
            <button type="button" class="navbar-toggle pull-left">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            
            <!-- Search -->
            <form role="search" class="navbar-left app-search pull-left hidden-xs">
              <input type="text" placeholder="Search..." class="form-control">
            </form>
            
            
            
            <!-- Right navbar -->
            <ul class="list-inline navbar-right top-menu top-right-menu">  
                <!-- mesages -->  
                <li class="dropdown">
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                        <i class="fa fa-envelope-o "></i>
                        <span class="badge badge-sm up bg-purple count">4</span>
                    </a>
                    <ul class="dropdown-menu extended fadeInUp animated nicescroll" tabindex="5001">
                        <li>
                            <p>Messages</p>
                        </li>
                        <li>
                            <a href="#">
                                <span class="pull-left"><img src="<?php echo base_url('assets/img/avatar-2.jpg'); ?>" class="img-circle thumb-sm m-r-15" alt="img"></span>
                                <span class="block"><strong>John smith</strong></span>
                                <span class="media-body block">New tasks needs to be done<br><small class="text-muted">10 seconds ago</small></span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span class="pull-left"><img src="<?php echo base_url('assets/img/avatar-3.jpg'); ?>" class="img-circle thumb-sm m-r-15" alt="img"></span>
                                <span class="block"><strong>John smith</strong></span>
                                <span class="media-body block">New tasks needs to be done<br><small class="text-muted">3 minutes ago</small></span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span class="pull-left"><img src="<?php echo base_url('assets/img/avatar-4.jpg'); ?>" class="img-circle thumb-sm m-r-15" alt="img"></span>
                                <span class="block"><strong>John smith</strong></span>
                                <span class="media-body block">New tasks needs to be done<br><small class="text-muted">10 minutes ago</small></span>
                            </a>
                        </li>
                        <li>
                            <p><a href="inbox.html" class="text-right">See all Messages</a></p>
                        </li>
                    </ul>
                </li>
                <!-- /messages -->
                <!-- Notification -->
                <li class="dropdown">
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                        <i class="fa fa-bell-o"></i>
                        <span class="badge badge-sm up bg-pink count">3</span>
                    </a>
                    <ul class="dropdown-menu extended fadeInUp animated nicescroll" tabindex="5002">
                        <li class="noti-header">
                            <p>Notifications</p>
                        </li>
                        <li>
                            <a href="#">
                                <span class="pull-left"><i class="fa fa-user-plus fa-2x text-info"></i></span>
                                <span>New user registered<br><small class="text-muted">5 minutes ago</small></span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span class="pull-left"><i class="fa fa-diamond fa-2x text-primary"></i></span>
                                <span>Use animate.css<br><small class="text-muted">5 minutes ago</small></span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span class="pull-left"><i class="fa fa-bell-o fa-2x text-danger"></i></span>
                                <span>Send project demo files to client<br><small class="text-muted">1 hour ago</small></span>
                            </a>
                        </li>
                        
                        <li>
                            <p><a href="#" class="text-right">See all notifications</a></p>
                        </li>
                    </ul>
                </li>
                <!-- /Notification -->

                <!-- user login dropdown start-->
                <li class="dropdown text-center">
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                        <img alt="" src="<?php echo base_url('assets/img/avatar-2.jpg'); ?>" class="img-circle profile-img thumb-sm">
                        <span class="username"><?php echo $profile['users_fullname']; ?> </span> <span class="caret"></span>
                    </a>
                    <ul class="dropdown-menu extended pro-menu fadeInUp animated" tabindex="5003" style="overflow: hidden; outline: none;">
                        <li><a href="<?php echo base_url(); ?>myprofile"><i class="fa fa-briefcase"></i>Profile</a></li>                 
                        <li><a href="<?php echo base_url(); ?>logout"><i class="fa fa-sign-out"></i> Log Out</a></li>
                    </ul>
                </li>
                <!-- user login dropdown end -->       
            </ul>
            <!-- End right navbar -->

        </header>
        <!-- Header Ends -->


        <!-- Page Content Start -->
        <!-- ================== -->

        <div class="wraper container-fluid">
            <div class="page-title"> 
                <h3 class="title">Invoice</h3> 
            </div>

            <div class="row">
                <div class="col-md-12" id="invoice-body">
                    <div class="panel panel-default">
                        <!-- <div class="panel-heading">
                            <h4>Invoice</h4>
                        </div> -->
                        <div class="panel-body">
                            <div class="clearfix invoice-header">
                                <div class="col-sm-4 pad-zero">
                                    <h4 class="text-right">
                                        <img src="<?php echo base_url('assets/img/logo.png'); ?>" class="img-responsive" alt="velonic">
                                    </h4>
                                    
                                </div>
                                <div class="col-sm-5 pad-zero">
                                    <h4>
                                        <strong>SSA Consulting Group Pte. Ltd.</strong><br>
                                        <span class="address">
                                        11 Eunos Road 8 Lifelong Learning Institute
                                        Singapore 408601<br>
                                        Tel: 6842-2282 Fax: 6842-2202<br>
                                        GST Reg No.: M200632125
                                        </span>
                                    </h4>
                                </div>
                                <div class="col-sm-3 pad-zero">
                                    <h4 class="text-right"><strong>Official Receipt</strong><br>
                                        <span class="address">
                                        No.: <?php echo $receipts_or; ?><br>
                                        <?php echo $receipt_type; ?>
                                        </span>
                                    </h4>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-md-12 receipt-details">                                    
                                        <h4><strong>Receipt Details</strong></h4>

                                        <h5 class="col-sm-8 pad-zero">
                                            <strong>Received From <a class="pull-right">:</a></strong>&nbsp; <?php echo $participants_fullname; ?>                                  
                                        </h5>
                                        <h5 class="col-sm-4 pad-zero">
                                            <strong>Receipt Date <a class="pull-right">:</a></strong>&nbsp; <?php echo $receipts_date; ?>
                                        </h5><div class="clearfix"></div>
                                        <h5 class="col-sm-8 pad-zero">
                                            <strong>Type of Transaction <a class="pull-right">:</a></strong>&nbsp; <?php echo $receipts_trans_type; ?>   
                                        </h5>
                                        <h5 class="col-sm-4 pad-zero">
                                            <strong>Received By <a class="pull-right">:</a></strong>&nbsp; <?php echo $users_fullname; ?>
                                        </h5><div class="clearfix"></div>
                                        <h5 class="col-sm-8 pad-zero">
                                            <strong>Transaction Ref. No. <a class="pull-right">:</a></strong>&nbsp; <?php if($receipts_ref_no!=""): echo $receipts_ref_no; else: echo '000000'; endif; ?>   
                                        </h5>
                                        <h5 class="col-sm-4 pad-zero">
                                            <strong>Received At <a class="pull-right">:</a></strong>&nbsp; <?php echo $users_location; ?>
                                        </h5><div class="clearfix"></div>
                                        <h5 class="col-sm-12 pad-zero">
                                            <strong>Remarks <a class="pull-right">:</a></strong>&nbsp; <?php echo $receipts_remarks; ?>
                                        </h5><div class="clearfix"></div>        
                                </div>
                            </div>
                          
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="table-responsive">
                                        <table class="table m-t-30">
                                            <thead>
                                                <tr>
                                                <th style="width:20%">Participant</th>
                                                <th style="width:15%">Identification No.</th>
                                                <th>Description</th>
                                                <th style="width:10%" class="text-right">Amount</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td><?php echo $participants_fullname; ?></td>
                                                    <td><?php 
                                                        $msg = '';
                                                        $msg .= substr($participants_nric, 0, 1);
                                                        $msg .= 'XXXX';
                                                        $msg .= substr($participants_nric, 5);
                                                        echo $msg;
                                                        ?>
                                                    </td>
                                                    <td><?php echo $receipts_course_desc; ?>
                                                    </td>
                                                    <td class="text-right">$<?php echo number_format($receipts_amount,2); ?></td>
                                                   
                                                </tr>
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="hidden-print">
                                <div class="col-sm-8 pad-zero">
                                    <h5>
                                        <em>This is a company-gerated document. No signature is required. </em>
                                    </h5>
                                </div>
                                <div class="col-sm-4 pad-zero">
                                    <h5 class="text-right">
                                        <strong>Total Amount <a class="pull-right">:</a></strong>&nbsp; <span>$<?php echo number_format($receipts_amount,2); ?></span>
                                    </h5><div class="clearfix"></div>
                                   
                                    <h5 class="text-right">
                                        <strong>Print Date/Time<a class="pull-right">:</a></strong> <span><?php echo $dateprint; ?></span>
                                    </h5>
                                </div>

                                <div class="pull-right bots">
                                    <a href="javascript:;" class="btn btn-inverse print-button"><i class="fa fa-print"></i></a>
                                    <a href="javascript:;" class="btn btn-info send-button">Submit</a>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>

        </div>

        <!-- Page Content Ends -->
        <!-- ================== -->

        <!-- Footer Start -->
        <footer class="footer">
            2015 © theRECEIPT SSA Consulting Group Pte. Ltd.
        
        </footer>
        <!-- Footer Ends -->


    </section>

    <?php 
    echo '<script> var link = "'.$official_receipt.'"; </script>';
    ?>
    <!-- Main Content Ends -->