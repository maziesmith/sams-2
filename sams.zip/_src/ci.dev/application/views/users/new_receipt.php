<body id="new-receipt">

        <!-- Aside Start-->
        <aside class="left-panel">

            <!-- brand -->
            <div class="logo text-center">
                <a href="<?php echo base_url(); ?>users/dashboard" class="logo-expanded">
                    <img src="<?php echo base_url('assets/img/logo3.png'); ?>" alt="logo" style="width:70%">
                    <span class="nav-label">theRECEIPT</span>
                </a>
            </div>
            <!-- / brand -->
        
            <!-- Navbar Start -->
            <nav class="navigation">
                <ul class="list-unstyled">
                    <li><a href="<?php echo base_url(); ?>users/dashboard"><i class="ion-home"></i> <span class="nav-label">Dashboard</span></a>                        
                    </li>
                    
                    <li class="has-submenu active"><a href="#"><i class="ion-ios7-printer"></i> <span class="nav-label">Receipts</span></a>
                        <ul class="list-unstyled">
                            <li><a href="<?php echo base_url(); ?>users/receipts">All Receipts</a></li>
                            <li  class="active"><a href="#">Add New</a></li>
                            
                        </ul>
                    </li>
                    <li><a href="<?php echo base_url(); ?>users/myprofile"><i class="ion-gear-a"></i> <span class="nav-label">My Profile</span></a>                       
                    </li>
                    
                </ul>
            </nav>
                
        </aside>
        <!-- Aside Ends-->


        <!--Main Content Start -->
        <section class="content">
            
            <!-- Header -->
            <header class="top-head container-fluid">
                <button type="button" class="navbar-toggle pull-left">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                
                <!-- Search -->
                <form role="search" class="navbar-left app-search pull-left hidden-xs">
                  <input type="text" placeholder="Search..." class="form-control">
                </form>
                
                
                
                <!-- Right navbar -->
                <ul class="list-inline navbar-right top-menu top-right-menu">  
                    <!-- mesages -->  
                    <li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <i class="fa fa-envelope-o "></i>
                            <span class="badge badge-sm up bg-purple count">4</span>
                        </a>
                        <ul class="dropdown-menu extended fadeInUp animated nicescroll" tabindex="5001">
                            <li>
                                <p>Messages</p>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><img src="<?php echo base_url('assets/img/avatar-2.jpg'); ?>" class="img-circle thumb-sm m-r-15" alt="img"></span>
                                    <span class="block"><strong>John smith</strong></span>
                                    <span class="media-body block">New tasks needs to be done<br><small class="text-muted">10 seconds ago</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><img src="<?php echo base_url('assets/img/avatar-3.jpg'); ?>" class="img-circle thumb-sm m-r-15" alt="img"></span>
                                    <span class="block"><strong>John smith</strong></span>
                                    <span class="media-body block">New tasks needs to be done<br><small class="text-muted">3 minutes ago</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><img src="<?php echo base_url('assets/img/avatar-4.jpg'); ?>" class="img-circle thumb-sm m-r-15" alt="img"></span>
                                    <span class="block"><strong>John smith</strong></span>
                                    <span class="media-body block">New tasks needs to be done<br><small class="text-muted">10 minutes ago</small></span>
                                </a>
                            </li>
                            <li>
                                <p><a href="inbox.html" class="text-right">See all Messages</a></p>
                            </li>
                        </ul>
                    </li>
                    <!-- /messages -->
                    <!-- Notification -->
                    <li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <i class="fa fa-bell-o"></i>
                            <span class="badge badge-sm up bg-pink count">3</span>
                        </a>
                        <ul class="dropdown-menu extended fadeInUp animated nicescroll" tabindex="5002">
                            <li class="noti-header">
                                <p>Notifications</p>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><i class="fa fa-user-plus fa-2x text-info"></i></span>
                                    <span>New user registered<br><small class="text-muted">5 minutes ago</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><i class="fa fa-diamond fa-2x text-primary"></i></span>
                                    <span>Use animate.css<br><small class="text-muted">5 minutes ago</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><i class="fa fa-bell-o fa-2x text-danger"></i></span>
                                    <span>Send project demo files to client<br><small class="text-muted">1 hour ago</small></span>
                                </a>
                            </li>
                            
                            <li>
                                <p><a href="#" class="text-right">See all notifications</a></p>
                            </li>
                        </ul>
                    </li>
                    <!-- /Notification -->

                    <!-- user login dropdown start-->
                    <li class="dropdown text-center">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <img alt="" src="<?php echo base_url('assets/img/avatar-2.jpg'); ?>" class="img-circle profile-img thumb-sm">
                            <span class="username"><?php echo $profile['users_fullname']; ?> </span> <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu extended pro-menu fadeInUp animated" tabindex="5003" style="overflow: hidden; outline: none;">
                            <li><a href="<?php echo base_url(); ?>myprofile"><i class="fa fa-briefcase"></i>Profile</a></li>                 
                            <li><a href="<?php echo base_url(); ?>logout"><i class="fa fa-sign-out"></i> Log Out</a></li>
                        </ul>
                    </li>
                    <!-- user login dropdown end -->       
                </ul>
                <!-- End right navbar -->

            </header>
            <!-- Header Ends -->


            <!-- Page Content Start -->
            <!-- ================== -->

            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title"><?php echo $template['sub_title']; ?></h3> 
                </div>

                

                




                <div class="row">
                    <div class="col-lg-8">
                        <div class="form-holder">
                            <form role="form" id="add_form">

                              

                                <div class="form-group col-sm-6 pad-zero-left">
                                    <label for="add_nric" style="width:100%">NRIC/FIN/PASSPORT                                        
                                    </label>
                                    <select class="js-example-tags tags1 form-control input-lg" multiple="multiple" id="add_nric" name="add_nric">
                                        <?php 
                                            foreach($results as $row){
                                                echo "<option value='".$row->participants_nric."'>".$row->participants_nric." (".$row->participants_fullname.")</option>";                                         
                                            }                                  
                                        ?>
                                    </select>
                                    
                                </div>
                                <div class="form-group col-sm-6 pad-zero-right">
                                    <label for="add_fname" style="width:100%">FULL NAME                                       
                                    </label>
                                    <input type="text" class="form-control input-lg" id="add_fname" name="add_fname">
                                   
                                </div><div class="clearfix"></div>

                                <div class="form-group col-sm-6 pad-zero-left">
                                    <label for="add_trans_type">TRANSACTION TYPE</label>
                                    <select class="form-control input-lg" id="add_trans_type" name="add_trans_type">
                                        <option value=""></option>
                                        <option value="Cash">Cash</option>
                                        <option value="Nets">Nets</option>
                                        <option value="Bank Transfer">Bank Transfer</option>
                                        <option value="Cheque">Cheque</option>
                                    </select>
                                   
                                </div>
                                <div class="form-group col-sm-6 pad-zero-right">
                                    <label for="add_trans_ref_no">TRANSACTION REF. NO.</label>
                                    <input type="text" class="form-control input-lg" id="add_trans_ref_no" name="add_trans_ref_no" disabled="disabled">
                                    
                                </div>
                                
                                <div class="form-group col-sm-6 pad-zero-left">
                                    <label for="add_course_desc">COURSE DESCRIPTION</label>
                                    <textarea class="form-control input-lg" rows="1"  id="add_course_desc" name="add_course_desc"></textarea>
                                   
                                </div>
                                <div class="form-group col-sm-6 pad-zero-right">
                                    <label for="add_remarks">REMARKS</label>
                                    <textarea class="form-control input-lg" rows="1"  id="add_remarks" name="add_remarks"></textarea>
                                    
                                </div><div class="clearfix"></div>
                                <div class="form-group">
                                    <label for="add_amount">AMOUNT</label>
                                    <input type="email" class="form-control input-lg" id="add_amount" name="add_amount">
                                    
                                </div>
                                <div class="form-group">
                                    <button type="button" class="btn btn-info input-lg" id="add_button">Add New Receipt</button>
                                </div>

                            </form>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="prog-search-holder">
                            
                            <div class="col-sm-12 pad-zero">
                                <div class="form-group">
                                    <label class="col-md-6 control-label pad-zero">
                                         <input type="text" class="form-control" id="nric_search" name="nric_search">
                                    </label>
                                    <div class="col-md-6 pad-zero-right">
                                        <button type="button" class="btn btn-default btn-search ">Search History</button>
                                    </div>
                                </div>
                            </div><div class="clearfix"></div>
                        </div>

                        <div class="portlet"><!-- /primary heading -->
                            <div class="portlet-heading">
                                <h3 class="portlet-title text-dark text-uppercase">
                                    <span id="nric_values"></span> History
                                </h3>
                                <div class="portlet-widgets">
                                    
                                    <a data-toggle="collapse" data-parent="#accordion1" href="#portlet1"><i class="ion-minus-round"></i></a>
                                    <span class="divider"></span>
                                    
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div id="portlet1" class="panel-collapse collapse in">
                                <div class="portlet-body">
                                    <div class="row">                                

                                        <div class="col-sm-12">
                                            <div id="containers" class="col-sm-12 table-responsive">
                                                <div class="data"></div>                                      
                                            </div>
                                        </div><div class="clearfix"></div>                                        

                                    </div>                              
                                </div>
                            </div>
                        </div> <!-- /Portlet -->

                    </div> <!-- end col -->

                    
                </div> <!-- End row -->

            </div>
            <!-- Page Content Ends -->
            <!-- ================== -->

            <!-- Footer Start -->
            <footer class="footer">
                2015 © theRECEIPT SSA Consulting Group Pte. Ltd.
            </footer>
            <!-- Footer Ends -->



        </section>
        <!-- Main Content Ends -->
        
        <div class="md-modal md-effect-14" id="edit-modal">
            <div class="md-content">
                <h3>Edit <strong>(OR-15/04/000001)</strong> <br>
                <span class="text-info">PARTICIPANT(S7980136D)</span></h3>
                <div class="transaction-content">                   
                    <div class="form-group">
                        <label for="prog_slug">TRANSACTION TYPE</label>
                        <select class="form-control">
                            <option value="Cash">Cash</option>
                            <option value="Nets">Nets</option>
                            <option value="Bank Transfer">Bank Transfer</option>
                            <option value="Cheque">Cheque</option>
                        </select>
                        
                    </div>
                    <div class="form-group">
                        <label for="prog_slug">TRANSACTION REF. NO.</label>
                        <input type="text" class="form-control" id="prog_slug" name="prog_slug" disabled="disabled">
                        
                    </div>
                    
                    <div class="form-group">
                        <label for="prog_desc">COURSE DESCRIPTION</label>
                        <textarea id="prog_slug" class="form-control" rows="1"  id="prog_desc" name="prog_desc">Duis autem vel eum iriure dolor in hendrerit in vulputate</textarea>
                        
                    </div>
                    <div class="form-group">
                        <label for="prog_desc">REMARKS</label>
                        <textarea id="prog_slug" class="form-control" rows="1"  id="prog_desc" name="prog_desc">Duis autem vel eum iriure dolor in hendrerit in vulputate</textarea>
                        
                    </div>
                    <div class="form-group">
                        <label for="prog_name">AMOUNT</label>
                        <input type="email" class="form-control" value="50.00" id="prog_name" name="prog_name">
                        
                    </div>
                    <span class="pull-left text-center" style="width:100%;margin:0">
                    <h3 style="margin:0">Do you wish to update this transaction?</h3>
                    <button class="btn-info btns">Yes</button>
                    <button class="md-close btn-danger btns">No</button>
                    </span><div class="clearfix"></div>
                </div>
            </div>
        </div>    

        <div class="md-modal md-effect-14" id="delete-modal">
            <div class="md-content">
                <h3>Cancel <strong>(OR-15/04/000001)</strong> <br>
                <span class="text-info">PARTICIPANT(S7980136D)</span></h3>
                <div class="transaction-content">
                    <p>
                        <strong>TRANSACTION TYPE </strong>: &nbsp;  Cash<br/>                  
                        <strong>TRANSACTION REF. NO. </strong>: &nbsp;  0<br/>
                        <strong>COURSE DESCRIPTION: </strong>: &nbsp;  Duis autem vel eum iriure dolor in hendrerit in<br/>
                        <strong>REMARKS </strong>: &nbsp;  Duis autem vel eum iriure dolor in hendrerit in<br/>
                        <strong>AMOUNT </strong>: &nbsp;  50.00
                    </p>                   
                    <span class="pull-left text-center" style="width:100%">
                    <h3 style="margin:0">Do you wish to cancel this transaction?</h3>
                    <button class="btn-info btns">Yes</button>
                    <button class="md-close btn-danger btns">No</button>
                    </span><div class="clearfix"></div>
                </div>
            </div>
        </div>    

        <div class="md-overlay"></div><!-- the overlay element -->