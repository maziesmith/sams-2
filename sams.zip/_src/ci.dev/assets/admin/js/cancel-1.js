$(".del-modal").click(function(e){
        
    e.preventDefault();
    var parent = $(this).parent().parent();
    var numero = parent.attr('id').replace('record-','');

    $.ajax({
        type: "GET",
        url: 'search-or?or='+numero,
        beforeSend: function(x) {

        },
        dataType: "json",
        success: function(data){
            $("#id_or").html(data.r_id); 
            $("#or_or").html(data.r_or);    
            $("#nric_or").html(data.r_nric);
            $("#trans_or").html(data.r_trans); 
            
            if(data.r_ref==""){    
                $("#ref_or").html('000000');
            } else {
                $("#ref_or").html(data.r_ref);
            }  

            $("#course_or").html(data.r_course);  
            $("#remarks_or").html(data.r_remarks);  
            $("#amount_or").html(data.r_amount);  
        }
    });

});


$(".yes-cancel").unbind('click').bind('click', function (e) {
    e.preventDefault();
    var numero = $("#id_or").html();      
    
    $.ajax({
        type: "GET",
        url: 'update-or?or='+numero,
        success: function(msg)
        {   
            
            
        },
        complete: function(){
                     
            /*var value = $("#receipts .nav-tabs li.active a span").html();
            
            if(value=="All"){                
                $.when( loadData_all(ping_value,'nothing') ).done(function( x ) {
                  swal("Success!", "The OR ("+numero+") has been cancelled.", "success");
                });
            } else if(value=="Received"){            
                $.when( loadData_all_received(ping_value,'nothing') ).done(function( x ) {
                  swal("Success!", "The OR ("+numero+") has been cancelled.", "success");
                });
            } else if(value="Cancelled"){                
                $.when( loadData_all_cancelled(ping_value,'nothing') ).done(function( x ) {
                  swal("Success!", "The OR ("+numero+") has been cancelled.", "success");
                });
            }*/

            $.when( loadData_all(ping_valuez1,'nothing'), loadData_all_received(ping_valuez2,'nothing'), loadData_all_cancelled(ping_valuez3,'nothing') ).done(function( x ) {
              swal("Success!", "The OR ("+numero+") has been cancelled.", "success");
            }); 

            count_all_cancelled_receipt();
            count_all_received_receipt();
            count_all_receipt();
         
        }
    }); 
}); 

function count_all_cancelled_receipt(){

    $.ajax({
        type: "GET",
        url: 'count-all-cancelled-receipt',
        beforeSend: function(x) {

        },
        dataType: "json",
        success: function(data){
            $("li[role='all-cancelled-receipts'] co").html(data.value_all_cancelled);
        }
                       
        
    }); 
}

function count_all_received_receipt(){

    $.ajax({
        type: "GET",
        url: 'count-all-received-receipt',
        beforeSend: function(x) {

        },
        dataType: "json",
        success: function(data){
            $("li[role='all-received-receipts'] co").html(data.value_all_received);
        }
                       
        
    }); 
}

function count_all_receipt(){

    $.ajax({
        type: "GET",
        url: 'count-all-receipt',
        beforeSend: function(x) {

        },
        dataType: "json",
        success: function(data){
            $("li[role='all-receipts'] co").html(data.value_all);
        }
                       
        
    }); 
}


$(".nifty-close2").click(function(e){

    $("#delete-modal").removeClass("md-show");
});