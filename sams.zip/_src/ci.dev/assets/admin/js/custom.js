


jQuery(document).ready(function($) {
    
    
    
    
    

    $("#checkAll").click(function(){
        alert('ss');
    });

    $("#add_trans_type").change(function(){
        if(($(this).val()=="") || ($(this).val()=="Cash")){
            $("#add_trans_ref_no").prop("disabled",true);            
        } else {
            $("#add_trans_ref_no").prop("disabled",false);
        }
    });

    $('form .btn-info').click(function(){

        var add_nric = $("#add_nric").val();
        var add_fname = $("#add_fname").val();
        var add_trans_type = $("#add_trans_type").val();
        var add_trans_ref_no = $("#add_trans_ref_no").val();
        var add_course_desc = $("#add_course_desc").val();
        var add_remarks = $("#add_remarks").val();
        var add_amount = $("#add_amount").val();


        if((add_nric === undefined || add_nric === null) && (add_fname=="") && (add_trans_type=="") && (add_course_desc=="") && (add_remarks=="") && (add_amount=="")){
            $("#add_nric, .select2-selection").addClass('has-error');
            $("#add_fname").addClass('has-error');
            $("#add_trans_type").addClass('has-error');
            $("#add_course_desc").addClass('has-error');
            $("#add_remarks").addClass('has-error');
            $("#add_amount").addClass('has-error');
        }
        else if(add_nric === undefined || add_nric === null){
            $("#add_nric, .select2-selection").addClass('has-error');
        } else if(add_fname==""){  
            $("#add_fname").addClass('has-error');
        } else if(add_trans_type==""){
            if((add_trans_type=="Cash") || (add_trans_type=="")){
               
            } else {
            $("#add_trans_ref_no").addClass('has-error');
            }

            $("#add_trans_type").addClass('has-error');
        } else if(add_course_desc==""){
            $("#add_course_desc").addClass('has-error');
        } else if(add_remarks==""){
            $("#add_remarks").addClass('has-error');
        } else if(add_amount==""){
            $("#add_amount").addClass('has-error');
        } else if(add_trans_ref_no==""){
            if((add_trans_type=="Cash") || (add_trans_type=="")){
                save();
            } else {
            $("#add_trans_ref_no").addClass('has-error');
            }      
        } else {
            save();
        }
    })
    
    $(".print-button").click(function(){
        swal({   
            title: "Do you like to print this?", 
            type: "warning",   
            showCancelButton: true,   
            confirmButtonColor: "#0074a2",   
            confirmButtonText: "Yes, please.",
            cancelButtonText: "No, its okay.",    
            closeOnConfirm: false },
            function(isConfirm){   
                if (isConfirm) {  
                  window.open("../generate/"+link+"","_blank");


                } 
                else { 
          
                }

           
            });
    });


    $("#add_user_button").unbind('click').bind('click', function (e) {
        e.preventDefault();

        var add_fname = $("#user_fname").val();
        var add_branch = $("#user_branch").val();
        var add_email = $("#user_email").val();
        var add_uname = $("#user_uname").val();
        var add_pass = $("#user_pass").val();
        var add_repass = $("#user_repass").val();
        var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
        var passwordStrengthRegex = /((?=.*d)(?=.*[a-z])(?=.*[A-Z]).{8,15})/; 
        

        if((add_fname == "") && (add_branch == "") && (add_email == "") && (add_uname == "") && (add_pass == "") && (add_repass == "") && (!$("input[name='user-role']").is(':checked')) ){
            $("#user_fname, #user_branch, #user_email, #user_uname, #user_pass, #user_repass").addClass('has-error').next().addClass('help-block error').html('This field is required.');
            $(".user_role_error").addClass('help-block error').html('This field is required.');
        } else if(add_fname == ""){
            $("#user_fname").addClass('has-error');
            $(".user_fname_error").addClass('help-block error').html('This field is required.');
        } else if(add_branch == ""){
            $("#user_branch").addClass('has-error');
            $(".user_branch_error").addClass('help-block error').html('This field is required.');
        } else if(add_uname == ""){
            $("#user_uname").addClass('has-error');
            $(".user_uname_error").addClass('help-block error').html('This field is required.');
        } else if((add_email == "") || ( !emailReg.test(add_email) )) {
            if(add_email == ""){   
                $("#user_email").addClass('has-error');
                $(".user_email_error").addClass('help-block error').html('This field is required.');
            }else if(!emailReg.test(add_email) ){
                $("#user_email").addClass('has-error');
                $(".user_email_error").addClass('help-block error').html('This is not a valid email.');
            }
        } else if ( (add_pass == "") || ((!passwordStrengthRegex.test(add_pass)))) {
            if(add_pass == ""){
                $("#user_pass").addClass('has-error');
                $(".user_pass_error").addClass('help-block error').html('This field is required.');       
            }
            else if(!passwordStrengthRegex.test(add_pass)){
                $("#user_pass").addClass('has-error');
                $(".user_pass_error").addClass('help-block error').html('Your password must contain <strong>1 uppercase, 1 lowerCase, 1 number, and must be 8 digits.</strong>'); 
            }
        } else if ( (add_repass == "") || ((!passwordStrengthRegex.test(add_repass))) || (add_pass != add_repass)) {

            if(add_repass == ""){
                $("#user_repass").addClass('has-error');
                $(".user_repass_error").addClass('help-block error').html('This field is required.');       
            }
            else if(!passwordStrengthRegex.test(add_repass)){
                $("#user_repass").addClass('has-error');
                $(".user_repass_error").addClass('help-block error').html('Your password must contain <strong>1 uppercase, 1 lowerCase, 1 number, and must be 8 digits.</strong>'); 
            }
            else if(add_pass != add_repass){
                $("#user_repass").addClass('has-error');
                $(".user_repass_error").addClass('help-block error').html('Your password is not matched!'); 
            }
        } else if(!$("input[name='user-role']").is(':checked')){
            $(".user_role_error").addClass('help-block error').html('This field is required.'); 
        } else{
           save_user(add_fname,add_branch,add_email,add_uname,add_pass);
        }


    });

    $('#user_fname, #user_uname, #user_email, #user_pass, #user_repass').keydown(function() {
      $(this).removeClass('has-error').next().html('');
    });
    
    $('#user_branch').change(function() {
      $(this).removeClass('has-error').next().html('');
    });



    $(".send-button").click(function(){
        swal("Sorry, this feature has been disabled.","","error");
    });

    function save(){
        var dataness = 0;

        swal({   
            title: "Are you sure you like to register this participant?", 
            type: "warning",   
            showCancelButton: true,   
            confirmButtonColor: "#0074a2",   
            confirmButtonText: "Yes, register it!",   
            closeOnConfirm: false },
            function(isConfirm){   
                if (isConfirm) {  

                    var add_nric = $("#add_nric").val();
                    var add_fname = $("#add_fname").val();
                    var add_trans_type = $("#add_trans_type").val();
                    var add_trans_ref_no = $("#add_trans_ref_no").val();
                    var add_course_desc = $("#add_course_desc").val();
                    var add_remarks = $("#add_remarks").val();
                    var add_amount = $("#add_amount").val();
                    var add_role = $("input[name='user-role']:checked").val();

                    $.ajax
                    ({
                        type: "GET",
                        url: "../../admin/add-receipts/?add_nric="+add_nric+"&add_fname="+add_fname+"&add_trans_type="+add_trans_type+"&add_trans_ref_no="+add_trans_ref_no+"&add_course_desc="+add_course_desc+"&add_remarks="+add_remarks+"&add_amount="+add_amount,                        
                        success: function(msg)
                        { 
                           dataness = msg; 
                        }
                    });

                    swal({
                    title: "Successful",
                    type: "success",
                    text: "The participant has been successfully registered!",
                    confirmButtonColor: "",   
                    confirmButtonText: "Done.",},
                    function(isConfirm){   
                        if (isConfirm) {
                                 document.location = 'invoice/'+dataness;
                        } else {     
                               
                        }

                    });

                } 
                else { 
          
                }

           
            });
    }

    function save_user(add_fname,add_branch,add_email,add_uname,add_pass){

        swal({   
            title: "Are you sure you like to register this user?", 
            type: "warning",   
            showCancelButton: true,   
            confirmButtonColor: "#0074a2",   
            confirmButtonText: "Yes, register it!",   
            closeOnConfirm: false },
            function(isConfirm){   
                if (isConfirm) {  
                    
                    $.ajax
                    ({
                        type: "GET",
                        url: "../../admin/save-user/?add_fname="+add_fname+"&add_branch="+add_branch+"&add_email="+add_email+"&add_uname="+add_uname+"&add_pass="+add_pass,                        
                        success: function(msg)
                        { 
                           
                           if(msg == "0"){
                                swal({
                                title: "Successful",
                                type: "success",
                                text: "The user has been successfully registered!",
                                confirmButtonColor: "",   
                                confirmButtonText: "Done.",});
                                clearform();
                            } else {
                                swal({
                                title: "Failed",
                                type: "warning",
                                text: "The username is already registered!",
                                confirmButtonColor: "",   
                                confirmButtonText: "Done.",});
                            }

                        }
                    });

                    

                } 
                else { 
          
                }

           
            });
    }


    function clearform(){
        $("#user_fname, #user_email, #user_uname, #user_pass, #user_repass").val('');
        $("#user_branch").find("option#selectnull").attr("selected", true);
    }

    //for numeric function
    jQuery.fn.ForceNumericOnly =
    function()
    {
        return this.each(function()
        {
            $(this).keydown(function(e)
            {
                var key = e.charCode || e.keyCode || 0;
                // allow backspace, tab, delete, enter, arrows, numbers and keypad numbers ONLY
                // home, end, period, and numpad decimal
                return (
                    key == 8 || 
                    key == 9 ||
                    key == 13 ||
                    key == 46 ||
                    key == 110 ||
                    key == 190 ||
                    (key >= 35 && key <= 40) ||
                    (key >= 48 && key <= 57) ||
                    (key >= 96 && key <= 105));
            });
        });
    };

    $("#add_amount").ForceNumericOnly();

    $('#add_nric').change(function() {
        if((add_nric === undefined || add_nric === null)){
            if(add_fname =="" ){
                $("#add_fname").addClass('has-error');
            }
        }else{
                $("#add_nric, .select2-selection").removeClass('has-error');
            if(add_fname !=""){
                $("#add_fname").removeClass('has-error');
            }
        }
    });

    $('#add_trans_type').change(function(){
        $(this).removeClass('has-error');        
        if( ($(this).val()=="Cash") || ($(this).val()=="") ){
            $("#add_trans_ref_no").removeClass('has-error').val('');
        }
    });   

    $('#add_trans_ref_no, #add_course_desc, #add_remarks, #add_amount, #add_fname').keydown(function(){
        $(this).removeClass('has-error'); 
    });


    
    $(".btn-searchs").click(function(){

        var nricz = $("#prog_search").val();    
    
        if(nricz != ""){

        var value = $("#receipts .nav-tabs li.active a span").html();

            if(value=="All"){
                loadData_all(1,nricz);
            } else if(value=="Received"){
                loadData_all_received(1,nricz); 
            } else if(value="Cancelled"){
                loadData_all_cancelled(1,nricz); 
            }

        }
        

    });

    

   

    


    

    $("#prog_search").keypress(function (e) {
      if (e.which == 13) {
        
        e.preventDefault();    

        var nricz = $("#prog_search").val();    
    
        if(nricz != ""){

        var value = $("#receipts .nav-tabs li.active a span").html();

            if(value=="All"){
                loadData_all(1,nricz);
            } else if(value=="Received"){
                loadData_all_received(1,nricz); 
            } else if(value="Cancelled"){
                loadData_all_cancelled(1,nricz); 
            }

        }


        return false;    //<---- Add this line
        
        }
    });
    
    $("#prog_search").keyup(function(){

        if( $(this).val()=="" ){
        

            var value = $("#receipts .nav-tabs li.active a span").html();

                if(value=="All"){
                    loadData_all(1,'nothing');
                } else if(value=="Received"){
                    loadData_all_received(1,'nothing'); 
                } else if(value="Cancelled"){
                    loadData_all_cancelled(1,'nothing'); 
                }

        }

    });

    $(".btn-searchz").click(function(){

        var nricz = $("#prog_searchs").val();    
    
       
        if(nricz != ""){

        var value = $("#participants .nav-tabs li.active a span").html();

            if(value=="Active"){
                loadData_all_participants(1,nricz);
            } else if(value=="Deleted"){
                loadData_all_del_participants(1,nricz); 
            } 

        }
   

    });


    $("#prog_searchs").keypress(function (e) {
      if (e.which == 13) {
        
        e.preventDefault();    

        var nricz = $("#prog_searchs").val();    
    
        if(nricz != ""){

        var value = $("#participants .nav-tabs li.active a span").html();

            if(value=="Active"){
                loadData_all_participants(1,nricz);
            } else if(value=="Deleted"){
                loadData_all_del_participants(1,nricz); 
            } 

        }


        return false;    //<---- Add this line
        
        }
    });
    
    $("#prog_searchs").keyup(function(){

        if( $(this).val()=="" ){
        

            var value = $("#participants .nav-tabs li.active a span").html();

                if(value=="Active"){
                loadData_all_participants(1,'nothing');
                } else if(value=="Deleted"){
                    loadData_all_del_participants(1,'nothing'); 
                }
        }

    });
    



    $("#user_search").keypress(function (e) {
      if (e.which == 13) {
        
        e.preventDefault();    

        var nricz = $("#user_search").val();    
    
        if(nricz != ""){

        var value = $("#users .nav-tabs li.active a span").html();

            if(value=="All"){
                loadData_all_users(1,nricz);
            } else if(value=="Main"){
                loadData_all_main(1,nricz);
            } else if(value=="Branch"){
                loadData_all_branch(1,nricz); 
            } 

        }


        return false;    //<---- Add this line
        
        }
    });
    
    $("#user_search").keyup(function(){

        if( $(this).val()=="" ){
        

            var value = $("#users .nav-tabs li.active a span").html();

                if(value=="All"){
                    loadData_all_users(1,'nothing');
                } else if(value=="Main"){
                    loadData_all_main(1,'nothing'); 
                } else if(value=="Branch"){
                    loadData_all_branch(1,'nothing'); 
                }
        }

    });
    
});