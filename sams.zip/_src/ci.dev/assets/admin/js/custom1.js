$(".edit-part-modal").click(function(e){
        
        e.preventDefault();
        var parent = $(this).parent().parent();
        var numero = parent.attr('id').replace('record-','');

        $.ajax({
            type: "GET",
            url: 'search-pr?id='+numero,
            beforeSend: function(x) {

            },
            dataType: "json",
            success: function(data){
                $("#p_id").html(data.p_id); 
                $("#p_nrics").html(data.p_nric);
                $("#p_nric").val(data.p_nric);    
                $("#p_fname").val(data.p_fname);
                $("#p_ref").val(data.p_ref); 
                
            }
        });

    });

    $(".del-part-modal").click(function(e){
        
        e.preventDefault();
        var parent = $(this).parent().parent();
        var numero = parent.attr('id').replace('record-','');

        $.ajax({
            type: "GET",
            url: 'search-pr?id='+numero,
            beforeSend: function(x) {

            },
            dataType: "json",
            success: function(data){
                $("#pd_id").html(data.p_id); 
                $("#pd_nrics").html(data.p_nric);
                $("#pd_nric").html(data.p_nric);    
                $("#pd_fname").html(data.p_fname);
                $("#pd_ref").html(data.p_ref); 
                
            }
        });

    });

    $(".yes-edit").unbind('click').bind('click', function (e) {
        
        e.preventDefault();
        var numero = $("#p_id").html();      
        var nric = $("#p_nric").val();
        var fname = $("#p_fname").val();
        var ref = $("#p_ref").val();


        $.ajax({
            type: "GET",
            url: 'update-pr?id='+numero+'&p_nric='+nric+'&p_fname='+fname+'&p_ref='+ref,
            success: function(msg)
            {                  
                
            },
            complete: function(){    
                
                //var value = $("#receipts .nav-tabs li.active a span").html();
                $.when( loadData_all_participants(ping_values,'nothing') ).done(function( x ) {
                  swal("Success!", "The participant ("+nric+") has been updated.", "success");
                });    
                  

            }
        }); 

    });

    $(".yes-delete").unbind('click').bind('click', function (e) {
        
        e.preventDefault();
        var numero = $("#pd_id").html();
        var numeros = $("#pd_nric").html();

        $.ajax({
            type: "GET",
            url: 'update-pr?del='+numero,
            success: function(data){
             
            },
            complete: function(data){ 
             
                $.when( loadData_all_participants(ping_values,'nothing'), loadData_all_del_participants(ping_valuex,'nothing') ).done(function( x ) {
                  swal("Success!", "The participant ("+numeros+") has been deleted.", "success");
                }); 

                count_del();
                count_act();
            }
        }); 

    });

    function count_del(){

        $.ajax({
            type: "GET",
            url: 'count-del',
            beforeSend: function(x) {

            },
            dataType: "json",
            success: function(data){
                $("li[role='del-tab'] co").html(data.value_del);
            }
                           
            
        }); 
    }

    function count_act(){

        $.ajax({
            type: "GET",
            url: 'count-act',
            beforeSend: function(x) {

            },
            dataType: "json",
            success: function(data){
                $("li[role='act-tab'] co").html(data.value_act);
            }
                           
            
        }); 
    }

    $(".nifty-close").click(function(e){
        $("#edit-part-modal").removeClass("md-show");
        $("#del-part-modal").removeClass("md-show");
    });