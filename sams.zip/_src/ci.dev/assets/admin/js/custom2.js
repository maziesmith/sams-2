    $(".edit-user-modal").click(function(e){

        e.preventDefault();
        var parent = $(this).parent().parent();
        var numero = parent.attr('id').replace('record-','');

        $.ajax({
            type: "GET",
            url: 'search-user?id='+numero,
            beforeSend: function(x) {

            },
            dataType: "json",
            success: function(data){
                $("#u_id").html(data.u_id); 
                $("#u_unames").html(data.u_username);
                $("#u_uname").val(data.u_username);
                $("#u_pass").val(data.u_password);    
                $("#u_email").val(data.u_email);
                $("#u_fname").val(data.u_fname); 
                $("#u_brselect").attr('value',data.u_brselect).html(data.u_branchname);

            }   
        });

    });

    $(".yes-edit-user").unbind('click').bind('click', function (e) {
        
        e.preventDefault();
        var u_id = $("#u_id").html();      
        var u_fname = $("#u_fname").val();
        var u_email = $("#u_email").val();
        var u_uname = $("#u_uname").val();
        var u_pass = $("#u_pass").val();
        var u_branch = $("#u_branch").val();


        $.ajax({
            type: "GET",
            url: 'update-user?id='+u_id+'&u_fname='+u_fname+'&u_email='+u_email+'&u_uname='+u_uname+'&u_pass='+u_pass+'&u_branch='+u_branch,
            success: function(msg)
            {               
                
            },
            complete: function(){    
                
                var value = $("#users .nav-tabs li.active a span").html();

                if(value=="All"){
                    $.when( loadData_all_users(ping_all_user,'nothing') ).done(function( x ) {
                      swal("Success!", "The user ("+u_uname+") has been updated.", "success");
                    });
                } else if(value=="Main"){
                    $.when( loadData_all_main(ping_all_main,'nothing') ).done(function( x ) {
                      swal("Success!", "The user ("+u_uname+") has been updated.", "success");
                    });
                } else if(value=="Branch"){
                    $.when( loadData_all_branch(ping_all_branch,'nothing') ).done(function( x ) {
                      swal("Success!", "The user ("+u_uname+") has been updated.", "success");
                    });
                }  
                  

            }
        }); 

    });

    /*$(".del-part-modal").click(function(e){
        
        e.preventDefault();
        var parent = $(this).parent().parent();
        var numero = parent.attr('id').replace('record-','');

        $.ajax({
            type: "GET",
            url: 'search-pr?id='+numero,
            beforeSend: function(x) {

            },
            dataType: "json",
            success: function(data){
                $("#pd_id").html(data.p_id); 
                $("#pd_nrics").html(data.p_nric);
                $("#pd_nric").html(data.p_nric);    
                $("#pd_fname").html(data.p_fname);
                $("#pd_ref").html(data.p_ref); 
                
            }
        });

    });*/

    

    /*
    $(".yes-delete").unbind('click').bind('click', function (e) {
        
        e.preventDefault();
        var numero = $("#pd_id").html();
        var numeros = $("#pd_nric").html();

        $.ajax({
            type: "GET",
            url: 'update-pr?del='+numero,
            success: function(data){
             
            },
            complete: function(data){ 
             
                $.when( loadData_all_participants(ping_values,'nothing'), loadData_all_del_participants(ping_valuex,'nothing') ).done(function( x ) {
                  swal("Success!", "The participant ("+numeros+") has been deleted.", "success");
                }); 

                count_del();
                count_act();
            }
        }); 

    });

    function count_del(){

        $.ajax({
            type: "GET",
            url: 'count-del',
            beforeSend: function(x) {

            },
            dataType: "json",
            success: function(data){
                $("li[role='del-tab'] co").html(data.value_del);
            }
                           
            
        }); 
    }

    function count_act(){

        $.ajax({
            type: "GET",
            url: 'count-act',
            beforeSend: function(x) {

            },
            dataType: "json",
            success: function(data){
                $("li[role='act-tab'] co").html(data.value_act);
            }
                           
            
        }); 
    }
    */

    $(".nifty-closes").click(function(e){
        $("#edit-user-modal").removeClass("md-show");        
    });
