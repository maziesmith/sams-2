
function loadData_all_cancelled(page,value){
  
    
    $(".portlet").append('<div class="panel-disableds"><i class="ion-loading-c"></i></div>');
    var $pd = $(".portlet").find('.panel-disableds');

    if(value=="nothing"){

        var nric = $("#add_nric").val();

        $.ajax
        ({
            type: "GET",
            url: "../admin/all-cancelled-receipts",
            data: "page="+page,       
            success: function(msg){         
                $("#containers-all-cancelled").html(msg);     
            },
            complete: function(){
                         
               $pd.fadeOut('fast', function () {
                    $pd.remove();         
                });
           

            }

        });
    
    } else {

        var nric = value;

        $.ajax
        ({
            type: "GET",
            url: "../admin/all-cancelled-receipts?value="+nric,
            data: "page="+page,       
            success: function(msg){         
                $("#containers-all-cancelled").html(msg);     
            },
            complete: function(){
                         
               $pd.fadeOut('fast', function () {
                    $pd.remove();         
                });
           

            }

        });
    }
   
}





var ping_valuez2 = 1;    
$('#containers-all-cancelled').on("click", ".pagination li.ping",function(){

    if($(this).hasClass('active')){

    } else {
        var page = $(this).attr('p');   
        loadData_all_cancelled(page,'nothing'); 

        ping_valuez2 = page;
    }

}); 



$(document).ready(function(){
    
    loadData_all_cancelled(1,'nothing'); 
    
});










