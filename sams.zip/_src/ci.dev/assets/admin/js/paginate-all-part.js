
function loadData_all_participants(page,value){
  
    
    $(".portlet").append('<div class="panel-disableds"><i class="ion-loading-c"></i></div>');
    var $pd = $(".portlet").find('.panel-disableds');

    if(value=="nothing"){

        var nric = $("#add_nric").val();

        $.ajax
        ({
            type: "GET",
            url: "../admin/all-participants",
            data: "page="+page,       
            success: function(msg){         
                $("#containers-all-part").html(msg);     
            },
            complete: function(){
                         
               $pd.fadeOut('fast', function () {
                    $pd.remove();         
                });
           

            }

        });
    
    } else {

        var nric = value;

        $.ajax
        ({
            type: "GET",
            url: "../admin/all-participants?value="+nric,
            data: "page="+page,       
            success: function(msg){         
                $("#containers-all-part").html(msg);     
            },
            complete: function(){
                         
               $pd.fadeOut('fast', function () {
                    $pd.remove();         
                });
           

            }

        });
    }
   
}




var ping_values = 1;

$('#containers-all-part').on("click", ".pagination li.ping",function(){
    
    if($(this).hasClass('active')){

    } else {
        var page = $(this).attr('p');   
        loadData_all_participants(page,'nothing'); 

        ping_values = page;
    }

}); 



$(document).ready(function(){
    
    loadData_all_participants(1,'nothing'); 
    
});










