
function loadData_all_received(page,value){
  
    
    $(".portlet").append('<div class="panel-disableds"><i class="ion-loading-c"></i></div>');
    var $pd = $(".portlet").find('.panel-disableds');

    if(value=="nothing"){

        var nric = $("#add_nric").val();

        $.ajax
        ({
            type: "GET",
            url: "../admin/all-received-receipts",
            data: "page="+page,       
            success: function(msg){         
                $("#containers-all-received").html(msg);     
            },
            complete: function(){
                         
               $pd.fadeOut('fast', function () {
                    $pd.remove();         
                });
           

            }

        });
    
    } else {

        var nric = value;

        $.ajax
        ({
            type: "GET",
            url: "../admin/all-received-receipts?value="+nric,
            data: "page="+page,       
            success: function(msg){         
                $("#containers-all-received").html(msg);     
            },
            complete: function(){
                         
               $pd.fadeOut('fast', function () {
                    $pd.remove();         
                });
           

            }

        });
    }
   
}





var ping_valuez3 = 1;

$('#containers-all-received').on("click", ".pagination li.ping",function(){

    if($(this).hasClass('active')){

    } else {
        var page = $(this).attr('p');   
        loadData_all_received(page,'nothing');  

        ping_valuez3 = page;
    }

}); 



$(document).ready(function(){
    
    loadData_all_received(1,'nothing'); 
    
});










