
function loadData_all(page,value){
  
    
    $(".portlet").append('<div class="panel-disableds"><i class="ion-loading-c"></i></div>');
    var $pd = $(".portlet").find('.panel-disableds');

    if(value=="nothing"){

        var nric = $("#add_nric").val();

        $.ajax
        ({
            type: "GET",
            url: "../admin/all-receipts",
            data: "page="+page,       
            success: function(msg){         
                $("#containers-all").html(msg);     
            },
            complete: function(){
                         
               $pd.fadeOut('fast', function () {
                    $pd.remove();         
                });
           

            }

        });
    
    } else {

        var nric = value;

        $.ajax
        ({
            type: "GET",
            url: "../admin/all-receipts?value="+nric,
            data: "page="+page,       
            success: function(msg){         
                $("#containers-all").html(msg);     
            },
            complete: function(){
                         
               $pd.fadeOut('fast', function () {
                    $pd.remove();         
                });
           

            }

        });
    }
   
}

$(".btn-search").click(function(){
    
    var nricz = $("#nric_search").val();    
    
    if(nricz != ""){
        $("#nric_values").html("("+nricz+")");
        loadData_all(1,nricz)
    }

});





var ping_valuez1 = 1;

$('#containers-all').on("click", ".pagination li.ping",function(){

    if($(this).hasClass('active')){

    } else {
        var page = $(this).attr('p');   
        loadData_all(page,'nothing'); 

        ping_valuez1 = page;
    }


}); 



$(document).ready(function(){
    
    loadData_all(1,'nothing'); 
    
});










