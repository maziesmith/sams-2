
function loadData(page,value){
  
    
    $(".portlet").append('<div class="panel-disableds"><i class="ion-loading-c"></i></div>');
    var $pd = $(".portlet").find('.panel-disableds');

    if(value=="nothing"){

        var nric = $("#add_nric").val();

        $.ajax
        ({
            type: "GET",
            url: "../search-receipts?nric="+nric,
            data: "page="+page,       
            success: function(msg){         
                $("#containers").html(msg);     
            },
            complete: function(){
                         
               $pd.fadeOut('fast', function () {
                    $pd.remove();         
                });
           

            }

        });
    
    } else {

        var nric = value;

        $.ajax
        ({
            type: "GET",
            url: "../search-receipts?participants="+nric,
            data: "page="+page,       
            success: function(msg){         
                $("#containers").html(msg);     
            },
            complete: function(){
                         
               $pd.fadeOut('fast', function () {
                    $pd.remove();         
                });
           

            }

        });
    }
   
}

$(".btn-search").click(function(){
    
    var nricz = $("#nric_search").val();    
    
    if(nricz != ""){
        $("#nric_values").html("("+nricz+")");
        loadData(1,nricz)
    }

});

$("#nric_search").keypress(function (e) {
  if (e.which == 13) {
    
    e.preventDefault();    

    var nricz = $("#nric_search").val();    

    if(nricz != ""){
        $("#nric_values").html("("+nricz+")");
        loadData(1,nricz)
    }


    return false;    //<---- Add this line
    
    }
});

$("#nric_search").keyup(function(){

    if( $(this).val()=="" ){
        $("#nric_values").html("");
    }

});





$('#containers').on("click", ".pagination li.ping",function(){
    
    var page = $(this).attr('p');   
    loadData(page,'nothing'); 

}); 



$(document).ready(function(){
    
    loadData(1,'nothing'); 
    
});










