$(document).on('click', 'button#Login', function (e) {
    e.preventDefault();
    var button = $(this);
    var formData = button.closest('form#LoginForm').serialize();

    console.log(formData);

    $.ajax({
        url: base_url + 'ajax_login',
        async: false,
        type: "POST",
        data: formData,
        dataType: "json",
        beforeSend: function () {

            button.html('<i class="fa fa-spinner fa-spin"></i>').prop('disabled', true);

        },
        success: function (data) {
      
            if (data.status === 'Success') {
                window.location.href = data.redirect;
            } else {
                button.closest('form#LoginForm').find('.help-block').addClass('alert-danger').text('Invalid username or password.');
                button.html('Log In').prop('disabled', false);                
            }

        },

        error: function( jqXhr ) {
            if( jqXhr.status == 400 ) { //Validation error or other reason for Bad Request 400
                var json = $.parseJSON( jqXhr.responseText );
            }
        }

    });



});

$('.login-username, .login-password').keypress(function (e) {
  if (e.which == 13) {
    
    e.preventDefault();
    var formData = $('form#LoginForm').serialize();

    console.log(formData);

    $.ajax({
        url: base_url + 'ajax_login',
        async: false,
        type: "POST",
        data: formData,
        dataType: "json",
        beforeSend: function () {

            $('form#LoginForm').find('.btn').html('<i class="fa fa-spinner fa-spin"></i>').prop('disabled', true);

        },
        success: function (data) {
      
            if (data.status === 'Success') {
                window.location.href = data.redirect;
            } else {
                $('form#LoginForm').find('.help-block').addClass('alert-danger').text('Invalid username or password.');
                $('form#LoginForm').find('.btn').html('Log In').prop('disabled', false);                
            }

        },

        error: function( jqXhr ) {
            if( jqXhr.status == 400 ) { //Validation error or other reason for Bad Request 400
                var json = $.parseJSON( jqXhr.responseText );
            }
        }

    });

    return false;    //<---- Add this line
  }
});



$(document).ready(function() {
    Pace.on("done", function(){
        $(".title-animation").addClass("fadeInRight").css({"visibility":"visible"});
        setTimeout(function(){ 
            $(".moving").addClass("downplease");

        }, 500);
        
    });
});