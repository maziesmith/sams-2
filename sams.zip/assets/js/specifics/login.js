jQuery(document).ready(function ($) {
    // $('#form-login button[type=submit]').on('click', function (e) {
    //     e.preventDefault();
    //     $.ajax({
    //         method: "POST",
    //         url: base_url('auth/login'),
    //         data: $('#form-login').serialize(),
    //         success: function (data) {
    //             var data = $.parseJSON(data);
    //             console.log(data);
    //         }
    //     });
    // });
})